/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// EDIT THIS FILE!  THIS IS SCAFFOLDING FOR YOU TO OWN!
// NOTE: json tags are required.  Any new fields you add must have json tags for the fields to be serialized.

// BandProfileSpec defines the desired state of BandProfile
type BandProfileSpec struct {
	// INSERT ADDITIONAL SPEC FIELDS - desired state of cluster
	// Important: Run "make" to regenerate code after modifying this file

	// Id specifies the unique ID of the BandProfile.
	// +kubebuilder:validation:Required
	Id string `json:"id"`

	//committed information rate
	// +kubebuilder:validation:Required
	Cir int `json:"cir"`

	//committed bast size
	// +kubebuilder:validation:Required
	Cbs int `json:"cbs"`

	//size up to which subscriber traffic is allowed to burst in profile and not be discarded or shaped
	// +kubebuilder:validation:Required
	Eir int `json:"eir"`

	//size up to which the traffic is allowed to burst without being discarded
	// +kubebuilder:validation:Required
	Ebs int `json:"ebs"`

	//TODO: ADD COMMENT
	Air int `json:"air"`
}

// BandProfileStatus defines the observed state of BandProfile
type BandProfileStatus struct {
	// INSERT ADDITIONAL STATUS FIELD - define observed state of cluster
	// Important: Run "make" to regenerate code after modifying this file
}

//+kubebuilder:object:root=true
//+kubebuilder:subresource:status

// BandProfile is the Schema for the BandProfiles API
type BandProfile struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   BandProfileSpec   `json:"spec,omitempty"`
	Status BandProfileStatus `json:"status,omitempty"`
}

//+kubebuilder:object:root=true

// BandProfileList contains a list of BandProfile
type BandProfileList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []BandProfile `json:"items"`
}

func init() {
	SchemeBuilder.Register(&BandProfile{}, &BandProfileList{})
}
