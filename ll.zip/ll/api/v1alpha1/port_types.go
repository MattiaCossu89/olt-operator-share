/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// EDIT THIS FILE!  THIS IS SCAFFOLDING FOR YOU TO OWN!
// NOTE: json tags are required.  Any new fields you add must have json tags for the fields to be serialized.

// PortSpec defines the desired state of Port
type PortSpec struct {
	// INSERT ADDITIONAL SPEC FIELDS - desired state of cluster
	// Important: Run "make" to regenerate code after modifying this file

	// Id Specifies the ID of the port.
	// +kubebuilder:validation:Required
	Id string `json:"id"`

	// Name Specifies the name of the port.
	// +kubebuilder:validation:Required
	Name string `json:"name"`

	// PeerId Specifies the id of the device to which this port is used for connection (e.g peer).
	// It applies to pon port, UNI port are connected to RG
	// +kubebuilder:validation:Required
	PeerId string `json:"peerId"`

	// PeerPortId Specifies the id of the port to which this port is used for connection (e.g. peer).
	// It applies to pon port. Unit port are connected to RG
	// +kubebuilder:validation:Required
	PeerPortId string `json:"peerPortId"`

	// Type Specifies the type of port. NNI or PON or UNI
	// +kubebuilder:validation:Enum=NNI;PON;UNI
	// +kubebuilder:validation:Required
	Type string `json:"type"`

	// UniPortType Specifies the type of the UNI port.
	// This parameter is applicable only for the UNI port and it is mandatory for the UNI port.
	// +kubebuilder:validation:Enum=VEIP;PPTP-ETHERNET
	UniPortType string `json:"uniPortType,omitempty"`

	// PhysPortNo Specifies the physical port number for the PON port. Example: 15
	// +kubebuilder:validation:Required
	PhysPortNo string `json:"physPortNo"`

	// Capacity Specifies the capacity of the port.
	// +kubebuilder:validation:Required
	Capacity string `json:"capacity"`

	// CapacityUnit Specifies the unit for the capacity. (e.g. Gigabit)
	// +kubebuilder:validation:Required
	CapacityUnit string `json:"capacityUnit"`

	// EnablePonEncryption Specifies the PON encryption. This field is applicable only for the PON port.
	EnablePonEncryption bool `json:"enablePonEncryption,omitempty"`

	// PonEncryptionKeyExchangeInterval This field is applicable only for the PON port.
	// The default value is 1 hour.  Specifies the PON encryption key exchange interval in milliseconds.
	// If the value is configured as ‘0’, one time key exchange is considered. However, for the security,
	// a periodic key exchange is recommended.
	// +kubebuilder:default:=3600000
	PonEncryptionKeyExchangeInterval int `json:"ponEncryptionKeyExchangeInterval,omitempty"`

	// AdminState specifies whether the port is administratively enabled or disabled or down.
	AdminState string `json:"adminState,omitempty"`

	// OperationalState specifies whether the port is operationally up or down or forced in any other state. See table below
	OperationalState string `json:"operationalState,omitempty"`

	// OnHold Specifies whether the port is blacklisted or not.
	// +kubebuilder:default:=false
	OnHold bool `json:"onHold,omitempty"`

	// SfpId Specifies the SFP ID.
	SfpId bool `json:"sfpId,omitempty"`

	// SfpName Specifies the SFP name.
	SfpName bool `json:"sfpName,omitempty"`
}

// PortStatus defines the observed state of Port
type PortStatus struct {
	// INSERT ADDITIONAL STATUS FIELD - define observed state of cluster
	// Important: Run "make" to regenerate code after modifying this file
}

//+kubebuilder:object:root=true
//+kubebuilder:subresource:status

// Port is the Schema for the ports API
type Port struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   PortSpec   `json:"spec,omitempty"`
	Status PortStatus `json:"status,omitempty"`
}

//+kubebuilder:object:root=true

// PortList contains a list of Port
type PortList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []Port `json:"items"`
}

func init() {
	SchemeBuilder.Register(&Port{}, &PortList{})
}
