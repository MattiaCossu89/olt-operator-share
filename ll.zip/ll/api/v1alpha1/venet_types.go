/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// EDIT THIS FILE!  THIS IS SCAFFOLDING FOR YOU TO OWN!
// NOTE: json tags are required.  Any new fields you add must have json tags for the fields to be serialized.

// VenetSpec defines the desired state of Venet
type VenetSpec struct {
	// INSERT ADDITIONAL SPEC FIELDS - desired state of cluster
	// Important: Run "make" to regenerate code after modifying this file

	// Id specifies the VNet profile ID.
	// +kubebuilder:validation:Required
	Id string `json:"id"`

	// Name specifies the unique name of the VNet profile. Example: Subscriber-1
	// +kubebuilder:validation:Required
	Name string `json:"name"`

	// Uvlan specifies the VLAN or UNI port. The value uni_vlan 0 indicates untagged packet classification.
	Uvlan int `json:"uvlan"`

	// Svlan specifies the subscriber's S-Tag value. The supported value ranges from 2 to 4094.
	// +kubebuilder:validation:Required
	Svlan int `json:"svlan"`

	// Cvlan specifies the subscriber's C-Tag value. The supported value ranges from 2 to 4094.
	// +kubebuilder:validation:Required
	Cvlan int `json:"cvlan"`

	// Encapsulation Specifies the type of access protocol used to establish the access link.
	// +kubebuilder:validation:Enum=IPoE;PPoE
	// +kubebuilder:validation:Required
	Encapsulation string `json:"encapsulation"`

	// VlanControl Specifies the VLAN tagging supported at the ONU and OLT. The supported values are.
	// +kubebuilder:validation:Enum=ONU_CVLAN_OLT_SVLAN;OLT_CVLAN_OLT_SVLAN;ONU_CVLAN;OLT_SVLAN;NONE
	// +kubebuilder:default:=ONU_CVLAN_OLT_SVLAN
	VlanControl string `json:"vlanControl"`

	// IsDhcpEnabled enable DHCP.
	// +kubebuilder:default:=false
	IsDhcpEnabled bool `json:"isDhcpEnabled"`

	// IsIgmpEnabled enable IGMP.
	// +kubebuilder:default:=false
	IsIgmpEnabled bool `json:"isIgmpEnabled"`

	// IsPppoeEnabled enable PPPoE.
	// +kubebuilder:default:=true
	IsPppoeEnabled bool `json:"isPppoeEnabled"`

	// RgMac Specifies the MAC address of the RG connected to the particular UNI port for the enterprise (Bridged Mode) solution. The MAC address is same for the residential solution (Gateway Mode).
	// +kubebuilder:validation:Required
	RgMac string `json:"rgMac"`

	// AesEncryption Specifies whether the AES encryption is supported.
	// +kubebuilder:validation:Required
	AesEncryption bool `json:"aesEncryption"`

	// RemoteIdType Specifies the type of remote ID.
	// +kubebuilder:validation:Enum=MAC_Address;Custom
	RemoteIdType string `json:"remoteIdType"`

	// CircuitId Specifies the circuit ID.
	CircuitId string `json:"circuitId"`

	// RemoteId Specifies the remote ID. This field is applicable only when the remote_id_type is set to Custom. Otherwise, this field is ignored and can be left empty.
	RemoteId string `json:"remoteId"`

	// OntEthertypeClassification Specifies if the upstream traffic needs to be classified based on the ether type.
	OntEthertypeClassification bool `json:"ontEthertypeClassification"`

	// MacLearningType Specifies the type of method used to learn device MAC address.
	// +kubebuilder:validation:Enum=DHCP;ARP;None
	MacLearningType string `json:"macLearningType"`
}

// VenetStatus defines the observed state of Venet
type VenetStatus struct {
	// INSERT ADDITIONAL STATUS FIELD - define observed state of cluster
	// Important: Run "make" to regenerate code after modifying this file
}

//+kubebuilder:object:root=true
//+kubebuilder:subresource:status

// Venet is the Schema for the venets API
type Venet struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   VenetSpec   `json:"spec,omitempty"`
	Status VenetStatus `json:"status,omitempty"`
}

//+kubebuilder:object:root=true

// VenetList contains a list of Venet
type VenetList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []Venet `json:"items"`
}

func init() {
	SchemeBuilder.Register(&Venet{}, &VenetList{})
}
