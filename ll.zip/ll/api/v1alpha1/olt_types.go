/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1alpha1

import (
	_ "github.com/opencord/voltha-protos/v4/go/voltha"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// EDIT THIS FILE!  THIS IS SCAFFOLDING FOR YOU TO OWN!
// NOTE: json tags are required.  Any new fields you add must have json tags for the fields to be serialized.

// OltSpec defines the desired state of Olt
type OltSpec struct {
	// INSERT ADDITIONAL SPEC FIELDS - desired state of cluster
	// Important: Run "make" to regenerate code after modifying this file

	// Id is the id of the OLT
	// +kubebuilder:validation:Required
	Id string `json:"id"`

	// Name is the name of the OLT
	// +kubebuilder:validation:Required
	Name string `json:"name"`

	// Uuid specifies the UUID of the OLT.
	Uuid string `json:"uuid,omitempty"`

	// ParentId specifies the id of the AccessNode to which the OLT will be associated
	// +kubebuilder:validation:Required
	ParentId string `json:"parentId"`

	// Vendor is the vendor of the OLT
	// +kubebuilder:validation:Enum=edgecore;adtran;bbsim
	// +kubebuilder:validation:Required
	Vendor string `json:"vendor"`

	// Model is the model of the OLT
	// +kubebuilder:validation:Required
	Model string `json:"model"`

	// Technology specifies the technology implemented in the OLT. The supported technologies are.
	// +kubebuilder:validation:Enum=GPON;XGS-PON
	// +kubebuilder:validation:Required
	Technology string `json:"technology"`

	// SerialNo specifies the serial number of the OLT. It plays the role of ztpIdent for in band management and address assignment
	// +kubebuilder:validation:Required
	SerialNo string `json:"serialNo"`

	// ZtpIdent specifies the serial number of the OLT. It plays the role of ztpIdent for in band management and address assignment
	// +kubebuilder:validation:Required
	ZtpIdent string `json:"ztpIdent"`

	// MacAddress is the MAC address of the OLT. It is used by DHCP to assign the in band management ip address
	// +kubebuilder:validation:Required
	MacAddress string `json:"macAddress"`

	// IpAddress specifies the IPv4 in band address of the OLT (es. 192.168.21.44)
	// +kubebuilder:validation:Required
	IpAddress string `json:"ipAddress"`

	// Cidr specifies the network of the in band management address (es. 192.168.21.0/24)
	// +kubebuilder:validation:Required
	Cidr string `json:"cidr"`

	// VlanId specifies the in bad management VLAN ID on NNI port (es. 4093)
	// +kubebuilder:validation:Required
	VlanId int `json:"vlanId"`

	// AdminState specifies whether the OLT is administratively enabled or disabled or down.
	AdminState string `json:"adminState,omitempty"`

	// OperationalState specifies whether the OLT is operationally up or down or forced in any other state. See table below
	OperationalState string `json:"operationalState,omitempty"`

	// ConnectState Specifies whether the OLT is reachable by the dOLT control plane.
	ConnectState string `json:"connectState,omitempty"`

	// Reason is the latest reason for changing one of the state
	Reason string `json:"reason,omitempty"`

	// SoftwareVersion specifies the software version of the OLT.
	SoftwareVersion string `json:"softwareVersion,omitempty"`

	// OnHold specifies whether the OLT is blacklisted or not.
	// +kubebuilder:default:=false
	OnHold bool `json:"onHold,omitempty"`

	// OperationalData additional configuration mandatory for the dOLT control plane
	OperationalData string `json:"operationalData,omitempty"`

	// Clli identifies the central location
	Clli string `json:"clli,omitempty"`
}

// OltStatus defines the observed state of Olt
type OltStatus struct {
	// INSERT ADDITIONAL STATUS FIELD - define observed state of cluster
	// Important: Run "make" to regenerate code after modifying this file

	// AdminState represents the administrative state
	//+nullable
	//+optional
	AdminState string `json:"adminState"`

	// OperStatus represents the operative status
	//+nullable
	//+optional
	OperStatus string `json:"operStatus"`

	// Reason represents the reason for the last state
	//+nullable
	//+optional
	Reason string `json:"reason"`

	// ConnectStatus represents the connection status
	//+nullable
	//+optional
	ConnectStatus string `json:"connectStatus"`

	// DeviceId represents the id of the device as seen by Voltha
	//+nullable
	//+optional
	DeviceId string `json:"deviceId"`

	// Ports represents the ports of the device as seen by Voltha
	//+nullable
	//+optional
	Ports []OltDevicePort `json:"ports"`

	//Ont discovered but not yet setted in the cluster
	//+nullable
	//+optional
	DiscoveredOnt []DiscoveredOnt `json:"discoveredOnt,omitempty"`
}

type DiscoveredOnt struct {
	Id            string `json:"id,omitempty"`
	SerialNo      string `json:"serialNo,omitempty"`
	AdminState    string `json:"adminstate,omitempty"`
	OperStatus    string `json:"operstatus,omitempty"`
	Reason        string `json:"reason,omitempty"`
	ConnectStatus string `json:"connectstatus,omitempty"`
}

type OltPeerPort struct {
	DeviceId string `json:"deviceid"`
	PortNo   uint32 `json:"portno"`
}

type OltDevicePort struct {
	PortNo     uint32        `json:"portno"`
	Label      string        `json:"label"`
	Type       string        `json:"type"`
	AdminState string        `json:"adminstate"`
	OperStatus string        `json:"operstatus"`
	DeviceId   string        `json:"deviceid"`
	Peers      []OltPeerPort `json:"peers"`
}

//+kubebuilder:object:root=true
//+kubebuilder:subresource:status
// +kubebuilder:printcolumn:name="SerialNumber",type="string",JSONPath=".spec.serialNo",description="The serial number"
// +kubebuilder:printcolumn:name="AdminState",type="string",JSONPath=".status.adminState",description="The administrative state"
// +kubebuilder:printcolumn:name="OperStatus",type="string",JSONPath=".status.operStatus",description="The operative status"
// +kubebuilder:printcolumn:name="ConnectStatus",type="string",JSONPath=".status.connectStatus",description="The connection status"
// +kubebuilder:printcolumn:name="Reason",type="string",JSONPath=".status.reason",description="The reason"
// +kubebuilder:printcolumn:name="DeviceId",type="string",JSONPath=".status.deviceId",description="The Voltha device ID"

// Olt is the Schema for the olts API
type Olt struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   OltSpec   `json:"spec,omitempty"`
	Status OltStatus `json:"status,omitempty"`
}

//+kubebuilder:object:root=true

// OltList contains a list of Olt
type OltList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []Olt `json:"items"`
}

func init() {
	SchemeBuilder.Register(&Olt{}, &OltList{})
}
