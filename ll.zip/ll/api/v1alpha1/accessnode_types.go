/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// EDIT THIS FILE!  THIS IS SCAFFOLDING FOR YOU TO OWN!
// NOTE: json tags are required.  Any new fields you add must have json tags for the fields to be serialized.

// AccessNodeSpec defines the desired state of AccessNode
type AccessNodeSpec struct {
	// INSERT ADDITIONAL SPEC FIELDS - desired state of cluster
	// Important: Run "make" to regenerate code after modifying this file

	// Id specifies the unique ID of the AccessNode.
	// +kubebuilder:validation:Required
	Id string `json:"id"`

	// Uuid specifies the UUID of the AccessNode.
	Uuid string `json:"uuid,omitempty"`

	// Name specifies the name of the AccessNode.
	Name string `json:"name,omitempty"`

	// ZtpIdent specifies the identifier name of the AccessNode.
	ZtpIdent string `json:"ztpIdent,omitempty"`

	// MacAddress specifies the mac address of the port used on AccessNode for initiating ZTP (DHCP discovery)
	MacAddress string `json:"macAddress,omitempty"`

	// IpAddress specifies the ip to get health check info for the AccessNode
	IpAddress string `json:"ipAddress,omitempty"`

	// AdminState specifies whether the AccessNode is administratively enabled or disabled or down.
	AdminState string `json:"adminState,omitempty"`

	// OperationalState specifies whether the AccessNode is operationally up or down.
	OperationalState string `json:"operationalState,omitempty"`

	// Reason is the latest reason for changing one of the state
	Reason string `json:"reason,omitempty"`
}

// AccessNodeStatus defines the observed state of AccessNode
type AccessNodeStatus struct {
	// INSERT ADDITIONAL STATUS FIELD - define observed state of cluster
	// Important: Run "make" to regenerate code after modifying this file
}

//+kubebuilder:object:root=true
//+kubebuilder:subresource:status

// AccessNode is the Schema for the accessnodes API
type AccessNode struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   AccessNodeSpec   `json:"spec,omitempty"`
	Status AccessNodeStatus `json:"status,omitempty"`
}

//+kubebuilder:object:root=true

// AccessNodeList contains a list of AccessNode
type AccessNodeList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []AccessNode `json:"items"`
}

func init() {
	SchemeBuilder.Register(&AccessNode{}, &AccessNodeList{})
}
