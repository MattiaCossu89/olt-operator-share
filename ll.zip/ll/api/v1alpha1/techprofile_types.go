/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// EDIT THIS FILE!  THIS IS SCAFFOLDING FOR YOU TO OWN!
// NOTE: json tags are required.  Any new fields you add must have json tags for the fields to be serialized.

// TechProfileSpec defines the desired state of TechProfile
type TechProfileSpec struct {
	// INSERT ADDITIONAL SPEC FIELDS - desired state of cluster
	// Important: Run "make" to regenerate code after modifying this file

	// Id Specifies the ID of the tech profile.
	// +kubebuilder:validation:Required
	Id int `json:"id"`

	ProfileMap []TechProfileMap `json:"profileMap,omitempty"`
}

type TechProfileMap struct {
	// Name is the name of the profile
	// +kubebuilder:validation:Required
	Name string `json:"name"`

	// ProfileType is the type
	// +kubebuilder:validation:Required
	ProfileType string `json:"profileType"`

	Version                        int                               `json:"version"`
	NumGemPorts                    int                               `json:"numGemPorts"`
	InstanceControl                TechProfileInstanceControl        `json:"instanceControl"`
	UsScheduler                    TechProfileScheduler              `json:"usScheduler"`
	DsScheduler                    TechProfileScheduler              `json:"dsScheduler"`
	UpstreamGemPortAttributeList   []TechProfileGemPortAttributeList `json:"upstreamGemPortAttributeList"`
	DownstreamGemPortAttributeList []TechProfileGemPortAttributeList `json:"downstreamGemPortAttributeList"`
}

type TechProfileInstanceControl struct {
	Onu               string `json:"onu"`
	Uni               string `json:"uni"`
	MaxGemPayloadSize string `json:"maxGemPayloadSize"`
}

type TechProfileScheduler struct {
	AdditionalBw string `json:"additionalBw"`
	Direction    string `json:"direction"`
	Priority     int    `json:"priority"`
	Weight       int    `json:"weight"`
	QSchedPolicy string `json:"qSchedPolicy"`
}

type TechProfileGemPortAttributeList struct {
	PbitMap          string                   `json:"pbitMap"`
	AesEncryption    string                   `json:"aesEncryption"`
	SchedulingPolicy string                   `json:"schedulingPolicy"`
	PriorityQ        int                      `json:"priorityQ"`
	Weight           int                      `json:"weight"`
	DiscardPolicy    string                   `json:"discardPolicy"`
	MaxQSize         string                   `json:"maxQSize"`
	DiscardConfig    TechProfileDiscardConfig `json:"discardConfig"`
}

type TechProfileDiscardConfig struct {
	MaxThreshold   int `json:"maxThreshold"`
	MinThreshold   int `json:"minThreshold"`
	MaxProbability int `json:"maxProbability"`
}

// TechProfileStatus defines the observed state of TechProfile
type TechProfileStatus struct {
	// INSERT ADDITIONAL STATUS FIELD - define observed state of cluster
	// Important: Run "make" to regenerate code after modifying this file
}

//+kubebuilder:object:root=true
//+kubebuilder:subresource:status

// TechProfile is the Schema for the techprofiles API
type TechProfile struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   TechProfileSpec   `json:"spec,omitempty"`
	Status TechProfileStatus `json:"status,omitempty"`
}

//+kubebuilder:object:root=true

// TechProfileList contains a list of TechProfile
type TechProfileList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []TechProfile `json:"items"`
}

func init() {
	SchemeBuilder.Register(&TechProfile{}, &TechProfileList{})
}
