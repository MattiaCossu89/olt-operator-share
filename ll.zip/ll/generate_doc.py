#!./docs/venv/bin/python3
import os
from typing import final
import yaml
from docs.src.definitions import createDefinitions
from docs.src.tohtml import toHtml

yamlFolder = './config/crd/bases/'
conf = './docs/baseConfig/headerDocs.yaml'

def getFiles():
    try:
        directoryList = os.listdir(yamlFolder)
    except:
        print('Error: yaml folder not found in ' + yamlFolder)
        exit(0)
    return directoryList

def generateMethod(path, pathObj):
    pathObj[path]['post'] = {}
    pathObj[path + '/{name}']['put'] = {}
    pathObj[path]['get'] = {}
    pathObj[path + '/{name}']['get'] = {}
    pathObj[path]['delete'] = {}
    pathObj[path + '/{name}']['delete'] = {}
    #pathObj[path]['patch'] = {}
    return pathObj

def generateGet(path, pathObj, obj, returnName):
    try:
        nameObj = obj['spec']['names']['singular']
    except:
        nameObj = "undefined"
    try:
        pluralNameObj = obj['spec']['names']['plural']
    except:
        pluralNameObj = "undefined"

    pathObj[path]['get']['parameters'] = [
        { 
            "in": "path",
            "name": "NameNamespace",
            "description" : "Name of namespace to select",
            "required" : True,
            "type" : "string" 
        }
    ]

    pathObj[path + '/{name}']['get']['parameters'] = [
        { 
            "in": "path",
            "name": "name",
            "description" : "Name of " + nameObj + " to return",
            "required" : True,
            "type" : "string" 
        },
        { 
            "in": "path",
            "name": "NameNamespace",
            "description" : "Name of namespace to select",
            "required" : True,
            "type" : "string" 
        }
    ]

    pathObj[path]['get']['tags'] = [nameObj]
    pathObj[path + '/{name}']['get']['tags'] = [nameObj]

    pathObj[path]['get']['summary'] = "Return all " + pluralNameObj
    pathObj[path + '/{name}']['get']['summary'] = "Find " + nameObj + " by name"

    pathObj[path]['get']['description'] = "Return all " + pluralNameObj
    pathObj[path + '/{name}']['get']['description'] = "Find " + nameObj + " by name"

    pathObj[path]['get']['operationId'] = "get" + pluralNameObj[0:1].upper() + pluralNameObj[1:]
    pathObj[path + '/{name}']['get']['operationId'] = "get" + nameObj[0:1].upper() + nameObj[1:] + "ByName"

    pathObj[path]['get']['produces'] = ["application/json"]
    pathObj[path + '/{name}']['get']['produces'] = ["application/json"]

    #TODO add $ref to OBJ response
    pathObj[path]['get']['responses'] = {
        "200" : {
            "description" : "successful",
            "schema" : {
                "$ref" : "#/definitions/" + returnName
            }
        },
        "401" : {
            "description" : "Unauthorized"
        }
    }
    pathObj[path + '/{name}']['get']['responses'] = {
        "200" : {
            "description" : "OK",
            "schema" : {
                "$ref" : "#/definitions/" + returnName
            }
        },
        "401" : {
            "description" : "Unauthorized"
        }
    }
    return pathObj

def generateDelete(path, pathObj, obj, returnName):
    try:
        nameObj = obj['spec']['names']['singular']
    except:
        nameObj = "undefined"
    try:
        pluralNameObj = obj['spec']['names']['plural']
    except:
        pluralNameObj = "undefined"

    pathObj[path]['delete']['parameters'] = [
        { 
            "in": "path",
            "name": "NameNamespace",
            "description" : "Name of namespace to select",
            "required" : True,
            "type" : "string" 
        }
    ]

    pathObj[path + '/{name}']['delete']['parameters'] = [
        { 
            "in": "path",
            "name": "name",
            "description" : "Name of " + nameObj + " to delete",
            "required" : True,
            "type" : "string" 
        },
        { 
            "in": "path",
            "name": "NameNamespace",
            "description" : "Name of namespace to select",
            "required" : True,
            "type" : "string" 
        }
    ]

    pathObj[path]['delete']['tags'] = [nameObj]
    pathObj[path + '/{name}']['delete']['tags'] = [nameObj]

    pathObj[path]['delete']['summary'] = "Delete all " + pluralNameObj
    pathObj[path + '/{name}']['delete']['summary'] = "Delete " + nameObj + " by name"

    pathObj[path]['delete']['description'] = "Delete all " + pluralNameObj
    pathObj[path + '/{name}']['delete']['description'] = "Delete " + nameObj + " by name"

    pathObj[path]['delete']['operationId'] = "delete" + pluralNameObj[0:1].upper() + pluralNameObj[1:]
    pathObj[path + '/{name}']['delete']['operationId'] = "delete" + nameObj[0:1].upper() + nameObj[1:] + "ByName"

    pathObj[path]['delete']['produces'] = ["application/json"]
    pathObj[path + '/{name}']['delete']['produces'] = ["application/json"]

    pathObj[path]['delete']['responses'] = {
        "200" : {
            "description" : "successful"
        },
        "401" : {
            "description" : "Unauthorized"
        }
    }
    pathObj[path + '/{name}']['delete']['responses'] = {
        "200" : {
            "description" : "OK",
            "schema" : {
                "$ref" : "#/definitions/" + returnName
            }
        },
        "401" : {
            "description" : "Unauthorized"
        }
    }
    return pathObj

def generatePost(path, pathObj, obj, returnName):
    try:
        nameObj = obj['spec']['names']['singular']
    except:
        nameObj = "undefined"

    pathObj[path]['post']['tags'] = [nameObj]

    pathObj[path]['post']['summary'] = "Create " + nameObj + " with body parameters"

    pathObj[path]['post']['description'] = "Create " + nameObj + " with body parameters"

    pathObj[path]['post']['operationId'] = "create" + nameObj[0:1].upper() + nameObj[1:]

    pathObj[path]['post']['parameters'] =  [
        {
            "in": "body",
            "name" : "body",
            "required" : True,
            "description" : "Parameters used to create " + nameObj,
            "schema"  : {
                "$ref" : "#/definitions/" + returnName
            }
        },
        { 
            "in": "path",
            "name": "NameNamespace",
            "description" : "Name of namespace to select",
            "required" : True,
            "type" : "string" 
        }

    ]

    pathObj[path]['post']['produces'] = ["application/json"]

    pathObj[path]['post']['responses'] = {
        "200" : {
            "description" : "OK",
        },
        "401" : {
            "description" : "Unauthorized"
        }
    }
    return pathObj

def generatePut(path, pathObj, obj, returnName):
    try:
        nameObj = obj['spec']['names']['singular']
    except:
        nameObj = "undefined"

    pathObj[path + "/{name}"]['put']['tags'] = [nameObj]

    pathObj[path + "/{name}"]['put']['summary'] = "Update " + nameObj + " identified by {name} with body parameters"

    pathObj[path + "/{name}"]['put']['description'] = "Update " + nameObj + " identified by {name} with body parameters"

    pathObj[path + "/{name}"]['put']['operationId'] = "update" + nameObj[0:1].upper() + nameObj[1:]

    pathObj[path + "/{name}"]['put']['parameters'] =  [
        {
            "in": "body",
            "name" : "body",
            "required" : True,
            "description" : "Parameters to use to update " + nameObj + " identified by {name}",
            "schema"  : {
                "$ref" : "#/definitions/" + returnName #+ nameObj
            }
        },
        { 
            "in": "path",
            "name": "NameNamespace",
            "description" : "Name of namespace to select",
            "required" : True,
            "type" : "string" 
        },
        { 
            "in": "path",
            "name": "name",
            "description" : "Name of " + nameObj + " to update",
            "required" : True,
            "type" : "string" 
        }

    ]

    pathObj[path + "/{name}"]['put']['produces'] = ["application/json"]

    pathObj[path + "/{name}"]['put']['responses'] = {
        "200" : {
            "description" : "OK",
        },
        "401" : {
            "description" : "Unauthorized"
        }
    }
    # for obj["spec"]["versions"][0]["schema"]["openAPIV3Schema"]["properties"]
    return pathObj

def generatePath(obj):
    path = ""
    pathObj = {}
    try:
        if obj['spec']['scope'] == 'Namespaced':
            path += '/namespaces/{NameNamespace}/'
    except:
        path = path
    try:
        path += obj['spec']['names']['plural']
    except:
        print('Error: cant provide a valid name')
        exit(0)
    pathObj[path] = {}
    pathObj[path + '/{name}'] = {}
    return path, pathObj

def parseFile(file):
    f = open(yamlFolder + file, 'r')
    text = f.read()
    f.close()
    obj = yaml.load(text, Loader=yaml.FullLoader)
    path, pathObj = generatePath(obj)
    pathObj = generateMethod(path, pathObj)
    pathObj = generateGet(path, pathObj, obj, obj['spec']['names']['kind'])
    pathObj = generatePost(path, pathObj, obj, obj['spec']['names']['kind'])
    pathObj = generatePut(path, pathObj, obj, obj['spec']['names']['kind'])
    pathObj = generateDelete(path, pathObj, obj, obj['spec']['names']['kind'])
    return pathObj, path

def setBasePath(dList):
    f = open(yamlFolder + dList[0], 'r')
    text = f.read()
    f.close()
    obj = yaml.load(text, Loader=yaml.FullLoader)
    return "/apis/" + obj['spec']['group'] + '/' + obj['spec']['versions'][0]['name'] + '/'

def readFiles(dList):
    final = {}
    for file in dList:

        pathoObj, path = parseFile(file)
        final[path] = pathoObj[path]
        final[path + "/{name}"] = pathoObj[path + "/{name}"]
    return final

def getBaseConfig(conf):
    f = open(conf)
    text = f.read()
    f.close()
    return yaml.load(text, Loader=yaml.FullLoader)

dList = getFiles()
finalfinal = getBaseConfig(conf)
finalfinal['basePath'] = setBasePath(dList)
finalfinal['paths'] = readFiles(dList)
finalfinal['definitions'] = createDefinitions()

out = toHtml(finalfinal)
f = open('./docs/documentation.yaml','w+')
f.write(yaml.dump(finalfinal))

        