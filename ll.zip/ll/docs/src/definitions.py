import os
import yaml

yamlFolder = './config/crd/bases/'

def getFiles(folder):
    try:
        directoryList = os.listdir(folder)
    except:
        print('Error: yaml folder not found in ' + yamlFolder)
        exit(0)
    i = 0
    while i < len(directoryList):
        if ".yaml" not in directoryList[i]:
            del directoryList[i]
        else:
            i += 1
    return directoryList

def generatePath(obj):
    path = ""
    pathObj = {}
    try:
        if obj['spec']['scope'] == 'Namespaced':
            path += 'namespace/{NameNamespace}/'
    except:
        path = path
    try:
        path += obj['spec']['names']['plural']
    except:
        print('Error: cant provide a valid name')
        exit(0)
    path = obj['spec']['group'] + '/' + obj['spec']['versions'][0]['name'] + '/' + path
    pathObj[path] = {}
    return pathObj

def readFile(file):
    f = open(yamlFolder + file, 'r')
    text = f.read()
    f.close()
    obj = yaml.load(text, Loader=yaml.FullLoader)
    return obj

def readSample(file):
    f = open( file, 'r')
    text = f.read()
    f.close()
    obj = yaml.load(text, Loader=yaml.FullLoader)
    return obj

def findSample(name):
    myexamples = getFiles('config/samples')
    for i in range(len(myexamples)):
        obj = readSample('config/samples/' + myexamples[i])
        # print(obj)
        if 'kind' in obj and obj['kind'] == name:
            return obj



def addSample(sample, obj):
    if not sample: 
        return obj
    for key in sample.keys():
        if not sample: 
            continue
        if type(sample[key]) is dict:
            try:
                obj[key]['properties'] = addSample(sample[key], obj[key]['properties'])
            except:
                obj[key]['example'] = sample[key]
        else:
            obj[key]['example'] = sample[key]
    return obj 

def generateDefinitions(obj, final):

    name = obj['spec']['names']['kind']

    sample = findSample(name)
    

    properties = obj['spec']['versions'][0]['schema']['openAPIV3Schema']['properties']
    properties = addSample(sample, properties)

    final[name] = {}
    final[name]['type'] = 'object'

    final[name]['properties'] = properties
    return final

def  createDefinitions():
    final = {}
    myfiles = getFiles(yamlFolder)
    for file in myfiles:
        final = generateDefinitions(readFile(file), final)

    return final