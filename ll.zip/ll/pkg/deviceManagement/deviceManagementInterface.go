package devicemanagement

import (
	"context"

	"github.com/go-logr/logr"
	"github.com/opencord/device-management-interface/go/dmi"
)

type deviceManagmentInterface struct {
	ctx                            context.Context
	log                            logr.Logger
	DeviceSoftwareManagementClient dmi.NativeSoftwareManagementServiceClient
}
