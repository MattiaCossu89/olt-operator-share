package devicemanagement

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/go-logr/logr"
	"github.com/gorilla/mux"
	"github.com/opencord/device-management-interface/go/dmi"
	"google.golang.org/grpc"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	"sigs.k8s.io/controller-runtime/pkg/log/zap"
)

var logger logr.Logger = zap.New()

func RunDeviceManagementGateway() error {

	port := env.ReadEnv("DEVICE_MANAGEMENT_WEBSERVER_PORT", "8080")
	dmiAddress := env.ReadEnv("DEVICE_MANAGER_ADDRESS", "")

	router := mux.NewRouter()

	conn, err := grpc.DialContext(context.Background(), dmiAddress, grpc.WithInsecure(), grpc.WithStreamInterceptor(nil))
	if err != nil {
		return err
	}
	d := deviceManagmentInterface{
		ctx:                            context.Background(),
		log:                            logger,
		DeviceSoftwareManagementClient: dmi.NewNativeSoftwareManagementServiceClient(conn),
	}

	//endpoints
	router.HandleFunc("/olt/software-update/{namespace}/{name}", d.handleSoftwareUpdateRequest)

	logger.Info(fmt.Sprintf("starting server on: %s", port))
	err = http.ListenAndServe("0.0.0.0:"+port, router)
	if err != nil {
		logger.Error(err, "Impossible to start device management gateway")
		return err
	}
	return nil
}

func (d *deviceManagmentInterface) handleSoftwareUpdateRequest(w http.ResponseWriter, r *http.Request) {
	//Discard wrong method call
	if r.Method != http.MethodPost {
		http.Error(w, "Methods supported: POST", http.StatusMethodNotAllowed)
		return
	}

	params := mux.Vars(r)
	namespace := params["namespace"]
	name := params["name"]

	var firmwareUpdateRequest FirmwareUpdateRequest

	// Try to decode the request body into the struct. If there is an error,
	// respond to the client with the error message and a 400 status code.
	err := json.NewDecoder(r.Body).Decode(&firmwareUpdateRequest)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	//Check for input
	err = d.firmwareUpdateInputChecker(firmwareUpdateRequest)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	err = d.FirmwareUpdate(name, namespace, &firmwareUpdateRequest)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	fmt.Fprintf(w, "Successfully updated firmware for device: %s", name)
}
