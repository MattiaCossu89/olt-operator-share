package devicemanagement

import "github.com/opencord/device-management-interface/go/dmi"

type FirmwareUpdateRequest struct {
	Mode Mode `json:"mode"`

	ArtefactSourceLocation string `json:"artefactSourceLocation"`

	ArtefactType ArtefactType `json:"artefactType"`

	Name string `json:"name"`

	Version string `json:"version"`
}

type ArtefactType int32

const (
	ArtefactTypeFIRMWARE                 ArtefactType = 0
	ArtefactTypePERSISTED_CONFIG         ArtefactType = 1
	ArtefactTypeOPERATING_SYSTEM         ArtefactType = 2
	ArtefactTypeAPPLICATION_STACK        ArtefactType = 3
	ArtefactTypeREMOTE_TERMINAL_SOFTWARE ArtefactType = 4
)

func (e ArtefactType) String() string {
	switch e {
	case ArtefactTypeFIRMWARE:
		return "FIRMWARE"
	case ArtefactTypePERSISTED_CONFIG:
		return "PERSISTED_CONFIG"
	case ArtefactTypeOPERATING_SYSTEM:
		return "OPERATING_SYSTEM"
	case ArtefactTypeAPPLICATION_STACK:
		return "APPLICATION_STACK"
	case ArtefactTypeREMOTE_TERMINAL_SOFTWARE:
		return "REMOTE_TERMINAL_SOFTWARE"
	}
	return "unknown"
}

type Mode int32

const (
	ModePREPARE Mode = 0
	ModeEXECUTE Mode = 1
)

func (e Mode) String() string {
	switch e {
	case ModePREPARE:
		return "PREPARE"
	case ModeEXECUTE:
		return "EXECUTE"
	}
	return "unknown"
}

func (da *deviceManagmentInterface) newDownloadImageRequest(deviceUUID, imageName, imageVersion, imageLocation string) *dmi.DownloadImageRequest {
	return &dmi.DownloadImageRequest{
		DeviceUuid: &dmi.Uuid{
			Uuid: deviceUUID,
		},
		ImageInfo: &dmi.ImageInformation{
			Image: &dmi.ImageVersion{
				ImageName: imageVersion, // Currently, adtran DM maintains image status as '<image_name:\"sdx6320-RL-20.9-14\" version:\"unknown\" >'
				Version:   "",
			},
			ImageUrl: imageLocation,
		},
	}
}

func (d *deviceManagmentInterface) newActivateImageRequest(uuid string) *dmi.HardwareID {
	return &dmi.HardwareID{
		Uuid: &dmi.Uuid{
			Uuid: uuid,
		},
	}
}
