package devicemanagement

import "fmt"

func (d *deviceManagmentInterface) firmwareUpdateInputChecker(input FirmwareUpdateRequest) error {
	err := ""
	if input.ArtefactSourceLocation == "" {
		err += "ArtefactSourceLocation can't be empty\n"
	}
	if input.ArtefactType != ArtefactTypeFIRMWARE {
		err += "ArtefactType must be 0 for firmware update request \n"
	}
	if input.Mode != ModeEXECUTE && input.Mode != ModePREPARE {
		err += "Mode must be 0 for execute or 1 for prepare, value not supported \n"
	}
	if input.Name == "" {
		err += "Firmware name can't be empty \n"
	}
	if input.Version == "" {
		err += "Firmware version can't be empty\n"
	}

	if err != "" {
		return fmt.Errorf(err)
	}
	return nil
}
