package devicemanagement

import (
	"fmt"
	"strings"

	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

func (d *deviceManagmentInterface) updateCredentials(event *FirmwareUpdateRequest) error {
	user := env.ReadEnv("SFTP_USERNAME", "")
	accessToken := env.ReadEnv("SFTP_TOKEN", "")

	location := strings.Split(event.ArtefactSourceLocation, "//")

	if len(location) != 2 {
		// source location not of form- <protocol>://<image-location>
		// Valid artefact source location example:
		// sftp://127.0.0.1:2122/home/a4/sdx6320-RL-21.3-22-onie_inst.bin
		return fmt.Errorf("unsupported artefact source location format, required form is <protocol>://<image-location>")
	}

	locationWithCredentials := fmt.Sprintf("%s//%s:%s@%s", location[0], user, accessToken, location[1])
	event.ArtefactSourceLocation = locationWithCredentials

	return nil
}
