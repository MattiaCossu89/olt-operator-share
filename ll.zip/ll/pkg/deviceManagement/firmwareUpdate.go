package devicemanagement

import (
	"context"
	"fmt"
	"io"
	"time"

	"github.com/opencord/device-management-interface/go/dmi"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

const (
	internalError       = "Internal Error"
	imageActionDownload = "Image-Download"
	imageActionActivate = "Image-Activate"
)

func (d *deviceManagmentInterface) FirmwareUpdate(name string, namespace string, request *FirmwareUpdateRequest) error {
	clientSet, err := controllers_utils.GetClientSet()
	if err != nil {
		d.log.Error(err, err.Error())
		return err
	}

	oltClient := clientSet.Olts(context.Background(), namespace)

	olt, err := oltClient.Get(name, v1.GetOptions{})
	if err != nil {
		d.log.Error(err, err.Error())
		return err
	}

	uuid := olt.Status.DeviceId

	activeImage, standbyImage, err := d.getSoftwareVersionWithRetry(context.Background(), uuid)
	if err != nil {
		d.log.Error(err, err.Error())
	}

	err = d.updateCredentials(request)
	if err != nil {
		d.log.Error(err, err.Error())
		return err
	}

	switch request.Mode {
	case ModePREPARE:
		//Produce 'ArtefactUpdateStarted' event
		d.log.Info(fmt.Sprintf("Olt software update in mode: PREPARE  for device id:%s, just started", uuid))
		err := d.firmwarePrepare(d.ctx, request, standbyImage, uuid)
		if err != nil {
			return err
		}
		d.log.Info(fmt.Sprintf("Olt software update in mode: PREPARE  for device id:%s, successfully concluded", uuid))
		return nil
	case ModeEXECUTE:
		//Produce 'ArtefactUpdateStarted' event
		d.log.Info(fmt.Sprintf("Olt software update in mode: EXECUTE  for device id:%s, just started", uuid))
		err := d.firmwareExecute(d.ctx, request, standbyImage, activeImage, uuid)
		if err != nil {
			return err
		}
		d.log.Info(fmt.Sprintf("Olt software update in mode: EXECUTE  for device id:%s, successfully concluded", uuid))
		return nil
	default:
		err := fmt.Errorf("mode %s not supported", request.Mode)
		d.log.Error(err, err.Error())
		return err
	}
}

func (d *deviceManagmentInterface) firmwarePrepare(ctx context.Context, request *FirmwareUpdateRequest, presentStdbySW *dmi.ImageVersion, uuid string) error {
	if !d.isImageUpdateNeeded(request.Name, request.Version, presentStdbySW) {
		d.log.Info("SW image already present")
		return nil
	}

	err := d.downloadImageToOlt(ctx, uuid, request)
	if err != nil {
		err := fmt.Errorf("image download to OLT failed")
		d.log.Error(err, err.Error())
		return err
	}

	return nil
}

func (d *deviceManagmentInterface) firmwareExecute(ctx context.Context, request *FirmwareUpdateRequest, presentStdbySW, presentActiveSW *dmi.ImageVersion, uuid string) error {
	// Check if the activation is needed
	if !d.isImageUpdateNeeded(request.Name, request.Version, presentActiveSW) {
		err := fmt.Errorf("SW image already present in active partition %s:%s for device id:%s", request.Name, request.Version, uuid)
		d.log.Error(err, err.Error())
		return err
	}

	//Check if the image is already present in the standby
	if d.isImageUpdateNeeded(request.Name, request.Version, presentStdbySW) {
		// The required image is not present in the standby partition of the OLT
		// Download the required SW on the OLT, waiting for download to finish
		d.log.Info("Target SW not present in the standby")
		if err := d.downloadImageToOlt(ctx, uuid, request); err != nil {
			d.log.Error(err, err.Error())
			return err
		}
	}

	err := d.activateImageOnOlt(ctx, request, uuid)
	if err != nil {
		d.log.Error(err, fmt.Sprintf("Image activation on OLT failed for device id:%s", uuid))
		return err
	}

	return nil
}

func (d *deviceManagmentInterface) downloadImageToOlt(ctx context.Context, uuid string, request *FirmwareUpdateRequest) error {
	stream, err := d.DeviceSoftwareManagementClient.DownloadImage(ctx,
		d.newDownloadImageRequest(uuid, request.Name, request.Version, request.ArtefactSourceLocation))
	if err != nil {
		return err
	}

	waitChan := make(chan error, 1)

	go d.receiveImageStatus(ctx, imageActionDownload, request.Name, stream, waitChan)

	return <-waitChan
}

func (d *deviceManagmentInterface) activateImageOnOlt(ctx context.Context, request *FirmwareUpdateRequest, uuid string) error {
	stream, err := d.DeviceSoftwareManagementClient.ActivateImage(ctx, d.newActivateImageRequest(uuid))
	if err != nil {
		return err
	}

	waitChan := make(chan error, 1)

	go d.receiveImageStatus(ctx, imageActionActivate, request.Name, stream, waitChan)
	return <-waitChan
}

func (d *deviceManagmentInterface) receiveImageStatus(ctx context.Context, action, imageName string, stream dmi.NativeSoftwareManagementService_DownloadImageClient, waitChan chan error) {
	d.log.Info("Waiting to receive Image Status")

	for {
		response, streamErr := stream.Recv()
		if streamErr != nil {
			if streamErr == io.EOF {
				err := fmt.Errorf("action %s on the OLT is completed", action)
				d.log.Error(err, err.Error())
				break
			}
			err := fmt.Errorf("error occurred while receiving %s stream response: %s", action, streamErr.Error())
			d.log.Error(err, err.Error())
			// store image status
			waitChan <- streamErr
			return
		}

		response.Description = imageName
		d.log.Info("Received image status")

		if response.Status != dmi.Status_OK_STATUS {
			err := fmt.Errorf("action %s failed", action)
			d.log.Error(err, err.Error())
			waitChan <- fmt.Errorf("action %s failed, reason %s", action, response.Reason)
			return
		}
	}
	waitChan <- nil
}

func (d *deviceManagmentInterface) getSoftwareVersionWithRetry(ctx context.Context, uuid string) (
	activeImage *dmi.ImageVersion,
	standbyImage *dmi.ImageVersion,
	err error,
) {
	delay := env.ReadEnv("GET_SW_VERSION_DELAY", "30s")
	retry := env.ReadEnvInt("GET_SW_VERSION_MAX_RETRY", 1)
	apiDelay, err := time.ParseDuration(delay)
	if err != nil {
		return
	}

	var reason dmi.GetSoftwareVersionInformationResponse_Reason

	for i := 0; i < retry; i++ {
		activeImage, standbyImage, reason, err = d.getSoftwareVersion(ctx, uuid)
		if reason == dmi.GetSoftwareVersionInformationResponse_DEVICE_UNREACHABLE {
			time.Sleep(apiDelay)
			continue
		}
		break
	}
	return
}

func (d *deviceManagmentInterface) getSoftwareVersion(ctx context.Context, uuid string) (
	activeImage *dmi.ImageVersion,
	standbyImage *dmi.ImageVersion,
	reason dmi.GetSoftwareVersionInformationResponse_Reason,
	err error,
) {
	response, err := d.DeviceSoftwareManagementClient.GetSoftwareVersion(ctx, &dmi.HardwareID{
		Uuid: &dmi.Uuid{
			Uuid: uuid,
		},
	})
	if err != nil {
		return
	}
	if response.Status != dmi.Status_OK_STATUS {
		reason = response.Reason
		err = fmt.Errorf("got %s response status with reason %s", response.Status, response.Reason)
		return
	}

	d.log.Info("Got software versions from DM")

	reason = response.Reason
	activeImage = response.GetInfo().ActiveVersions[0]
	standbyImage = response.GetInfo().StandbyVersions[0]
	return
}

func (d *deviceManagmentInterface) isImageUpdateNeeded(targetImageName, targetImageVersion string, currentSW *dmi.ImageVersion) bool {
	// ImageVersion Format: <image_name: "NOS" version: "sdx6320-RL-20.9-14" >
	if targetImageName == currentSW.ImageName && targetImageVersion == currentSW.Version {
		return false
	}
	return true
}
