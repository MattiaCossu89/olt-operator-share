package influxdb

import (
	"time"

	influxdb2 "github.com/influxdata/influxdb-client-go/v2"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

type InfluxdbClient struct {
	Token    string
	Bucket   string
	Org      string
	Endpoint string
}

func NewClient() *InfluxdbClient {
	client := &InfluxdbClient{
		Token:    env.ReadEnv("INFLUXDB_TOKEN", "I5mlm2bvSc5H8EgN61vUDrEQ4DzyKizFlXMXbGm3-1fMGHY9EEdgA_f8eytveVZG_U_piaGTYVRF3AmLdx9qSA=="),
		Bucket:   env.ReadEnv("INFLUXDB_BUCKET", "events"),
		Org:      env.ReadEnv("INFLUXDB_ORG", "tim"),
		Endpoint: env.ReadEnv("INFLUXDB_ENDPOINT", "http://influxdb-service.olt-operator-system:8086"),
	}
	return client
}

//metric in type / value
//omettere value
//move devide in label

func (c *InfluxdbClient) WriteMetric(device, deviceId, metricName string, metricValue float64) error {

	client := influxdb2.NewClient(c.Endpoint, c.Token)

	writeAPI := client.WriteAPI(c.Org, c.Bucket)

	p := influxdb2.NewPoint("metrics",
		map[string]string{
			"deviceId": deviceId,
			"name":     metricName,
			"device":   device,
		},
		map[string]interface{}{
			"value": metricValue,
		},
		time.Now())

	writeAPI.WritePoint(p)
	//writeAPI.WriteRecord(fmt.Sprintf("metric,device=%s deviceId=%s value=%s",device, deviceId, metric))
	// Flush writes
	writeAPI.Flush()
	defer client.Close()
	return nil
}
