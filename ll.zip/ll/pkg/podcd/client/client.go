package client

import (
	"bytes"
	"encoding/json"
	"net/http"

	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

type Client struct {
	client    *http.Client
	serverURL string
}

type Characteristic struct {
	Name  string `json:"name,omitempty"`
	Value string `json:"value,omitempty"`
}

type Resource map[string][]Characteristic

func NewClient() *Client {
	client := &http.Client{}
	return &Client{
		client:    client,
		serverURL: env.ReadEnv("PODCD_ENDPOINT", "http://pod-cd.voltha:8081"),
	}
}

func (c *Client) AddResource(item *Resource) (*http.Response, error) {
	b, err := json.Marshal(item)
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequest("POST", c.serverURL+"/api/neids", bytes.NewBuffer(b))
	if err != nil {
		return nil, err
	}
	res, err := c.client.Do(req)
	if err != nil {
		return nil, err
	}

	return res, nil
}

func (c *Client) RemoveResource(id string) (*http.Response, error) {
	model := []string{id}
	b, err := json.Marshal(model)
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequest("DELETE", c.serverURL+"/api/neids", bytes.NewBuffer(b))
	if err != nil {
		return nil, err
	}
	res, err := c.client.Do(req)
	if err != nil {
		return nil, err
	}

	return res, nil
}
