package endpoints

import (
	"fmt"
	"net/http"

	"github.com/go-logr/logr"
	"github.com/gorilla/mux"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/podcd"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/sadis"
	"sigs.k8s.io/controller-runtime/pkg/log/zap"
)

var logger logr.Logger = zap.New()

func Run() {
	podcd := podcd.NewPodCDSim()
	sadis := sadis.NewEndpointManager()

	logger.Info("Starting endpoints simulator")

	router := mux.NewRouter().StrictSlash(true)
	//Podcd endpoints
	router.HandleFunc("/v2/logicalResource", podcd.GetLogicalResources)
	router.HandleFunc("/v2/logicalResource/{ne_id}", podcd.FetchLogicalResources)
	router.HandleFunc("/api/neids", podcd.ChangeNetworkResource)
	router.HandleFunc("/voltha/add/{ztpId}", podcd.AddAndEnableVoltha)

	//Sadis endpoints
	router.HandleFunc("/sadisEntries/{key}", sadis.GetHandler)
	logger.Info(fmt.Sprintf("starting server on: %s", podcd.Address))
	err := http.ListenAndServe(podcd.Address, router)
	if err != nil {
		logger.Error(err, "Impossible to start podcd endpoint")
	}
}
