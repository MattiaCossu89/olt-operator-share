package podcd

import (
	"encoding/json"
	"sync"
	"time"

	"github.com/go-openapi/strfmt"
)

// LogicalResource LogicalResource Logic resource is a type of resource that describes the common set of attributes shared by all concrete logical resources (e.g. TPE, MSISDN, IP Addresses) in the inventory.
// swagger:model LogicalResource
type LogicalResource struct {

	// Indicates<b> </b>the base type of the resource. For resources pf type 'Equipment', baseType can be 'PhysicalResource'.
	AtBaseType string `json:"@baseType,omitempty"`

	// This field provides a link to the schema describing this REST resource
	AtSchemaLocation string `json:"@schemaLocation,omitempty"`

	// Indicates the type of resource. For physical resource this will be 'Equipment', For logical Resource this can be 'Resource Function' , 'MSISDN', 'IP Address'.
	AtType string `json:"@type,omitempty"`

	// Category of the concrete resource. e.g Gold, Silver for MSISDN concrete resource
	Category string `json:"category,omitempty"`

	// characteristic
	Characteristic []*ResourceCharacteristic `json:"characteristic"`

	// free-text description of the resource
	Description string `json:"description,omitempty"`

	// A date time( DateTime). The date till the resource is effective
	// Format: date-time
	// Format: date-time
	EndDate time.Time `json:"endDate,omitempty"`

	// The URI for the object itself.
	Href string `json:"href,omitempty"`

	// Identifier of an instance of the resource. Required to be unique within the resource type. Used in URIs as the identifier for specific instances of a type.
	ID string `json:"id,omitempty"`

	// The life cycle state of the resource.
	LifecycleState string `json:"lifecycleState,omitempty"`

	// A string used to give a name to the resource
	Name string `json:"name,omitempty"`

	// note
	Note []*Note `json:"note"`

	// party role
	PartyRole []*PartyRoleRef `json:"partyRole"`

	// related party
	RelatedParty []*RelatedPartyRef `json:"relatedParty"`

	// resource relationship
	ResourceRelationship []*ResourceRelationship `json:"resourceRelationship"`

	// A date time( DateTime). The date from which the resource is effective
	// Format: date-time
	// Format: date-time
	StartDate time.Time `json:"startDate,omitempty"`

	// the value of the logical resource. E.g '0746712345' for MSISDN's
	Value string `json:"value,omitempty"`

	// A field that identifies the specific version of an instance of a resource.
	Version string `json:"version,omitempty"`

	// place
	Place *Place `json:"place,omitempty"`
}

//Place Place Place defines the places where the products are sold or delivered.
// swagger:model Place
type Place struct {

	// A string characterizing an address (for instance a formatted address or an identifier taken from an address database or an address API)
	Address string `json:"address,omitempty"`

	// A url providing a map for localizing the place
	GeoLocationURL string `json:"geoLocationUrl,omitempty"`

	// A user-friendly name for the place, such as "Paris Store", "London Store", "Main Home".
	Name string `json:"name,omitempty"`

	// Role of the place (for instance: 'home delivery', 'shop retrieval')
	Role string `json:"role,omitempty"`
}

//PartyRoleRef PartyRoleRef Party role reference. A party role represents the part played by a party in a given context.
// swagger:model PartyRoleRef
type PartyRoleRef struct {

	// Reference of the product
	Href string `json:"href,omitempty"`

	// Unique identifier of the product
	ID string `json:"id,omitempty"`

	// The name of the referred party role.
	Name string `json:"name,omitempty"`

	// The identifier of the engaged party that is linked to the PartyRole object.
	PartyID string `json:"partyId,omitempty"`

	// The name of the engaged party that is linked to the PartyRole object.
	PartyName string `json:"partyName,omitempty"`
}

//ResourceRelationship ResourceRelationship resource relationship
// swagger:model ResourceRelationship
type ResourceRelationship struct {

	// Linked Resources to the one instantiate, it can be :
	// "reliesOn" if the Resource needs another already owned Resource to rely on
	// "targets" or "isTargeted" (depending on the way of expressing the link) for any other kind of links that may be useful
	Type        string      `json:"type,omitempty"`
	ResourceRef ResourceRef `json:"resourceRef"`
}

type ResourceRef struct {
	ID   string `json:"id"`
	Type string `json:"type"`
}

//RelatedPartyRef RelatedPartyRef RelatedParty reference. A related party defines party or party role linked to a specific entity.
// swagger:model RelatedPartyRef
type RelatedPartyRef struct {

	// Reference of the related party, could be a party reference or a party role reference
	Href string `json:"href,omitempty"`

	// Unique identifier of a related party
	ID string `json:"id,omitempty"`

	// Name of the related party
	Name string `json:"name,omitempty"`

	// Role of the related party.
	Role string `json:"role,omitempty"`

	// valid for
	ValidFor *TimePeriod `json:"validFor,omitempty"`
}

//TimePeriod TimePeriod A base / value business entity used to represent a period of time between two timepoints.
// swagger:model TimePeriod
type TimePeriod struct {

	// An instant of time, ending at the TimePeriod.
	// Format: date-time
	// Format: date-time
	EndDateTime time.Time `json:"endDateTime,omitempty"`

	// An instant of time, starting at the TimePeriod
	// Format: date-time
	// Format: date-time
	StartDateTime time.Time `json:"startDateTime,omitempty"`
}

//Note Note Extra information about the ticket or a product order
// swagger:model Note
type Note struct {

	// Author of the note
	Author string `json:"author,omitempty"`

	// Date of the note
	// Format: date-time
	// Format: date-time
	Date time.Time `json:"date,omitempty"`

	// Text of the note
	Text string `json:"text,omitempty"`
}

//ResourceCharacteristic ResourceCharacteristic resource characteristic
// swagger:model ResourceCharacteristic
type ResourceCharacteristic struct {
	// Name of the characteristic
	Name string `json:"name,omitempty"`
	// Value of the characteristic
	Value string `json:"value,omitempty"`
}

func (rc *ResourceCharacteristic) String() string {
	data, err := json.Marshal(rc)
	if err != nil {
		logger.Info(err.Error())
	}

	return string(data)
}

//PodCDSim simulates the pod-cd
type PodCDSim struct {
	Address          string
	resourceMap      map[string][]*ResourceCharacteristic
	physicalResource sync.Map
	configPath       string
	kubeManager      *PodcdKubeManager
}

//ActorTaskEventExtended actor test event struct
// swagger:model ActorTaskEventExtended
type ActorTaskEventExtended struct {

	// metadata
	Metadata *EventsMetadataDescriptor `json:"Metadata,omitempty"`

	// notification data
	NotificationData map[string]interface{} `json:"notificationData,omitempty"`

	// notification data binary
	NotificationDataBinary []uint8 `json:"NotificationDataBinary"`
}

//EventsMetadataDescriptor events metadata descriptor
// swagger:model EventsMetadataDescriptor
type EventsMetadataDescriptor struct {

	// notification data specification version
	NotificationDataSpecificationVersion int32 `json:"NotificationDataSpecificationVersion,omitempty"`

	// specification version
	SpecificationVersion int32 `json:"SpecificationVersion,omitempty"`

	// creation time
	CreationTime string `json:"CreationTime,omitempty"`

	// description
	Description string `json:"Description,omitempty"`

	// notification Id
	NotificationID string `json:"NotificationId,omitempty"`

	// notification type
	NotificationType string `json:"NotificationType,omitempty"`

	// occurred time
	OccurredTime string `json:"OccurredTime,omitempty"`

	// source object identifier
	SourceObjectIdentifier string `json:"SourceObjectIdentifier,omitempty"`

	// source object name
	SourceObjectName string `json:"SourceObjectName,omitempty"`

	// source object type
	SourceObjectType string `json:"SourceObjectType,omitempty"`

	// trace Id
	TraceID string `json:"TraceId,omitempty"`

	// triggering trace ids
	TriggeringTraceIds []string `json:"TriggeringTraceIds"`

	// notification class
	NotificationClass NotificationClassEnum `json:"NotificationClass,omitempty"`

	// perceived severity
	PerceivedSeverity PerceivedSeverityType `json:"PerceivedSeverity,omitempty"`

	// security
	Security *EventsNotificationSecurity `json:"Security,omitempty"`
}

//PhysicalResource a dummy structure to store the physical resource
type PhysicalResource struct {

	// Indicates<b> </b>the base type of the resource. For resources pf type 'Equipment', baseType can be 'PhysicalResource'.
	AtBaseType string `json:"@baseType,omitempty"`

	// This field provides a link to the schema describing this REST resource
	AtSchemaLocation string `json:"@schemaLocation,omitempty"`

	// Indicates the type of resource. For physical resource this will be 'Equipment', For logical Resource this can be 'Resource Function' , 'MSISDN', 'IP Address'.
	AtType string `json:"@type,omitempty"`

	// Category of the concrete resource. e.g Gold, Silver for MSISDN concrete resource
	Category string `json:"category,omitempty"`

	// characteristic
	Characteristic []*ResourceCharacteristic `json:"characteristic"`

	// free-text description of the resource
	Description string `json:"description,omitempty"`

	// A date time( DateTime). The date till the resource is effective
	// Format: date-time
	// Format: date-time
	EndDate strfmt.DateTime `json:"endDate,omitempty"`

	// The URI for the object itself.
	Href string `json:"href,omitempty"`

	// Identifier of an instance of the resource. Required to be unique within the resource type. Used in URIs as the identifier for specific instances of a type.
	ID string `json:"id,omitempty"`

	// The life cycle state of the resource.
	LifecycleState string `json:"lifecycleState,omitempty"`

	// This is a string attribute that defines the date of manufacture of this item in the fixed format "dd/mm/yyyy". This is an optional attribute.
	// Format: date-time
	// Format: date-time
	ManufactureDate strfmt.DateTime `json:"manufactureDate,omitempty"`

	// A string used to give a name to the resource
	Name string `json:"name,omitempty"`

	// note
	Note []*Note `json:"note"`

	// party role
	PartyRole []*PartyRoleRef `json:"partyRole"`

	// This defines the current power status of the hardware item. Values include:
	//
	// 0: Unknown
	// 1: Not Applicable
	// 2: No Power Applied
	// 3: Full Power Applied
	// 4: Power Save - Normal
	// 5: Power Save - Degraded
	// 6: Power Save - Standby
	// 7: Power Save - Critical
	// 8: Power Save - Low Power Mode
	// 9: Power Save - Unknown
	// 10: Power Cycle
	// 11: Power Warning
	// 12: Power Off
	PowerState string `json:"powerState,omitempty"`

	// related party
	RelatedParty []*RelatedPartyRef `json:"relatedParty"`

	// resource relationship
	ResourceRelationship []*ResourceRelationship `json:"resourceRelationship"`

	// This is a string that represents a manufacturer-allocated number used to identify different instances of the same hardware item. The ModelNumber and PartNumber attributes are used to identify different types of hardware items. This is a REQUIRED attribute.
	SerialNumber string `json:"serialNumber,omitempty"`

	// A date time( DateTime). The date from which the resource is effective
	// Format: date-time
	// Format: date-time
	StartDate strfmt.DateTime `json:"startDate,omitempty"`

	// A field that identifies the specific version of an instance of a resource.
	Version string `json:"version,omitempty"`

	// This is a string that identifies the version of this object. This is an optional attribute.
	VersionNumber string `json:"versionNumber,omitempty"`

	//Place
	Place *Place `json:"place,omitempty"`
}

//NotificationClassEnum notification class enum
// swagger:model NotificationClassEnum
type NotificationClassEnum int32

//EventsNotificationSecurity events notification security
// swagger:model EventsNotificationSecurity
type EventsNotificationSecurity struct {

	// type
	Type NotificationSecurityEnum `json:"Type,omitempty"`
}

//NotificationSecurityEnum notification security enum
// swagger:model NotificationSecurityEnum
type NotificationSecurityEnum int32

//PerceivedSeverityType perceived severity type
// swagger:model PerceivedSeverityType
type PerceivedSeverityType int32
