package podcd

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/go-logr/logr"
	"github.com/google/uuid"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/voltha/commands"
	"sigs.k8s.io/controller-runtime/pkg/log/zap"

	"github.com/gorilla/mux"
	"github.com/opencord/voltha-protos/v4/go/voltha"
)

var logger logr.Logger = zap.New()

//NewPodCDSim returns new instance of PodCDSim
func NewPodCDSim() *PodCDSim {
	return &PodCDSim{
		Address:     "0.0.0.0:" + env.ReadEnv("PODCD_PORT", "18808"),
		resourceMap: make(map[string][]*ResourceCharacteristic),
		kubeManager: NewPodcdKubeManager(),
	}
}

func (psim *PodCDSim) UpdateResourcesCache(configPath string) {
	logger.Info(fmt.Sprintf("will updated internal db from path %s", configPath))
	byteContent, err := ioutil.ReadFile(filepath.Clean(configPath))
	if err != nil {
		panic(err.Error())
	}
	err = json.Unmarshal(byteContent, &psim.resourceMap)
	if err != nil {
		panic(err)
	}

	logger.Info(fmt.Sprintf("successfully read %d db items", len(psim.resourceMap)))
	logger.Info(fmt.Sprintf("internal db items: %+v", psim.resourceMap))
}

func (psim *PodCDSim) Run() {
	logger.Info("Starting podcd sim")

	router := mux.NewRouter().StrictSlash(true)
	router.HandleFunc("/v2/logicalResource", psim.GetLogicalResources)
	router.HandleFunc("/v2/logicalResource/{ne_id}", psim.FetchLogicalResources)
	router.HandleFunc("/api/neids", psim.ChangeNetworkResource)
	router.HandleFunc("/voltha/add/{ztpId}", psim.AddAndEnableVoltha)
	logger.Info(fmt.Sprint("starting server on: ", psim.Address))
	logger.Info(fmt.Sprintf("starting server on: %s", psim.Address))
	err := http.ListenAndServe(psim.Address, router)
	if err != nil {
		logger.Error(err, "Impossible to start podcd endpoint")
	}
}

func (psim *PodCDSim) AddAndEnableVoltha(w http.ResponseWriter, r *http.Request) {

	switch r.Method {
	case "POST":
		vars := mux.Vars(r)
		ztpId := vars["ztpId"]
		clientSet, err := controllers_utils.GetClientSet()
		if err != nil {
			http.Error(w, "Is not possible to initialize clientSet",
				http.StatusInternalServerError)
			logger.Error(err, "Is not possible to initialize clientSet")
			return
		}
		oltClient := clientSet.Olts(context.TODO(), "olt-operator-system")
		olts, err := oltClient.List(v1.ListOptions{})
		if err != nil {
			http.Error(w, "Error while retriving Olts",
				http.StatusInternalServerError)
			logger.Error(err, "Error while retriving Olts")
			return
		}

		found := false
		olt := v1alpha1.Olt{}
		for _, o := range olts.Items {
			if o.Spec.ZtpIdent == ztpId {
				found = true
				olt = o
				break
			}
		}

		if found == false {
			http.Error(w, "Olt not found",
				http.StatusNotFound)
			logger.Error(err, "Olt not found")
			return
		}

		var port string
		if olt.Spec.Vendor == "edgecore" {
			port = "9191"
		} else if olt.Spec.Vendor == "adtran" {
			port = "830"
		} else if olt.Spec.Vendor == "bbsim" {
			port = "50060"
		} else {
			http.Error(w, "Olt vendor not supported",
				http.StatusInternalServerError)
			logger.Error(err, fmt.Sprintf("Olt vendor not supported: %s", olt.Spec.Vendor))
			return
		}

		deviceHostAndPort := &voltha.Device_HostAndPort{HostAndPort: olt.Spec.IpAddress + ":" + port}
		Id := uuid.New().String()

		oltDevice := voltha.Device{
			Id:           Id,
			Type:         olt.Spec.Model,
			SerialNumber: olt.Spec.SerialNo,
			Address:      deviceHostAndPort,
		}

		deviceAdd := &commands.DeviceAdd{
			OltDevice: &oltDevice,
		}

		dev, err := deviceAdd.Execute()
		if err != nil {
			http.Error(w, "Error while adding olt into voltha",
				http.StatusInternalServerError)
			logger.Error(err, "Error while adding olt into voltha")
			return
		}

		resp, err := json.Marshal(dev)
		if err != nil {
			http.Error(w, "Error while marshaling olt",
				http.StatusInternalServerError)
			logger.Error(err, "Error while marshaling olt Error: %s")
			return
		}

		w.Header().Add("Content-Type", "application/json")
		_, err = w.Write(resp)

	default:
		fmt.Fprintf(w, "Sorry, only POST methods is supported.")
	}
}

func getValue(reqQuery string) string {
	needleValue := regexp.MustCompile(`value%3D`)
	strValue := needleValue.Split(reqQuery, -1)
	s3 := regexp.MustCompile(`%7D`)
	s4 := s3.Split(strValue[1], -1)
	return s4[0]
}

func (psim *PodCDSim) GetLogicalResources(w http.ResponseWriter, r *http.Request) {
	logger.Info("getLogicalResources() invoked")
	if r == nil {
		w.WriteHeader(http.StatusBadRequest)
		fmt.Fprintf(w, "can not process nil request")
		return
	}
	reqQuery := r.URL.RawQuery
	logger.Info(fmt.Sprintf("request query string: %s", reqQuery))

	var response []*LogicalResource
	var value string
	if strings.Contains(reqQuery, "ztpIdent") {
		//Value contains OLT serialNumber
		value = getValue(reqQuery)
		response, found := psim.kubeManager.FindOLTZtpIdent(value)
		if found == true {
			logger.Info(fmt.Sprintf("OLT FOUND ====> %s", value))
			resp, err := json.Marshal(response)
			if err != nil {
				panic(err)
			}

			w.Header().Add("Content-Type", "application/json")
			_, err = w.Write(resp)
			if err != nil {
				panic(err)
			}
			logger.Info(fmt.Sprintf("Returned response from getLogicalResources(): \n%s", resp))
			return

		} else {
			logger.Info(fmt.Sprintf("OLT NOT FOUND ====> %s", value))
			http.Error(w, "OLT NOT FOUND.", http.StatusNotFound)
			return
		}

	} else {
		port0 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "ENABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870912",
			},
		}
		port1 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870913",
			},
		}
		port2 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870914",
			},
		}
		port3 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870915",
			},
		}
		port4 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870916",
			},
		}
		port5 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870917",
			},
		}
		port6 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870918",
			},
		}
		port7 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870919",
			},
		}
		port8 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870920",
			},
		}
		port9 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870921",
			},
		}
		port10 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870922",
			},
		}
		port11 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870923",
			},
		}
		port12 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "ENABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870924",
			},
		}
		port13 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870925",
			},
		}
		port14 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870926",
			},
		}
		port15 := []*ResourceCharacteristic{
			{
				Name:  "administrativeMode",
				Value: "DISABLED",
			},
			{
				Name:  "logicalLabel",
				Value: "XGSPON_536870927",
			},
		}
		response = []*LogicalResource{
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port0,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port1,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port2,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port3,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port4,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port5,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port6,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port7,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port8,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port9,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port10,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port11,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port12,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port13,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port14,
			},
			{
				AtType:         "NETWORK_ELEMENT_PORT",
				Characteristic: port15,
			},
		}
	}

	resp, err := json.Marshal(response)
	if err != nil {
		panic(err)
	}

	w.Header().Add("Content-Type", "application/json")
	_, err = w.Write(resp)
	if err != nil {
		panic(err)
	}
	logger.Info(fmt.Sprintf("Returned response from getLogicalResources(): \n%s", resp))
}

func (psim *PodCDSim) FetchLogicalResources(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	networkElementID := vars["ne_id"]
	logger.Info(fmt.Sprintf("Will try to fetch details for network-element-id %s", networkElementID))

	resource, err := psim.kubeManager.Finder(networkElementID)
	if err != nil {
		logger.Error(err, fmt.Sprintf("no resource found for network-element-id %s", networkElementID))
		http.Error(w, "resource-not-found", http.StatusNotFound)
		return
	}

	logger.Info(fmt.Sprintf("Network-element-id %s is found", networkElementID))
	response := []*LogicalResource{
		{
			AtType:         "NETWORK_ELEMENT",
			Characteristic: resource,
		},
	}
	resp, err := json.Marshal(response)
	if err != nil {
		panic(err)
	}
	w.Header().Add("Content-Type", "application/json")
	_, err = w.Write(resp)
	if err != nil {
		panic(err)
	}
}

func (psim *PodCDSim) ChangeNetworkResource(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		logger.Info(fmt.Sprintf("Received GET request at '%s'", r.URL.String()))

		resources, err := psim.kubeManager.FindAll()
		if err != nil {
			logger.Error(err, "Error while searching resource")
			return
		}
		jsonEncoder := json.NewEncoder(w)
		err = jsonEncoder.Encode(resources)
		if err != nil {
			logger.Error(err, "Error while encoding json")
			return
		}

		logger.Info(fmt.Sprintf("Read %d NEIDs from the internal db", len(psim.resourceMap)))
		return
	}

	msg := fmt.Sprintf("unsupported http method %s", r.Method)
	logger.Info(msg)
	http.Error(w, msg, http.StatusMethodNotAllowed)
}

/* func (psim *PodCDSim) getPhysicalResource(w http.ResponseWriter, r *http.Request) {
	logger.Info(fmt.Sprintf("getPhysicalResource() invoked with request %+v", r)
	vars := mux.Vars(r)
	resourceName := vars["ne_id"]

	logger.Info(fmt.Sprintf("Will now try to fetch physical-resource with name %s", resourceName)
	fetchedPhyResource, ok := psim.physicalResource.Load(resourceName)
	if !ok {
		logger.Error("Physical resource for key %s not found", resourceName)
		w.WriteHeader(http.StatusNotFound)
		return
	}
	logger.Info(fmt.Sprintf("fetched physical-resource %+v", fetchedPhyResource)

	phyResourceJSON, er := json.Marshal(fetchedPhyResource)
	if er != nil {
		logger.Error("Error occurred while marshaling physicalResource %s", er.Error())
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.Header().Add("Content-Type", "application/json")
	_, er = w.Write(phyResourceJSON)
	if er != nil {
		logger.Error("error in sending physical resource to caller %s", er.Error())
		w.WriteHeader(http.StatusInternalServerError)
	}
}

func (psim *PodCDSim) createPhysicalResource(w http.ResponseWriter, r *http.Request) {
	logger.Infof("creatPhysicalResource invoked with request %+v", r)
	if r == nil {
		w.WriteHeader(http.StatusBadRequest)
		fmt.Fprintf(w, "can not process nil request")

		return
	}

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		logger.Errorf(err.Error())
		w.WriteHeader(http.StatusBadRequest)
		fmt.Fprintf(w, "error occurred while reading the request physical resource %s", err.Error())
		return
	}

	logger.Infof("request body : %s", reqBody)
	phyResource := &PhysicalResource{}
	err = json.Unmarshal(reqBody, phyResource)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintf(w, "error occurred while un-marshalig physical resource %s", err.Error())
		return
	}

	logger.Infof("Un-marshaled physical-resource %+v", phyResource)
	if phyResource.Name == "" {
		logger.Errorf("physical-resource name is empty in un-marshaled physical-resource")
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintf(w, "physical-resource name is empty in un-marshaled physical-resource")
		return
	}
	psim.physicalResource.Store(phyResource.Name, phyResource)
	logger.Infof("Physical resource %+v with name %s saved to dB", phyResource, phyResource.Name)
	w.Header().Add("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
} */
