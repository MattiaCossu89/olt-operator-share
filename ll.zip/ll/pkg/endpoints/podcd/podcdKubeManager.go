package podcd

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net/http"

	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/client"
)

type PodcdKubeManager struct {
	ontClient            client.OntInterface
	oltClient            client.OltInterface
	accessNodeClient     client.AccessNodeInterface
	venetClient          client.VenetInterface
	techProfileClient    client.TechProfileInterface
	serviceProfileClient client.ServiceProfileInterface
	ctx                  context.Context
}

type Resource map[string][]*ResourceCharacteristic

func NewPodcdKubeManager() *PodcdKubeManager {

	config, err := rest.InClusterConfig()
	if err != nil {
		return nil
	}

	clientset, err := client.NewForConfig(config)
	if err != nil {
		return nil
	}

	mgr := &PodcdKubeManager{
		ontClient:            clientset.Onts(context.TODO(), "olt-operator-system"),
		oltClient:            clientset.Olts(context.TODO(), "olt-operator-system"),
		accessNodeClient:     clientset.AccessNodes(context.TODO(), "olt-operator-system"),
		venetClient:          clientset.Venets(context.TODO(), "olt-operator-system"),
		techProfileClient:    clientset.TechProfiles(context.TODO(), "olt-operator-system"),
		serviceProfileClient: clientset.ServiceProfiles(context.TODO(), "olt-operator-system"),
		ctx:                  context.Background(),
	}

	return mgr
}

func (e *PodcdKubeManager) Finder(id string) ([]*ResourceCharacteristic, error) {

	dict := make(Resource, 0)

	err := e.neidsOlt(&dict)
	if err != nil {
		return nil, err
	}

	if _, ok := dict[id]; ok {
		return dict[id], nil
	}

	err = e.neidsAccessNode(&dict)
	if err != nil {
		return nil, err
	}

	if _, ok := dict[id]; ok {
		return dict[id], nil
	}

	err = e.neidsOnt(&dict)
	if err != nil {
		return nil, err
	}

	if _, ok := dict[id]; ok {
		return dict[id], nil
	}

	return nil, errors.New("Error: resource not found")
}

func (e *PodcdKubeManager) FindOLTZtpIdent(ztpIdent string) ([]*LogicalResource, bool) {

	dict := make(Resource, 0)

	err := e.neidsOlt(&dict)
	if err != nil {
		return nil, false
	}

	for neid, characteristic := range dict {
		for _, value := range characteristic {
			if value.Name == "ztpIdent" && value.Value == ztpIdent {
				logger.Info(fmt.Sprintf("OLT FOUND ====> %s In NEID ====> %s", value, neid))
				var correlationId string
				var lifeCycleState string
				var relatedNeid string

				for _, entries := range characteristic {
					if entries.Name == "correlationId" {
						correlationId = entries.Value
					}
					if entries.Name == "operationalState" {
						lifeCycleState = entries.Value
					}
					if entries.Name == "relationship" {
						relatedNeid = entries.Value
					}
				}
				var rel = []*ResourceRelationship{
					{
						Type: "requires",
						ResourceRef: ResourceRef{
							ID:   relatedNeid,
							Type: "NetworkElementGroup",
						},
					},
				}
				response := []*LogicalResource{
					{
						AtType:               "NETWORK_ELEMENT",
						Characteristic:       characteristic,             //TODO check if neid exists
						Description:          "OLT for " + correlationId, //correlationId
						ID:                   neid,                       //NEID
						LifecycleState:       lifeCycleState,             //OperationalState
						Name:                 "OLT " + correlationId,     //OLT + correlationId
						ResourceRelationship: rel,
					},
				}
				return response, true

			}
		}
	}

	return nil, false
}

func (e *PodcdKubeManager) FindAll() (Resource, error) {

	dict := make(Resource, 0)

	err := e.neidsOlt(&dict)
	if err != nil {
		return nil, err
	}

	err = e.neidsAccessNode(&dict)
	if err != nil {
		return nil, err
	}

	err = e.neidsOnt(&dict)
	if err != nil {
		return nil, err
	}

	return dict, errors.New("Error: resource not found")
}

func (e *PodcdKubeManager) paosimHealthHandler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/health" {
		http.Error(w, "404 not found.", http.StatusNotFound)
		return
	}
	str := "{\"status\":\"UP\"}"
	fmt.Fprint(w, str)
}

func (e *PodcdKubeManager) Run() {
	//http.HandleFunc("/onus", e.onusHandler)
	http.HandleFunc("/health", e.paosimHealthHandler)

	fmt.Printf("Starting server at port 18808\n")
	if err := http.ListenAndServe(":18808", nil); err != nil {
		log.Fatal(err)
	}
}
