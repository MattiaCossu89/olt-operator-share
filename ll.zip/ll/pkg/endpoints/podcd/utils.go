package podcd

import (
	"encoding/json"
	"fmt"
	"log"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func (e *PodcdKubeManager) neidsOlt(maps *Resource) error {
	olts, err := e.oltClient.List(metav1.ListOptions{})
	if err != nil {
		return err
	}

	log.Print(olts)

	for _, olt := range olts.Items {
		accessNode, err := e.accessNodeClient.Get(olt.Spec.ParentId, metav1.GetOptions{})
		if err != nil {
			return err
		}

		vendorClassId := ""
		if olt.Spec.Vendor == "adtran" {
			vendorClassId = "ADTRAN.SDX.6320"
		} else if olt.Spec.Vendor == "edgecore" {
			vendorClassId = "edgecore"
		}

		chars := []*ResourceCharacteristic{
			{
				Name:  "relationship",
				Value: accessNode.Spec.Id,
			},
			{
				Name:  "plannedMatNumber",
				Value: "9",
			},
			{
				Name:  "ztpIdent",
				Value: olt.Spec.ZtpIdent,
			},
			{
				Name:  "serialNo",
				Value: olt.Spec.SerialNo,
			},
			{
				Name:  "route",
				Value: "0.0.0.0",
			},
			{
				Name:  "cidr",
				Value: olt.Spec.Cidr,
			},
			{
				Name:  "mac",
				Value: olt.Spec.MacAddress,
			},
			{
				Name:  "ipv4Address",
				Value: olt.Spec.IpAddress,
			},
			{
				Name:  "operationalData",
				Value: fmt.Sprintf("{\"resourceResourceCharacteristic\":[{\"name\":\"neConfigId\",\"value\":101},{\"name\":\"dhcpOptions\",\"value\":[{\"tag\":1,\"value\":\"255.255.255.0\"}]},{\"name\":\"hostname\",\"value\":\"49_9124_130_7KH0\"},{\"name\":\"neSwitchId\",\"value\":101},{\"name\":\"vendorClassId\",\"value\":\"%s\"},{\"name\":\"managementIpAddresses\",\"value\":[{\"address\":\"%s\",\"type\":\"MGMT_INBAND\"}]}],\"vendorClassId\":\"%s\"}", vendorClassId, olt.Spec.Cidr, vendorClassId),
			},
		}

		(*maps)[olt.GetName()] = chars

	}

	return nil
}

func (e *PodcdKubeManager) neidsOnt(maps *Resource) error {
	onts, err := e.ontClient.List(metav1.ListOptions{})
	if err != nil {
		return nil
	}

	jsonRes, _ := json.Marshal(onts)
	log.Print(string(jsonRes))

	for _, ont := range onts.Items {
		olt, err := e.oltClient.Get(ont.Spec.ParentId, metav1.GetOptions{})
		if err != nil {
			return err
		}
		accessNode, err := e.accessNodeClient.Get(olt.Spec.ParentId, metav1.GetOptions{})
		if err != nil {
			return err
		}

		log.Print(ont)

		chars := []*ResourceCharacteristic{
			{
				Name:  "relationship",
				Value: accessNode.Spec.Id,
			},
			{
				Name:  "ztpIdent",
				Value: ont.Spec.SerialNo,
			},
			{
				Name:  "operationalData",
				Value: "",
			},
			{
				Name:  "onuId",
				Value: ont.Spec.OnuId,
			},
		}

		(*maps)[ont.GetName()] = chars
	}
	return nil
}

func (e *PodcdKubeManager) neidsAccessNode(maps *Resource) error {
	accessNodes, err := e.accessNodeClient.List(metav1.ListOptions{})
	if err != nil {
		return err
	}

	for _, accessNode := range accessNodes.Items {

		chars := []*ResourceCharacteristic{
			{
				Name:  "ipv4Address",
				Value: accessNode.Spec.IpAddress,
			},
			{
				Name:  "ztpIdent",
				Value: accessNode.Spec.ZtpIdent,
			},
			{
				Name:  "operationalData",
				Value: "",
			},
		}

		(*maps)[accessNode.GetName()] = chars
	}
	return nil
}
