//Entry point for PAO simulator GRPC server
package main
