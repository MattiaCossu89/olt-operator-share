//Entry point for PAO simulator GRPC server
package paosim

import (
	"context"

	config2 "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/config"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/notif"

	"github.com/joho/godotenv"
	"github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	grpc2 "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/grpc2"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/url"
	access_proxy "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/vap"
	kube "sigs.k8s.io/controller-runtime/pkg/client"
)

//Version paosim app version
var Version = "1.8.2-tim.2"

func Start(client kube.Client) {
	logrus.Infof("TIM PAO Simulator 1.8.2-tim.2")
	err := godotenv.Load()
	if err != nil {
		logrus.Warn(err.Error())
	}

	//vapGrpc := env.ReadEnv("VAP_GRPC_ADDRESS", ":18812")
	vapGrpc := env.ReadEnv("VAP_GRP_ENDPOINT", "vap-grpc.voltha:18800") //TODO config map

	logLevel := env.ReadEnv("LOGGING_LEVEL", "info")
	grpcAddr := url.BuildURLFromEnvs("", "PAO_SIMULATOR_PORT", 18809)
	logrus.Infof("Will start TIM paosim GRPC Server at '%s' with log level %s", grpcAddr, logLevel)

	config, err := config2.GetConfig()
	if err != nil {
		logrus.Fatalf(err.Error())
		return
	}
	configManager := config2.NewManager(config, client)
	/* configHandler := &config2.HTTPHandler{
		Manager: configManager,
	} */

	deviceIndicationQueue := make(chan *access_proxy.DeviceIndicationRequest, 1000)
	defer close(deviceIndicationQueue)

	/* httpFacade := rest.Facade{
		ConfigHandler: configHandler,
		DeviceHTTPHandler: &notif.DeviceHTTPHandler{
			Queue: deviceIndicationQueue,
		},
	}
	go httpFacade.Start(ctx) */
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	notifSrvr := &notif.PaoGRPCNotificationServer{
		ConfigManager: configManager,
		Queue:         deviceIndicationQueue,
	}
	srv := grpc2.NewServerWithOpts(grpc2.ServerOpts{
		BaseOpts: grpc2.NewDefaultServerOpts(),
		RegFuncs: []func(*grpc.Server){
			func(server *grpc.Server) {
				access_proxy.RegisterVolthaAccessProxyNotificationsServer(server, notifSrvr)
			},
		},
		IsWithReflection: true,
		Address:          grpcAddr,
		ID:               "paoGRPCServerSimulator",
	})
	defer srv.Stop()

	deviceExecutor := notif.ConfigureDeviceExecutor{
		VAPGRPCServerAddr: vapGrpc,
		ConfigManager:     configManager,
		Queue:             deviceIndicationQueue,
	}
	go deviceExecutor.Start(ctx)

	err = srv.StartSync()
	if err != nil {
		logrus.Fatalf(err.Error())
		return
	}
}
