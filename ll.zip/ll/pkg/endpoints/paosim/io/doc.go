//Package io gives different IO helper functions
package io
