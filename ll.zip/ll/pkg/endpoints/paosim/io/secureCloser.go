//Package io gives different IO helper functions
package io

import (
	"io"

	"github.com/sirupsen/logrus"
)

//CloseResourceSecure allows to call closer and handle errors as warnings in logs
func CloseResourceSecure(name string, c io.Closer) {
	if c == nil {
		return
	}

	err := c.Close()
	if err != nil {
		logrus.Errorf("Failed to close resource '%s': %v", name, c)
	}
}
