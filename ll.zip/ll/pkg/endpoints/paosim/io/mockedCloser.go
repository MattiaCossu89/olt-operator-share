//Package io gives different IO helper functions
package io

//MockedCloser mocks closer interface
type MockedCloser struct {
	ErrToGive error
	WasCalled bool
}

//Close interface implementation
func (mc *MockedCloser) Close() error {
	mc.WasCalled = true
	return mc.ErrToGive
}
