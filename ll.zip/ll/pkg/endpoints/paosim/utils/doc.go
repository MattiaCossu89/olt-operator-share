//Package utils contains diverse helpful utils without any specific business domain
package utils
