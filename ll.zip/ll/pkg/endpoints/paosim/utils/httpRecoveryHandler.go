//Package utils contains diverse helpful utils without any specific business domain
package utils

import (
	"fmt"
	"net/http"

	"github.com/sirupsen/logrus"
)

//Recover recovers http handlers from fatal errors and handles them gracefully
func Recover(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			err := recover()
			if err != nil {
				logrus.Errorf(fmt.Sprint(err))

				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)

				jsonBody := fmt.Sprintf(`{error: "There was an internal server error: %v"}`, err)

				_, err := w.Write([]byte(jsonBody))
				if err != nil {
					logrus.Errorf(err.Error())
				}
			}
		}()

		next.ServeHTTP(w, r)
	})
}
