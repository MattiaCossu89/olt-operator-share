//Package utils contains diverse helpful utils without any specific business domain
package utils

import (
	"regexp"
	"strings"
)

//Suffix to add or remove
const Suffix = "-1"

//AppendPortSuffixToONUSn appends -1 to input
func AppendPortSuffixToONUSn(input string) string {
	if strings.HasSuffix(input, Suffix) {
		return input
	}

	return input + Suffix
}

//RemovePortSuffixFromONUSn removes -1 from input
func RemovePortSuffixFromONUSn(input string) string {
	if !strings.HasSuffix(input, Suffix) {
		return input
	}

	return strings.TrimSuffix(input, Suffix)
}

//OnuSNHasExpectedSuffix indicates if an onu sn contains items from suffixesToFind at the end
func OnuSNHasExpectedSuffix(input string) bool {
	if strings.HasSuffix(input, Suffix) {
		return true
	}

	rgx := regexp.MustCompile(`.+-\d+$`)
	//we accept no number suffixes here e.g. SN rather than SN-2, SN-3 etc
	return !rgx.MatchString(input)
}
