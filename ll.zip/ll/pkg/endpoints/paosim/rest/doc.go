//Package rest wraps http server logic
package rest
