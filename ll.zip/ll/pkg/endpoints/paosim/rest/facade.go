//Package rest wraps http server logic
package rest

import (
	"context"
	"net/http"

	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/config"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/health"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/notif"

	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/utils"

	"github.com/gorilla/mux"
	"github.com/sirupsen/logrus"

	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/io"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/url"
)

//Facade starts rest server
type Facade struct {
	ConfigHandler     *config.HTTPHandler
	DeviceHTTPHandler *notif.DeviceHTTPHandler
}

//Start triggering function
func (f Facade) Start(ctx context.Context) {
	restAddr := url.BuildURLFromEnvs("", "PAO_REST_SIMULATOR_PORT", 18998)
	logLevel := env.ReadEnv("LOGGING_LEVEL", "info")

	logrus.Infof("Will start HTTP Server at '%s' with log level %s", restAddr, logLevel)
	router := mux.NewRouter().StrictSlash(false)
	router.Use(utils.Recover)

	srv := &http.Server{
		Addr:    restAddr,
		Handler: router,
	}

	defer io.CloseResourceSecure("PAO rest server", srv)
	router.HandleFunc("/health", health.HandleHealth).Methods(http.MethodGet)
	router.Handle("/onus", f.ConfigHandler).Methods(http.MethodGet, http.MethodPost, http.MethodDelete)
	router.Handle("/devices", f.DeviceHTTPHandler).Methods(http.MethodPost)

	go func(s *http.Server, c context.Context) {
		<-c.Done()
		e := s.Shutdown(context.Background())
		if e != nil {
			logrus.Fatalf(e.Error())
			return
		}
	}(srv, ctx)

	err := srv.ListenAndServe()
	if err != nil {
		logrus.Errorf(err.Error())
	}
}
