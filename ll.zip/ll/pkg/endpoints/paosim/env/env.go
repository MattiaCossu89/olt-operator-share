//Package env wraps env variables read capabilities
package env

import (
	"fmt"
	"os"
	"strconv"
)

//ReadEnv reads string env
func ReadEnv(name, defaultVal string) string {
	return readEnvironment(
		name,
		defaultVal,
		func(val string) interface{} {
			return val
		},
	).(string)
}

func readEnvironment(name string, defaultVal interface{}, conv func(val string) interface{}) interface{} {
	envVar, found := os.LookupEnv(name)
	if !found {
		return defaultVal
	}
	return conv(envVar)
}

//ReadEnvInt64 reads int64 env var returning defaultVal if the first one is missing
func ReadEnvInt64(name string, defaultVal int64) int64 {
	return readEnvironment(
		name,
		defaultVal,
		func(val string) interface{} {
			intRes, err := strconv.ParseInt(val, 0, 64)
			if err != nil {
				return defaultVal
			}
			return intRes
		},
	).(int64)
}

//ReadEnvInt reads int env var returning defaultVal if the first one is missing
func ReadEnvInt(name string, defaultVal int) int {
	return readEnvironment(
		name,
		defaultVal,
		func(val string) interface{} {
			intRes, err := strconv.Atoi(val)
			if err != nil {
				return defaultVal
			}
			return intRes
		},
	).(int)
}

//ReadEnvBool reads bool env var returning defaultVal if the first one is missing
func ReadEnvBool(name string, defaultVal bool) bool {
	return readEnvironment(
		name,
		defaultVal,
		func(val string) interface{} {
			return val == "true"
		},
	).(bool)
}

//ReadEnvFloat reads float64 env var returning defaultVal if the first one is missing
func ReadEnvFloat(name string, defaultVal float64) float64 {
	return readEnvironment(
		name,
		defaultVal,
		func(val string) interface{} {
			floatResult, err := strconv.ParseFloat(val, 64)
			if err != nil {
				return defaultVal
			}
			return floatResult
		},
	).(float64)
}

//ReadEnvOrError reads string env or returns error if it's missing
func ReadEnvOrError(name string) (string, error) {
	val := ReadEnv(name, "")
	if val == "" {
		return "", fmt.Errorf("required env variable '%s' is not set", name)
	}

	return val, nil
}
