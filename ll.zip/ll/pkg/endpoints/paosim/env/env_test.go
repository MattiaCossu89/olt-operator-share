package env

import (
	"fmt"
	"log"
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
)

var keyVals map[string]string

func init() {
	keyVals = map[string]string{
		"SOME_ENV_STRING":     "GoLangCode",
		"SOME_ENV_INT":        "123",
		"SOME_ENV_FLOAT":      "123.345",
		"SOME_ENV_BOOL_TRUE":  "true",
		"SOME_ENV_BOOL_FALSE": "false",
		"SOME_ENV_BOOL_EMPTY": "",
	}

	for k, v := range keyVals {
		err := os.Setenv(k, v)
		if err != nil {
			log.Fatalf(err.Error())
		}
	}
}

func TestSuite(t *testing.T) {
	defer func() {
		errCont := ""
		for k := range keyVals {
			err := os.Unsetenv(k)
			errCont += err.Error()
		}
		err := fmt.Errorf(errCont + "\n")
		if err != nil {
			log.Fatalf(err.Error())
		}
	}()
	t.Run("testReadEnv", testReadEnv)
	t.Run("testReadEnvInt64", testReadEnvInt64)
	t.Run("testReadEnvInt", testReadEnvInt)
	t.Run("testReadEnvFloat", testReadEnvFloat)
	t.Run("testReadEnvOrError", testReadEnvOrError)
	t.Run("testReadEnvOrFailWithExistingEnv", testReadEnvOrFailWithExistingEnv)
	t.Run("testReadEnvOrFailWithNonExistingEnv", testReadEnvOrFailWithNonExistingEnv)
	t.Run("testReadEnvBool", testReadEnvBool)
}

func testReadEnv(t *testing.T) {
	assert.Equal(t, "GoLangCode", ReadEnv("SOME_ENV_STRING", ""))
	assert.Equal(t, "Some default val", ReadEnv("NON_EXISTING_ENV_STRING", "Some default val"))
}

func testReadEnvInt64(t *testing.T) {
	assert.EqualValues(t, 123, ReadEnvInt64("SOME_ENV_INT", 0))
	assert.EqualValues(t, 0, ReadEnvInt64("NON_EXISTING_ENV_INT", 0))
	assert.EqualValues(t, 2, ReadEnvInt64("SOME_ENV_STRING", 2))
}

func testReadEnvBool(t *testing.T) {
	assert.EqualValues(t, true, ReadEnvBool("SOME_ENV_BOOL_TRUE", false))
	assert.EqualValues(t, false, ReadEnvBool("SOME_ENV_BOOL_FALSE", true))
	assert.EqualValues(t, false, ReadEnvBool("SOME_ENV_BOOL_EMPTY", true))
	assert.EqualValues(t, false, ReadEnvBool("NON_EXISTING_ENV_BOOL", false))
	assert.EqualValues(t, true, ReadEnvBool("NON_EXISTING_ENV_BOOL", true))
}

func testReadEnvInt(t *testing.T) {
	assert.EqualValues(t, 123, ReadEnvInt("SOME_ENV_INT", 0))
	assert.EqualValues(t, 0, ReadEnvInt("NON_EXISTING_ENV_INT", 0))
	assert.EqualValues(t, 0, ReadEnvInt("SOME_ENV_STRING", 0))
}

func testReadEnvFloat(t *testing.T) {
	assert.EqualValues(t, 123.345, ReadEnvFloat("SOME_ENV_FLOAT", 0.1))
	assert.EqualValues(t, 0.1, ReadEnvFloat("NON_EXISTING_ENV_INT", 0.1))
	assert.EqualValues(t, 0.2, ReadEnvFloat("SOME_ENV_STRING", 0.2))
}

func testReadEnvOrError(t *testing.T) {
	actualVal, err := ReadEnvOrError("SOME_ENV_STRING")
	assert.NoError(t, err)
	assert.Equal(t, "GoLangCode", actualVal)

	actualVal, err = ReadEnvOrError("NON_EXISTING_ENV_STRING")
	assert.EqualError(t, err, "required env variable 'NON_EXISTING_ENV_STRING' is not set")
	assert.Equal(t, "", actualVal)
}

func testReadEnvOrFailWithExistingEnv(t *testing.T) {
	actualVal, err := ReadEnvOrError("SOME_ENV_STRING")
	assert.NoError(t, err)
	assert.Equal(t, "GoLangCode", actualVal)
}

func testReadEnvOrFailWithNonExistingEnv(t *testing.T) {
	_, err := ReadEnvOrError("NON_EXISTING_ENV_STRING")
	assert.Error(t, err)
}
