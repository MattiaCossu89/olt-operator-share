//Package health manages health logic
package health

import (
	"net/http"
	"net/http/httputil"

	"github.com/sirupsen/logrus"
)

//HandleHealth health handler
func HandleHealth(w http.ResponseWriter, r *http.Request) {
	dump, err := httputil.DumpRequest(r, true)
	if err != nil {
		logrus.Errorf(err.Error())
		return
	}

	logrus.Debugf("Received HTTP request: %s,IP: '%s'", string(dump), r.RemoteAddr)

	w.WriteHeader(http.StatusOK)
	_, err = w.Write([]byte(`{"status":"UP"}`))
	if err != nil {
		logrus.Errorf(err.Error())
	}
}
