//Package url gives url manipulation logic
package url

import (
	"fmt"

	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

//BuildURLFromEnvs helper func to build host port address strings
func BuildURLFromEnvs(envAddress, envPort string, envDefaultPort int) string {
	addr := env.ReadEnv(envAddress, "")
	port := env.ReadEnvInt(envPort, envDefaultPort)
	return fmt.Sprintf("%s:%d", addr, port)
}
