//Package url gives url manipulation logic
package url
