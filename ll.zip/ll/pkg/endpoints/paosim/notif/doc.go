//Package notif handles the notifications coming from VAP towards simulated GRPC server of PAO
package notif
