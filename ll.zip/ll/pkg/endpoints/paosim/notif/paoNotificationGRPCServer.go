//Package notif handles the notifications coming from VAP towards simulated GRPC server of PAO
package notif

import (
	"context"

	"github.com/sirupsen/logrus"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/config"

	access_proxy "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/vap"
)

//PaoGRPCNotificationServer simulates PAO GRPC for Notifications
type PaoGRPCNotificationServer struct {
	ConfigManager *config.Manager
	Queue         chan *access_proxy.DeviceIndicationRequest
}

//DeviceIndication simulates an OK response
func (pgns *PaoGRPCNotificationServer) DeviceIndication(ctx context.Context, payload *access_proxy.DeviceIndicationRequest) (*access_proxy.DeviceIndicationResponse, error) {
	logrus.Debugf("Received DeviceIndication input: %s", payload.String())
	pgns.Queue <- payload

	//we return always success as failures will produce an endless consumption loop in Kafka flooding simulator
	//with the same failed payload
	return &access_proxy.DeviceIndicationResponse{Status: access_proxy.DeviceIndicationResponse_OK}, nil
}
