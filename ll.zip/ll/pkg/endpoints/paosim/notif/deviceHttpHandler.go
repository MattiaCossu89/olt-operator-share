//Package notif handles the notifications coming from VAP towards simulated GRPC server of PAO
package notif

import (
	"net/http"

	"github.com/golang/protobuf/jsonpb"
	"github.com/sirupsen/logrus"

	access_proxy "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/vap"
)

//DeviceHTTPHandler provides HTTP server for device indications from user
type DeviceHTTPHandler struct {
	Queue chan *access_proxy.DeviceIndicationRequest
}

//ServeHTTP implements http Handler to accept device indications
func (dhh *DeviceHTTPHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	logrus.Infof("Received DeviceIndicationRequest via REST")
	payload := &access_proxy.DeviceIndicationRequest{}
	err := jsonpb.Unmarshal(r.Body, payload)
	if err != nil {
		logrus.Errorf(err.Error())
		return
	}

	logrus.Infof("DeviceIndication payload: %s", payload.String())

	dhh.Queue <- payload
}
