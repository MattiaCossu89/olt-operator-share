//Package notif handles the notifications coming from VAP towards simulated GRPC server of PAO
package notif

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/sirupsen/logrus"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/config"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/io"

	"google.golang.org/grpc"
	access_proxy "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/vap"
)

const (
	maxOnuID        = 128
	maxIntfID       = 32
	maxAllowedVlan  = 4094
	onuSerialLength = 16
	bbsimVendor     = "4242534D"
)

//ConfigureDeviceExecutor simulates a detached device config executor
type ConfigureDeviceExecutor struct {
	VAPGRPCServerAddr string
	ConfigManager     *config.Manager
	Queue             chan *access_proxy.DeviceIndicationRequest
}

//Start starts simulator
func (pgns *ConfigureDeviceExecutor) Start(ctx context.Context) {
	logrus.Infof("Starting ConfigureDeviceExecutor")
	var onuConfig config.Onu
	var found bool
	var err error

mainLoop:
	for {
		select {
		case msg := <-pgns.Queue:
			logrus.Infof("ConfigureDeviceExecutor received configuration request: %v", msg)

			logrus.Infof("ConfigureDeviceExecutor will try to find configuration for ONU %s", msg.OnuSerial)
			if strings.Contains(msg.OnuSerial, bbsimVendor) {
				logrus.Infof("Onu %s belongs to BBSIM, will generate per OLT unique s-tag", msg.OnuSerial)
				onuConfig, err = pgns.generateStag(msg.OnuSerial)
				if err != nil {
					continue mainLoop
				}
			} else {
				found, onuConfig = pgns.ConfigManager.FindOnuConfig(msg.OnuSerial)
				if !found {
					logrus.Infof("Didn't find ONU configuration will ignore message %s", msg.String())
					continue mainLoop
				}
			}

			logrus.Infof("ConfigureDeviceExecutor found a whitelisted ONU sn '%s', queue configure device execution to VAP", msg.OnuSerial)
			err = pgns.callConfigureDeviceOnVAP(msg, onuConfig)
			if err != nil {
				logrus.Errorf("ConfigureDevice failure: %v", err)
			}
		case <-ctx.Done():
			logrus.Infof("Exit signal received, ConfigureDeviceExecutor will exit")
			return
		}
	}
}

func (pgns *ConfigureDeviceExecutor) callConfigureDeviceOnVAP(
	payload *access_proxy.DeviceIndicationRequest,
	onuConf config.Onu,
) error {
	logrus.Infof("Will call ConfigureDevice method on VAP GPRC: %s", pgns.VAPGRPCServerAddr)
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	conn, err := grpc.DialContext(ctx, pgns.VAPGRPCServerAddr, grpc.WithInsecure())
	if err != nil {
		return err
	}

	defer io.CloseResourceSecure("VapGRPCClient", conn)

	configureDeviceGRPCClient := access_proxy.NewVolthaAccessProxyConfigurationClient(conn)

	onuType := access_proxy.OnuType_UNDEFINED_ONU_TYPE
	switch onuConf.Type {
	case "ONT":
		onuType = access_proxy.OnuType_ONT
	case "DPU":
		onuType = access_proxy.OnuType_DPU
	}

	logrus.Infof("ONU type '%s' will set it as '%s'", onuConf.Type, onuType.String())

	configureDeviceRequestState := access_proxy.ConfigureDeviceRequest_UNDEFINED_STATE
	switch payload.State {
	case access_proxy.State_UP:
		configureDeviceRequestState = access_proxy.ConfigureDeviceRequest_UP
	case access_proxy.State_DOWN:
		configureDeviceRequestState = access_proxy.ConfigureDeviceRequest_DOWN
	}

	req := &access_proxy.ConfigureDeviceRequest{
		State:                configureDeviceRequestState,
		OnuSerial:            payload.OnuSerial,
		OltSerial:            payload.OltSerial,
		OnuType:              onuType,
		CTag:                 onuConf.CTag,
		STag:                 onuConf.STag,
		UniTagMatch:          onuConf.UniTagMatch,
		ConfiguredMacAddress: onuConf.ConfiguredMacAddress,
		DpuMgmtTag_1:         "",
		DpuMgmtTag_2:         "",
		Profile:              onuConf.Profile,
	}
	logrus.Infof("Will call ConfigureDevice GRPC for default profile and with input: %s", req.String())
	logrus.Debugf("ConfigureDevice input: %v", req)
	ctx2, cancel2 := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel2()

	resp, err := configureDeviceGRPCClient.ConfigureDevice(ctx2, req)
	if err != nil {
		msgErr := fmt.Sprintf("The call to ConfigureDevice on VAP GPRC has failed: %v", err)
		return errors.New(msgErr)
	}

	logrus.Infof("Got response from VAP ConfigureDevice method: %s", resp.String())
	return nil
}

// Assuming:
// Maximum number of pon per OLT is 32
// Maximum number of onus per pon-port is 128
// Total ONTs per OLT = 32 * 128 = 4096
// Hence, each OLT can have 1-4094 s-tags (4095 reserved vlan tag)
func (pgns *ConfigureDeviceExecutor) generateStag(onuSerial string) (config.Onu, error) {
	if len(onuSerial) != onuSerialLength {
		err := fmt.Errorf("can not generate s-tag for onu %s, invalid serial-number length %d", onuSerial, len(onuSerial))
		logrus.Errorf("%s", err.Error())
		return config.Onu{}, err
	}

	onuID, parseErr := strconv.ParseUint(onuSerial[14:], 16, 8)
	if parseErr != nil {
		err := fmt.Errorf("onu serial %s parsing failed %s", onuSerial, parseErr.Error())
		logrus.Errorf("%s", err.Error())
		return config.Onu{}, err
	}
	intfID, parseErr := strconv.ParseUint(onuSerial[12:14], 16, 8)
	if parseErr != nil {
		err := fmt.Errorf("onu serial %s parsing failed %s", onuSerial, parseErr.Error())
		logrus.Errorf("%s", err.Error())
		return config.Onu{}, err
	}

	// IntfID range: 0 to (maxIntfID-1)
	if intfID >= maxIntfID {
		err := fmt.Errorf("can not generate s-tag for onu %s, invalid pon-id", onuSerial)
		logrus.Errorf("%s", err.Error())
		return config.Onu{}, err
	}
	// onuID range: 1 to maxOnuID
	if onuID > maxOnuID {
		err := fmt.Errorf("can not generate s-tag for onu %s, invalid onu-id", onuSerial)
		logrus.Errorf("%s", err.Error())
		return config.Onu{}, err
	}

	// generate s-tag in range 1-4094
	// s-tag:
	// --------------------------------------
	// | 5 bit IntfID  |   7 bit OnuID      |
	// --------------------------------------
	stag := ((intfID << 7) | onuID) % 4096
	if stag > maxAllowedVlan {
		err := fmt.Errorf("can not generate s-tag for onu %s, vlan range %d exceeded", onuSerial, maxAllowedVlan)
		logrus.Errorf("%s", err.Error())
		return config.Onu{}, err
	}

	return config.Onu{
		Sn:   onuSerial,
		Type: "ONT",
		STag: strconv.Itoa(int(stag)),
	}, nil
}
