//Package grpc gives helpers for grpc servers
package grpc2

import (
	"time"
)

//ServerInterfaceGrpc common interface for gRPC server
type ServerInterfaceGrpc interface {
	StartAsync(time.Duration) error
	StartSync() error
	Stop()
}
