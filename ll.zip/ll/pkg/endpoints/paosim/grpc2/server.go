package grpc2

import (
	"context"
	"net"
	"time"

	"github.com/sirupsen/logrus"
	"google.golang.org/grpc/keepalive"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

//Server offers helpful wrapping functions to start and stop GRPC server
type Server struct {
	grpcServer *grpc.Server
	regFuncs   []func(*grpc.Server)
	Address    string
}

//RequestLogger logs every GRPC request
func RequestLogger(ctx context.Context,
	req interface{},
	info *grpc.UnaryServerInfo,
	handler grpc.UnaryHandler) (interface{}, error) {
	start := time.Now()
	// Calls the handler
	h, err := handler(ctx, req)

	// Logging with grpclog (grpclog.LoggerV2)
	logrus.Infof("Request GRPC - Method:%s\tDuration:%s\tError:%v\n",
		info.FullMethod,
		time.Since(start),
		err,
	)

	return h, err
}

//NewDefaultServerOpts default recommended options for a GRPC server
func NewDefaultServerOpts() []grpc.ServerOption {
	return []grpc.ServerOption{
		grpc.UnaryInterceptor(RequestLogger),
		grpc.KeepaliveParams(keepalive.ServerParameters{
			MaxConnectionIdle:     time.Minute,
			Time:                  time.Minute,
			MaxConnectionAge:      time.Minute,
			MaxConnectionAgeGrace: 2 * time.Minute,
		}),
	}
}

//NewServer generic GRPC logic to which we add concrete server implementations with regFuncs
func NewServer(id, address string, isWithReflection bool, regFunc ...func(*grpc.Server)) *Server {
	return NewServerWithOpts(ServerOpts{
		BaseOpts:         []grpc.ServerOption{},
		RegFuncs:         regFunc,
		IsWithReflection: isWithReflection,
		Address:          address,
		ID:               id,
	})
}

//ServerOpts configuration options for GRPC server wrapper
type ServerOpts struct {
	BaseOpts         []grpc.ServerOption
	RegFuncs         []func(*grpc.Server)
	IsWithReflection bool
	Address          string
	ID               string
}

//NewServerWithOpts another constructor with options struct
func NewServerWithOpts(opts ServerOpts) *Server {
	if opts.Address != "" {
		logrus.Infof("GRPC Server '%s' got %s as a startup address", opts.ID, opts.Address)
	} else {
		logrus.Infof("GRPC Server '%s' got an empty startup address, will select a random local port for it", opts.ID)
	}
	srv := grpc.NewServer(opts.BaseOpts...)
	if opts.IsWithReflection {
		reflection.Register(srv)
	}
	return &Server{
		grpcServer: srv,
		regFuncs:   opts.RegFuncs,
		Address:    opts.Address,
	}
}

//StartAsync non blocking server start
func (vs *Server) StartAsync(startupTimeout time.Duration) error {
	lis, err := vs.prepare()
	if err != nil {
		return err
	}

	errChan := make(chan error)
	go func(l net.Listener) {
		if err := vs.grpcServer.Serve(l); err != nil {
			errChan <- err
		}
	}(lis)

	select {
	case err := <-errChan:
		return err
	case <-time.After(startupTimeout):
		return nil
	}
}

//StartSync blocking server start
func (vs *Server) StartSync() error {
	lis, err := vs.prepare()
	if err != nil {
		return err
	}

	if err := vs.grpcServer.Serve(lis); err != nil {
		return err
	}

	return nil
}

//Stop cleanup server
func (vs *Server) Stop() {
	if vs.grpcServer != nil {
		vs.grpcServer.GracefulStop()
	}
}

func (vs *Server) prepare() (net.Listener, error) {
	address := vs.Address
	if vs.Address == "" {
		address = "127.0.0.1:0"
		logrus.Infof("Will try to bind a self assigned address: %s", address)
	} else {
		logrus.Infof("Will try to bind %s address", address)
	}

	lis, err := net.Listen("tcp", address)
	if err != nil {
		logrus.Warnf("Binding of %s has failed: %v, will try to bind it on tcp6", address, err)
		if lis, err = net.Listen("tcp6", address); err != nil {
			return lis, err
		}
	}
	if vs.Address == "" {
		address = lis.Addr().String()
		logrus.Infof("Since address for GRPC server was not defined, will use a self assigned value '%s'", address)
	}
	logrus.Infof("Starting GRPC Server at %s", address)

	for _, reg := range vs.regFuncs {
		reg(vs.grpcServer)
	}
	vs.Address = address
	return lis, nil
}
