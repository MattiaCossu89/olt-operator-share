//Package config handles configuration items
package config

import (
	"fmt"
	"sync"

	"github.com/sirupsen/logrus"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	kube "sigs.k8s.io/controller-runtime/pkg/client"
)

//Manager returns whitelisted onu config
type Manager struct {
	data       *sync.Map
	clusterMgr *EndpointManager
}

//NewManager constructor of Manager
func NewManager(cfg Config, c kube.Client) *Manager {
	mapData := &sync.Map{}

	for _, onu := range cfg.WhitelistOnus {
		mapData.Store(onu.Sn, onu)
	}

	return &Manager{
		data:       mapData,
		clusterMgr: NewEndpointManager(c),
	}
}

//Add adds Onus to the collection
func (cm *Manager) Add(onu Onu) {
	cm.data.Store(onu.Sn, onu)
}

//FindOnuConfig finds a whitelisted onu config
/* func (cm *Manager) FindOnuConfig(onuSn string) (bool, Onu) {
	log.Printf("Will try to find an ONU configuration for sn %s", onuSn)
	val, ok := cm.data.Load(onuSn)
	if !ok {

		log.Printf("Didn't find ONU configuration for SN %s", onuSn)
		return false, Onu{}
	}

	onu, ok := val.(Onu)
	if !ok {
		log.Printf("ONU configuration is incorrectly stored for SN %s", onuSn)
		return false, Onu{}
	}
	log.Printf("Found configuration for onu %s: %+v", onuSn, onu)

	return true, onu
} */

func (cm *Manager) FindOnuConfig(onuSn string) (bool, Onu) {
	onts, err := cm.clusterMgr.ontClient.List(metav1.ListOptions{})
	if err != nil {
		logrus.Error(err)
	}

	for _, ont := range onts.Items {

		snConverted, err := serialToHex(ont.Spec.SerialNo)
		if err != nil {
			logrus.Error(err)
		}

		//Check for the correct ont
		if snConverted != onuSn {
			continue
		}

		//get service profiles
		serviceProfile, err := cm.clusterMgr.getServiceProfile(&ont)
		if err != nil {
			logrus.Error(err)
		}
		//get techprofile
		techProfile, err := cm.clusterMgr.getTechProfile(serviceProfile)
		if err != nil {
			logrus.Error(err)
		}

		//Get venets
		venets, err := cm.clusterMgr.getVenetsFromService(serviceProfile)
		if err != nil {
			logrus.Error(err)
		}

		onu := Onu{
			Sn:                   snConverted,
			Type:                 "ONT",
			STag:                 fmt.Sprint(venets[0].Spec.Svlan),
			CTag:                 fmt.Sprint(venets[0].Spec.Cvlan),
			UniTagMatch:          fmt.Sprint(venets[0].Spec.Uvlan),
			ConfiguredMacAddress: ont.Spec.MacAddress,
			Profile:              fmt.Sprint(techProfile.Spec.Id),
		}

		return true, onu
	}
	return false, Onu{}
}

//Add adds Onus to the collection
func (cm *Manager) Read() Onus {
	onus := Onus{}
	cm.data.Range(func(key, value interface{}) bool {
		onus = append(onus, value.(Onu))
		return true
	})

	return onus
}

//Delete removes an Onu from the collection
func (cm *Manager) Delete(sn string) error {
	_, ok := cm.data.Load(sn)
	if ok {
		cm.data.Delete(sn)
		return nil
	}

	return fmt.Errorf("cannot delete sn %s as it doesn't exist", sn)
}
