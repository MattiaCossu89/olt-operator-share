//Package config handles configuration items
package config

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/sirupsen/logrus"
)

//HTTPHandler gives http interface for managing config
type HTTPHandler struct {
	Manager *Manager
}

//ServeHTTP Handler implementation
func (hh *HTTPHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		hh.handlePost(w, r)
		return
	}

	if r.Method == http.MethodGet {
		hh.handleGet(w, r)
		return
	}

	if r.Method == http.MethodDelete {
		hh.handleDelete(w, r)
		return
	}

	msg := fmt.Sprintf("unsupported http method %s", r.Method)
	logrus.Warn(msg)
	http.Error(w, msg, http.StatusMethodNotAllowed)
}

func (hh *HTTPHandler) handlePost(w http.ResponseWriter, r *http.Request) {
	logrus.Infof("Received POST request at '%s'", r.URL.String())

	var onus []Onu
	jsonDecoder := json.NewDecoder(r.Body)
	err := jsonDecoder.Decode(&onus)
	if err != nil {
		msg := fmt.Sprintf("Failed to decode request body to []Onus: %v", err)
		logrus.Error(msg)
		http.Error(w, msg, http.StatusBadRequest)
		return
	}

	logrus.Infof("Successfully decoded request body")
	logrus.Debugf("Request body: %+v", onus)

	for _, on := range onus {
		hh.Manager.Add(on)
	}

	msg := fmt.Sprintf("Added %d ONUs to the internal db", len(onus))
	logrus.Infof(msg)
	_, err = w.Write([]byte(msg))
	if err != nil {
		logrus.Error(err.Error())
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}

func (hh *HTTPHandler) handleGet(w http.ResponseWriter, r *http.Request) {
	logrus.Infof("Received GET request at '%s'", r.URL.String())

	onus := hh.Manager.Read()

	jsonEncoder := json.NewEncoder(w)
	err := jsonEncoder.Encode(onus)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		logrus.Error(err.Error())
		return
	}

	logrus.Infof("Read %d ONUs from the internal db", len(onus))
}

func (hh *HTTPHandler) handleDelete(w http.ResponseWriter, r *http.Request) {
	logrus.Infof("Received Delete request at '%s'", r.URL.String())

	d := json.NewDecoder(r.Body)
	onuSNs := make([]string, 0)
	err := d.Decode(&onuSNs)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		logrus.Error(err.Error())
		return
	}

	logrus.Infof("Delete request body '%v'", onuSNs)

	errCont := ""
	for _, onuSN := range onuSNs {
		err = hh.Manager.Delete(onuSN)
		if err != nil {
			errCont += err.Error()
		}
	}

	err = fmt.Errorf(errCont)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		logrus.Error(err.Error())
		return
	}

	msg := fmt.Sprintf("Deleted %d ONUs to the internal db", len(onuSNs))
	logrus.Infof(msg)
	_, err = w.Write([]byte(msg))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		logrus.Error(err.Error())
		return
	}
}
