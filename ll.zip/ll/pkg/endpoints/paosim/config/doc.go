//Package config manages configuration for PAO simulator
package config
