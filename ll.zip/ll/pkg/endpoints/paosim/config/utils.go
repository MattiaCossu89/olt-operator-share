package config

import (
	"context"
	"encoding/hex"
	"errors"
	"strings"

	doltitv1alpha1 "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/client"
	kube "sigs.k8s.io/controller-runtime/pkg/client"

	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/rest"
)

type EndpointManager struct {
	KubeClient       kube.Client
	ontClient        client.OntInterface
	oltClient        client.OltInterface
	accessNodeClient client.AccessNodeInterface
	ctx              context.Context
}

func NewEndpointManager(c kube.Client) *EndpointManager {
	mgr := &EndpointManager{
		KubeClient: c,
	}

	config, err := rest.InClusterConfig()
	if err != nil {
		return nil
	}

	clientset, err := client.NewForConfig(config)
	if err != nil {
		return nil
	}

	ontClient := clientset.Onts(context.TODO(), "olt-operator-system")

	mgr.ontClient = ontClient

	oltClient := clientset.Olts(context.TODO(), "olt-operator-system")

	mgr.oltClient = oltClient

	accessNodeClient := clientset.AccessNodes(context.TODO(), "olt-operator-system")

	mgr.accessNodeClient = accessNodeClient

	mgr.ctx = context.Background()

	return mgr
}

func serialToHex(sn string) (string, error) {
	if len(sn) < 4 {
		return "", errors.New("serial number too short")
	}
	prefix := sn[0:4]
	prefixHex := hex.EncodeToString([]byte(prefix))
	rest := sn[4:]
	return strings.ToUpper(prefixHex + rest), nil
}

func (e *EndpointManager) getServiceProfile(ont *doltitv1alpha1.Ont) (*doltitv1alpha1.ServiceProfile, error) {
	serviceProfile := &doltitv1alpha1.ServiceProfile{}
	namespacedName := types.NamespacedName{
		Namespace: "olt-operator-system",
		Name:      ont.Spec.ServiceId,
	}
	err := e.KubeClient.Get(e.ctx, namespacedName, serviceProfile)
	if err != nil {
		return nil, err
	}
	return serviceProfile, nil
}

func (e *EndpointManager) getTechProfile(serviceProfile *doltitv1alpha1.ServiceProfile) (*doltitv1alpha1.TechProfile, error) {
	techProfile := &doltitv1alpha1.TechProfile{}
	namespacedName := types.NamespacedName{
		Namespace: "olt-operator-system",
		Name:      serviceProfile.Spec.ServiceInfo[0].TechProfileId,
	}
	err := e.KubeClient.Get(e.ctx, namespacedName, techProfile)
	if err != nil {
		return nil, err
	}
	return techProfile, nil
}
func (e *EndpointManager) getVenetsFromService(serviceProfile *doltitv1alpha1.ServiceProfile) ([]*doltitv1alpha1.Venet, error) {
	var venets = make([]*doltitv1alpha1.Venet, 0)
	for _, si := range serviceProfile.Spec.ServiceInfo {
		v := &doltitv1alpha1.Venet{}
		namespacedName := types.NamespacedName{
			Namespace: "olt-operator-system",
			Name:      si.VenetProfileId,
		}
		err := e.KubeClient.Get(e.ctx, namespacedName, v)
		if err != nil {
			return nil, err
		}
		venets = append(venets, v)
	}
	return venets, nil
}

func (e *EndpointManager) getAccessNode(accessNodeId string) (*doltitv1alpha1.AccessNode, error) {
	an := &doltitv1alpha1.AccessNode{}
	namespacedName := types.NamespacedName{
		Namespace: "olt-operator-system",
		Name:      accessNodeId,
	}
	err := e.KubeClient.Get(e.ctx, namespacedName, an)
	if err != nil {
		return nil, err
	}
	return an, nil
}
