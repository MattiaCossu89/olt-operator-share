//Package config manages configuration for PAO simulator
package config

//Onu contains configuration item for an ONU
type Onu struct {
	Sn                   string `json:"sn"`
	Type                 string `json:"type"`
	CTag                 string `json:"ctag"`
	STag                 string `json:"stag"`
	UniTagMatch          string `json:"uniTagMatch"`
	ConfiguredMacAddress string `json:"configuredMacAddress"`
	Profile              string `json:"profile"`
}

//Onus collection of ONUs
type Onus []Onu

//Config General config for paosim
type Config struct {
	WhitelistOnus Onus `json:"whitelistONUs"`
}

//NewConfig constructor
func NewConfig() Config {
	return Config{
		WhitelistOnus: Onus{},
	}
}
