//Package config manages configuration for PAO simulator
package config

import (
	"encoding/json"
	"io/ioutil"
	"os"
	"path/filepath"

	"github.com/sirupsen/logrus"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

//GetConfig reads config from filesystem
func GetConfig() (Config, error) {
	filePath := env.ReadEnv("PAO_SIMULATOR_CONFIG_PATH", "")
	if filePath == "" {
		logrus.Warnf("Empty config path")
		return NewConfig(), nil
	}

	filePathSecure := filepath.Clean(filePath)

	if _, err := os.Stat(filePathSecure); os.IsNotExist(err) {
		logrus.Warnf("File config %s doesn't exist ", filePathSecure)
		return NewConfig(), nil
	}

	logrus.Infof("Will read config file '%s'", filePathSecure)
	data, err := ioutil.ReadFile(filepath.Clean(filePathSecure))

	if err != nil {
		return NewConfig(), err
	}

	dataToLog := data
	if len(data) > 2000 {
		dataToLog = data[0:2000]
	}
	logrus.Debugf("Read config file: %s", string(dataToLog))

	var config Config
	err = json.Unmarshal(data, &config)
	if err != nil {
		return NewConfig(), err
	}

	return config, nil
}
