package sadis

import (
	"context"
	"encoding/json"

	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

type SadisBandProfilePayload struct {
	Id  string `json:"id"`
	Cir int    `json:"cir"`
	Cbs int    `json:"cbs"`
	Eir int    `json:"eir"`
	Ebs int    `json:"ebs"`
	Air int    `json:"air"`
}

func SearchBandprofile(name string) (SadisBandProfilePayload, bool, error) {
	clientset, err := controllers_utils.GetClientSet()
	if err != nil {
		return SadisBandProfilePayload{}, false, err
	}

	bandProfilesClient := clientset.BandProfiles(context.TODO(), "olt-operator-system")
	bandprofiles, err := bandProfilesClient.List(v1.ListOptions{})
	if err != nil {
		return SadisBandProfilePayload{}, false, err
	}

	for _, bandprofile := range bandprofiles.Items {
		if bandprofile.Spec.Id == name {
			return SadisBandProfilePayload{
				Id:  bandprofile.Spec.Id,
				Cir: bandprofile.Spec.Cir,
				Cbs: bandprofile.Spec.Cbs,
				Eir: bandprofile.Spec.Eir,
				Ebs: bandprofile.Spec.Ebs,
				Air: bandprofile.Spec.Air,
			}, true, nil
		}
	}

	return SadisBandProfilePayload{}, false, nil
}

func DefaultBandwithProfile() SadisBandProfilePayload {
	bwprofile := SadisBandProfilePayload{
		Id:  "Default",
		Cir: 600,
		Cbs: 30,
		Eir: 400,
		Ebs: 30,
		Air: 100000,
	}

	response, err := env.ReadEnvOrError("DEFAULT_BANDWITH_PROFILE")
	if err != nil {
		return bwprofile
	}

	test := SadisBandProfilePayload{}
	//Check if the json is ok
	err = json.Unmarshal([]byte(response), test)
	if err != nil {
		logger.Info("The json provided for the default bandwith profile is malformed, the default one can't be overwritten")
		return bwprofile
	}
	return test
}
