package sadis

import (
	"encoding/json"

	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func (e *EndpointManager) searchBandProfile(name string) (bool, string, error) {
	bandProfileList, err := e.bandProfileClient.List(v1.ListOptions{})
	if err != nil {
		return false, "", err
	}
	for _, bp := range bandProfileList.Items {
		if bp.Spec.Id == name {
			data, err := json.Marshal(bp.Spec)
			if err != nil {
				return false, "", err
			}
			return true, string(data), nil
		}
	}
	return false, "", nil
}
