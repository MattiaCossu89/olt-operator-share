package sadis

import (
	"context"
	"errors"

	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
)

var upLinkPorts = map[string]string{
	//"openolt":   "1048576", Voltha v < 2.8
	//"adtranolt": "1048832", Voltha v < 2.8
	"openolt":   "16777216",
	"adtranolt": "16777472",
}

type SadisOltPayload struct {
	Id                 string `json:"id"`
	HardwareIdentifier string `json:"hardwareIdentifier"`
	IpAddress          string `json:"ipAddress"`
	UplinkPort         string `json:"uplinkPort"`
	NasId              string `json:"nasId"`
}

func SearchOlt(name string) (SadisOltPayload, bool, error) {
	clientset, err := controllers_utils.GetClientSet()
	if err != nil {
		return SadisOltPayload{}, false, err
	}

	oltClient := clientset.Olts(context.TODO(), "olt-operator-system")
	olts, err := oltClient.List(v1.ListOptions{})
	if err != nil {
		return SadisOltPayload{}, false, err
	}

	for _, olt := range olts.Items {
		if olt.Spec.SerialNo == name {
			payload, err := buildOltPayload(&olt)
			if err != nil {
				return SadisOltPayload{}, false, err
			}
			return payload, true, nil
		}
	}
	return SadisOltPayload{}, false, nil
}

func buildOltPayload(olt *v1alpha1.Olt) (SadisOltPayload, error) {

	if upLinkPort, ok := upLinkPorts[olt.Spec.Model]; ok {

		nasId := "0001014f891cdb07"

		return SadisOltPayload{
			Id:                 olt.Spec.SerialNo,
			HardwareIdentifier: olt.Spec.MacAddress,
			IpAddress:          olt.Spec.IpAddress,
			UplinkPort:         upLinkPort,
			NasId:              nasId,
		}, nil
		//do something here
	}
	return SadisOltPayload{}, errors.New("Olt model not supported, impossible to assign an upLinkPort")

}
