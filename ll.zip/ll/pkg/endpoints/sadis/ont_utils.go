package sadis

import (
	"context"
	"strconv"
	"strings"

	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/sadis"
)

func SearchOnt(name string) (sadis.OntMetric, bool, error) {
	clientset, err := controllers_utils.GetClientSet()
	if err != nil {
		return sadis.OntMetric{}, false, err
	}

	cleanName := strings.Trim(name, "-1")

	ontClient := clientset.Onts(context.TODO(), "olt-operator-system")
	onts, err := ontClient.List(v1.ListOptions{})
	if err != nil {
		return sadis.OntMetric{}, false, err
	}

	for _, ont := range onts.Items {
		if ont.Spec.SerialNo == cleanName {
			payload, err := buildOntPayload(&ont)
			if err != nil {
				return sadis.OntMetric{}, false, err
			}
			return payload, true, err
		}
	}
	return sadis.OntMetric{}, false, nil
}

func buildOntPayload(ont *v1alpha1.Ont) (sadis.OntMetric, error) {

	clientset, err := controllers_utils.GetClientSet()
	if err != nil {
		return sadis.OntMetric{}, err
	}

	serviceProfileClient := clientset.ServiceProfiles(context.TODO(), "olt-operator-system")
	techProfileClient := clientset.TechProfiles(context.TODO(), "olt-operator-system")
	venetClient := clientset.Venets(context.TODO(), "olt-operator-system")

	serviceProfile, err := serviceProfileClient.Get(ont.Spec.ServiceId, v1.GetOptions{})
	if err != nil {
		return sadis.OntMetric{}, err
	}

	sadisPayload := sadis.OntMetric{}
	sadisPayload.Id = ont.Spec.SerialNo + "-1"
	sadisPayload.NasPortId = ont.Spec.SerialNo + "-1"
	sadisPayload.CircuitId = ont.Spec.CircuitId
	sadisPayload.RemoteId = ont.Spec.SubscriberId

	for _, serviceInfo := range serviceProfile.Spec.ServiceInfo {

		uniTagItem := sadis.UniTagItem{}

		techProfile, err := techProfileClient.Get(serviceInfo.TechProfileId, v1.GetOptions{})
		if err != nil {
			logger.Error(err, "Failed to fetch the TechProfile", "techprofile_id", serviceInfo.TechProfileId)
			return sadis.OntMetric{}, err
		}

		venet, err := venetClient.Get(serviceInfo.VenetProfileId, v1.GetOptions{})
		if err != nil {
			logger.Error(err, "Failed to fetch the Venet", "venet_id", serviceInfo.VenetProfileId)
			return sadis.OntMetric{}, err
		}

		uniTagItem.ServiceName = serviceInfo.ServiceName
		uniTagItem.PonCTag = venet.Spec.Cvlan
		uniTagItem.PonSTag = venet.Spec.Svlan
		uniTagItem.TechnologyProfileId = strconv.Itoa(techProfile.Spec.Id)
		uniTagItem.UpStreamBandwidthProfile = serviceInfo.UpstreamBandwidthProfile
		uniTagItem.DownStreamBandwidthProfile = serviceInfo.DownstreamBandwidthProfile
		uniTagItem.IsDhcpRequired = venet.Spec.IsDhcpEnabled
		uniTagItem.IsIgmpRequired = venet.Spec.IsIgmpEnabled
		uniTagItem.IsPppoeRequired = venet.Spec.IsPppoeEnabled
		uniTagItem.UniTagMatch = venet.Spec.Uvlan
		uniTagItem.ConfiguredMacAddress = ont.Spec.MacAddress
		sadisPayload.UniTagList = append(sadisPayload.UniTagList, uniTagItem)
	}

	return sadisPayload, nil
}
