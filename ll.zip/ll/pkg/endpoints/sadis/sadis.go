package sadis

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/go-logr/logr"
	"github.com/gorilla/mux"
	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/log/zap"
)

var logger logr.Logger = zap.New()

type EndpointManager struct {
	ontClient            client.OntInterface
	oltClient            client.OltInterface
	accessNodeClient     client.AccessNodeInterface
	venetClient          client.VenetInterface
	techProfileClient    client.TechProfileInterface
	serviceProfileClient client.ServiceProfileInterface
	bandProfileClient    client.BandProfileInterface
	ctx                  context.Context
	log                  logr.Logger
}

func NewEndpointManager() *EndpointManager {

	config, err := rest.InClusterConfig()
	if err != nil {
		return nil
	}

	clientset, err := client.NewForConfig(config)
	if err != nil {
		return nil
	}

	mgr := &EndpointManager{
		ontClient:            clientset.Onts(context.TODO(), "olt-operator-system"),
		oltClient:            clientset.Olts(context.TODO(), "olt-operator-system"),
		accessNodeClient:     clientset.AccessNodes(context.TODO(), "olt-operator-system"),
		venetClient:          clientset.Venets(context.TODO(), "olt-operator-system"),
		techProfileClient:    clientset.TechProfiles(context.TODO(), "olt-operator-system"),
		serviceProfileClient: clientset.ServiceProfiles(context.TODO(), "olt-operator-system"),
		bandProfileClient:    clientset.BandProfiles(context.TODO(), "olt-operator-system"),
		ctx:                  context.Background(),
	}

	return mgr
}

func (e *EndpointManager) GetHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	key := vars["key"]
	logger.Info(fmt.Sprintf("Sadis simulator endpoint called, tryng to find resource with key: %s", key))

	if key == "Default" {
		logger.Info("Responding with default bandwith profile")
		bandprofilePayload := DefaultBandwithProfile()
		resp, err := json.Marshal(bandprofilePayload)
		if err != nil {
			logger.Error(err, "Error while marshaling the payload")
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Add("Content-Type", "application/json")
		_, err = w.Write(resp)
		if err != nil {
			logger.Error(err, "Error while writing response")
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
	}

	oltPayload, found, err := SearchOlt(key)
	if err != nil {
		logger.Error(err, "Error while searching olt")
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	} else if found {
		logger.Info(fmt.Sprintf("Olt found, sending: %v", oltPayload))
		resp, err := json.Marshal(oltPayload)
		if err != nil {
			logger.Error(err, "Error while marshaling the payload")
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Add("Content-Type", "application/json")
		_, err = w.Write(resp)
		if err != nil {
			logger.Error(err, "Error while writing response")
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		return
	}

	ontPayload, found, err := SearchOnt(key)
	if err != nil {
		logger.Error(err, "Error while searching ont")
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	} else if found {
		logger.Info(fmt.Sprintf("Ont found, sending: %v", ontPayload))
		resp, err := json.Marshal(ontPayload)
		if err != nil {
			logger.Error(err, "Error while marshaling the payload")
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Add("Content-Type", "application/json")
		_, err = w.Write(resp)
		if err != nil {
			logger.Error(err, "Error while writing response")
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		return
	}

	bandprofilePayload, found, err := SearchBandprofile(key)
	if err != nil {
		logger.Error(err, "Error while searching bandprofile")
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	} else if found {
		logger.Info(fmt.Sprintf("Bandprofile found, sending: %v", bandprofilePayload))
		resp, err := json.Marshal(bandprofilePayload)
		if err != nil {
			logger.Error(err, "Error while marshaling the payload")
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Add("Content-Type", "application/json")
		_, err = w.Write(resp)
		if err != nil {
			logger.Error(err, "Error while writing response")
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		return
	}

	logger.Info(fmt.Sprintf("No resource found with key %s, responding 404", key))
	http.Error(w, "{\"message\":\"Entry with ID "+key+" not found.\",\"statusCode\":404}", http.StatusNotFound)

}
