package sadis

import (
	"bytes"
	"encoding/json"
	"errors"
	"io/ioutil"
	"net/http"
	"strconv"

	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

type SadisClient struct {
	Endpoint string
}

//ont payloads

type UniTagItem struct {
	ServiceName                string `json:"serviceName"`
	PonCTag                    int    `json:"ponCTag"`
	PonSTag                    int    `json:"ponSTag"`
	TechnologyProfileId        string `json:"technologyProfileId"`
	UpStreamBandwidthProfile   string `json:"upstreamBandwidthProfile"`
	DownStreamBandwidthProfile string `json:"downstreamBandwidthProfile"`
	IsDhcpRequired             bool   `json:"isDhcpRequired"`
	IsIgmpRequired             bool   `json:"isIgmpRequired"`
	IsPppoeRequired            bool   `json:"isPppoeRequired"`
	UniTagMatch                int    `json:"uniTagMatch"`
	ConfiguredMacAddress       string `json:"configuredMacAddress"`
}

type OntMetric struct {
	Id         string       `json:"id"`
	NasPortId  string       `json:"nasPortId"`
	CircuitId  string       `json:"circuitId"`
	RemoteId   string       `json:"remoteId"`
	UniTagList []UniTagItem `json:"uniTagList"`
}

func NewSadisClient() *SadisClient {
	client := new(SadisClient)
	client.Endpoint = env.ReadEnv("SADIS_ENDPOINT", "http://consul-headless.voltha:8500/v1/kv/sadisEntries/")
	return client
}

func (r *SadisClient) AddMetric(title string, jsonData []byte) error {

	httpClient := &http.Client{}

	request, err := http.NewRequest(http.MethodPut, r.Endpoint+title+"?raw=1", bytes.NewBuffer(jsonData))
	//_ = events.NewEventRecorder("bandprofile", "olt-operator-system", nil, "Normal", "response", string(resp.Status))
	if err != nil {
		return err
	}

	request.Header.Set("Content-type", "application/json; charset=utf-8")
	_, err = httpClient.Do(request)
	if err != nil {
		return err
	}
	return nil
}

func (r *SadisClient) DeleteMetric(title string) error {

	httpClient := &http.Client{}

	request, err := http.NewRequest("DELETE", r.Endpoint+title+"?raw=1", nil)
	//_ = events.NewEventRecorder("bandprofile", "olt-operator-system", nil, "Normal", "response", string(resp.Status))
	if err != nil {
		return err
	}

	_, err = httpClient.Do(request)
	if err != nil {
		return err
	}
	return nil
}

func (r *SadisClient) GetKeys() ([]string, error) {
	httpClient := &http.Client{}

	var output []string

	request, err := http.NewRequest("GET", r.Endpoint+"?keys", nil)

	if err != nil {
		return nil, err
	}

	response, err := httpClient.Do(request)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()

	if response.StatusCode >= 200 && response.StatusCode <= 210 {

		responseData, err := ioutil.ReadAll(response.Body)
		if err != nil {
			return nil, err
		}

		json.Unmarshal([]byte(responseData), &output)

		for i := 0; i < len(output); i++ {
			output[i] = output[i][13:len(output[i])]
		}

		return output, nil
	}
	return nil, errors.New("Something goes wrong, response status is " + strconv.Itoa(response.StatusCode))
}

func (r *SadisClient) GetMetric(key string) (interface{}, error) {
	httpClient := &http.Client{}

	var output interface{}

	request, err := http.NewRequest("GET", r.Endpoint+key+"?raw=1", nil)

	if err != nil {
		return nil, err
	}

	response, err := httpClient.Do(request)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()

	if response.StatusCode >= 200 && response.StatusCode <= 210 {

		responseData, err := ioutil.ReadAll(response.Body)
		if err != nil {
			return nil, err
		}

		json.Unmarshal([]byte(responseData), &output)

		return output, nil
	}
	return nil, errors.New("Something goes wrong, response status is " + strconv.Itoa(response.StatusCode))
}

func (r *SadisClient) GetAllMetrics() ([]interface{}, error) {

	var output []interface{}
	var tmp interface{}

	keys, err := r.GetKeys()
	if err != nil {
		return nil, err
	}

	for i := 0; i < len(keys); i++ {

		tmp, err = r.GetMetric(keys[i])
		if err != nil {
			return nil, err
		}
		output = append(output, tmp)
	}

	return output, nil
}
