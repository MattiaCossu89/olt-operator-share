package ont_utils

import (
	"github.com/go-logr/logr"
	"github.com/opencord/voltha-protos/v4/go/voltha"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/voltha/commands"
)

func DeviceList(log logr.Logger) ([]*voltha.Device, error) {
	options := &commands.DeviceList{}
	devices, err := options.Execute()
	if err != nil {
		log.Error(err, "error retrieving the devices list from voltha")
		return nil, err
	}
	for _, device := range devices {
		log.Info("found device in voltha", "id", device.Id)
	}
	return devices, nil
}

func DeviceReboot(log logr.Logger, deviceId string) error {
	ids := make([]commands.DeviceId, 0)
	ids = append(ids, commands.DeviceId(deviceId))
	options := &commands.DeviceReboot{
		Ids: ids,
	}
	err := options.Execute()
	if err != nil {
		return err
	}
	return nil
}
