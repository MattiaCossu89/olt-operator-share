package ont_utils

import (
	"context"
	"fmt"

	"github.com/go-logr/logr"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	paoClient "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/paosim/client"
)

func UpdatePaoSim(log logr.Logger, serviceProfile *v1alpha1.ServiceProfile, ont *v1alpha1.Ont) {
	todo := env.ReadEnv("UPDATE_PAOSIM", "true")
	if todo != "true" {
		return
	}

	c := paoClient.NewClient()
	clientset, err := controllers_utils.GetClientSet()
	if err != nil {
		return
	}
	techProfileClient := clientset.TechProfiles(context.TODO(), "olt-operator-system")
	venetClient := clientset.Venets(context.TODO(), "olt-operator-system")

	techProfile, err := techProfileClient.Get(serviceProfile.Spec.ServiceInfo[0].TechProfileId, v1.GetOptions{})
	if err != nil {
		log.Error(err, "Failed to fetch the TechProfile", "techprofile_id", serviceProfile.Spec.ServiceInfo[0].TechProfileId)
		return
	}

	// Fetch the Venet
	var venets = make([]*v1alpha1.Venet, 0)
	for _, si := range serviceProfile.Spec.ServiceInfo {
		//v, err := r.getVenet(ctx, si.VenetProfileId, ont.Namespace)
		v, err := venetClient.Get(si.VenetProfileId, v1.GetOptions{})
		if err != nil {
			log.Error(err, "Failed to fetch the Venet", "venet_id", si.VenetProfileId)
			return
		}
		venets = append(venets, v)
	}

	// Remove the ONT from PAOsim
	log.Info("Removing Ont from PaoSim", "serialNo", ont.Spec.SerialNo)
	res, err := c.RemoveONU(ont.Spec.SerialNo)
	if err != nil {
		// Error reading the object - requeue the request.
		log.Error(err, "Failed to remove the Ont from PaoSim")
	}
	log.Info("response from paoSim: " + fmt.Sprint(res.StatusCode))

	// Add the ONT to PAOSim
	log.Info("Adding Ont to PaoSim", "serialNo", ont.Spec.SerialNo)
	res, err = c.AddONU(log, ont, venets[0], techProfile)
	if err != nil {
		// Error reading the object - requeue the request.
		log.Error(err, "Failed to add the Ont to PaoSim")
	}
	log.Info("response from paoSim: " + fmt.Sprint(res.StatusCode))
}
