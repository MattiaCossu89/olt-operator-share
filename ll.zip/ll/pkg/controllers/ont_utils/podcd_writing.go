package ont_utils

import (
	"context"
	"fmt"

	"github.com/go-logr/logr"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	podcdClient "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/podcd/client"
)

func UpdatePodCD(log logr.Logger, ont *v1alpha1.Ont) {
	todo := env.ReadEnv("UPDATE_PODCD", "true")
	if todo != "true" {
		return
	}

	pcd := podcdClient.NewClient()
	clientset, err := controllers_utils.GetClientSet()
	if err != nil {
		return
	}
	accessNodeClient := clientset.AccessNodes(context.TODO(), "olt-operator-system")
	oltClient := clientset.Olts(context.TODO(), "olt-operator-system")

	olt, err := oltClient.Get(ont.Spec.ParentId, v1.GetOptions{})
	if err != nil {
		log.Error(err, "Failed to fetch the Olt", "olt_id", ont.Spec.ParentId)
		return
	}

	an, err := accessNodeClient.Get(olt.Spec.ParentId, v1.GetOptions{})
	if err != nil {
		log.Error(err, "Failed to fetch the AccessNode", "an_id", olt.Spec.ParentId)
		return
	}

	log.Info("Removing Ont from PodCD", "id", ont.Spec.Id)
	res, err := pcd.RemoveResource(ont.Spec.Id)
	if err != nil {
		// Error reading the object - requeue the request.
		log.Error(err, "Failed to remove the Ont from PodCD")
	}
	log.Info("response from PodCD: " + fmt.Sprint(res.StatusCode))

	// Add the ONT to PodCD
	log.Info("Adding Ont to PodCD", "id", ont.Spec.Id)
	chars := []podcdClient.Characteristic{
		{
			Name:  "relationship",
			Value: an.Spec.Id,
		},
		{
			Name:  "ztpIdent",
			Value: ont.Spec.SerialNo,
		},
		{
			Name:  "operationalData",
			Value: "",
		},
		{
			Name:  "onuId",
			Value: ont.Spec.OnuId,
		},
	}
	lr := &podcdClient.Resource{
		ont.Spec.Id: chars,
	}
	res, err = pcd.AddResource(lr)
	if err != nil {
		// Error reading the object - requeue the request.
		log.Error(err, "Failed to add the Ont to PodCD")
	}
	log.Info("response from PodCD: " + fmt.Sprint(res.StatusCode))
}
