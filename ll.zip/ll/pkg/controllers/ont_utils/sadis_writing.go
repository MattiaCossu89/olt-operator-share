package ont_utils

import (
	"context"
	"encoding/json"
	"strconv"

	"github.com/go-logr/logr"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/events"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/sadis"
)

type ServiceInfoContainer struct {
	ServiceName                string
	Venet                      *v1alpha1.Venet
	TechProfile                *v1alpha1.TechProfile
	DownStreamBandwidthProfile string
	UpStreamBandwidthProfile   string
}

type ServiceProfileContainer struct {
	Id          string
	Name        string
	ServiceInfo []ServiceInfoContainer
}

func AddToSadis(log logr.Logger, serviceProfile *v1alpha1.ServiceProfile, ont *v1alpha1.Ont) error {
	todo := env.ReadEnv("UPDATE_SADIS", "true")
	if todo != "true" {
		return nil
	}

	clientset, err := controllers_utils.GetClientSet()
	if err != nil {
		return err
	}

	techProfileClient := clientset.TechProfiles(context.TODO(), "olt-operator-system")
	venetClient := clientset.Venets(context.TODO(), "olt-operator-system")

	serviceProfileC := ServiceProfileContainer{}
	serviceProfileC.Id = serviceProfile.Spec.Id
	serviceProfileC.Name = serviceProfile.Spec.Name

	for i := 0; i < len(serviceProfile.Spec.ServiceInfo); i++ {

		tmpServiceInfo := ServiceInfoContainer{}

		//techProfile, err := r.getTechProfile(ctx, serviceProfile.Spec.ServiceInfo[i].TechProfileId, ont.Namespace)
		techProfile, err := techProfileClient.Get(serviceProfile.Spec.ServiceInfo[i].TechProfileId, v1.GetOptions{})
		if err != nil {
			log.Error(err, "Failed to fetch the TechProfile", "techprofile_id", serviceProfile.Spec.ServiceInfo[i].TechProfileId)
			return err
		}

		//venet, err := r.getVenet(ctx, serviceProfile.Spec.ServiceInfo[i].VenetProfileId, ont.Namespace)
		venet, err := venetClient.Get(serviceProfile.Spec.ServiceInfo[i].VenetProfileId, v1.GetOptions{})
		if err != nil {
			log.Error(err, "Failed to fetch the Venet", "venet_id", serviceProfile.Spec.ServiceInfo[i].VenetProfileId)
			return err
		}

		tmpServiceInfo.ServiceName = serviceProfile.Spec.ServiceInfo[i].ServiceName
		tmpServiceInfo.UpStreamBandwidthProfile = serviceProfile.Spec.ServiceInfo[i].UpstreamBandwidthProfile
		tmpServiceInfo.DownStreamBandwidthProfile = serviceProfile.Spec.ServiceInfo[i].DownstreamBandwidthProfile
		tmpServiceInfo.TechProfile = techProfile
		tmpServiceInfo.Venet = venet
		serviceProfileC.ServiceInfo = append(serviceProfileC.ServiceInfo, tmpServiceInfo)
	}

	PutOntSadis(log, ont, serviceProfileC)
	return nil
}

func PutOntSadis(log logr.Logger, ont *v1alpha1.Ont, container ServiceProfileContainer) {

	//That variable will be used to create the rest body to send in Sadis
	payload := sadis.OntMetric{}

	payload.Id = ont.Spec.SerialNo + "-1"
	payload.NasPortId = ont.Spec.SerialNo + "-1"

	for i := 0; i < len(container.ServiceInfo); i++ {

		tmpContainer := container.ServiceInfo[i]

		tmpUniTagItem := sadis.UniTagItem{

			ServiceName:                tmpContainer.ServiceName,
			PonCTag:                    tmpContainer.Venet.Spec.Cvlan,
			PonSTag:                    tmpContainer.Venet.Spec.Svlan,
			TechnologyProfileId:        strconv.Itoa(tmpContainer.TechProfile.Spec.Id),
			UpStreamBandwidthProfile:   tmpContainer.UpStreamBandwidthProfile,
			DownStreamBandwidthProfile: tmpContainer.DownStreamBandwidthProfile,
			IsDhcpRequired:             tmpContainer.Venet.Spec.IsDhcpEnabled,
			IsIgmpRequired:             tmpContainer.Venet.Spec.IsIgmpEnabled,
			IsPppoeRequired:            tmpContainer.Venet.Spec.IsPppoeEnabled,
			UniTagMatch:                tmpContainer.Venet.Spec.Uvlan,
			ConfiguredMacAddress:       ont.Spec.MacAddress,
		}

		payload.UniTagList = append(payload.UniTagList, tmpUniTagItem)

	}

	data, _ := json.Marshal(payload)

	sadisClient := sadis.NewSadisClient()
	err := sadisClient.AddMetric(payload.Id, data)
	if err != nil {
		_ = events.NewEventRecorder("ont", "olt-operator-system", ont, "Normal", "Error while writing sadis", err.Error())
	} else {
		_ = events.NewEventRecorder("ont", "olt-operator-system", ont, "Normal", "Successfuly added to sadis", "Ont serialNumber: "+ont.Spec.SerialNo)
	}
	//do request
}
