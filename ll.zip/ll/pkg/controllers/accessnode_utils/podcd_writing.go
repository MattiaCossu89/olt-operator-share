package accessnode_utils

import (
	"fmt"

	"github.com/go-logr/logr"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	podcdClient "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/podcd/client"
)

func UpdatePodCD(log logr.Logger, an *v1alpha1.AccessNode) {
	todo := env.ReadEnv("UPDATE_PODCD", "true")
	log.Info("UPDATE_PODCD", "id", todo)
	if todo != "true" {
		return
	}
	c := podcdClient.NewClient()

	// Remove the AccessNode from PodCD
	log.Info("Removing AccessNode from PodCD", "id", an.Spec.Id)
	res, err := c.RemoveResource(an.Spec.Id)
	if err != nil {
		// Error reading the object - requeue the request.
		log.Error(err, "Failed to remove the AccessNode from PodCD")
	}
	log.Info("response from PodCD: " + fmt.Sprint(res.StatusCode))

	// Add the AccessNode to PodCD
	log.Info("Adding AccessNode to PodCD", "id", an.Spec.Id)
	chars := []podcdClient.Characteristic{
		{
			Name:  "ipv4Address",
			Value: an.Spec.IpAddress,
		},
		{
			Name:  "ztpIdent",
			Value: an.Spec.ZtpIdent,
		},
		{
			Name:  "operationalData",
			Value: "",
		},
	}
	lr := &podcdClient.Resource{
		an.Spec.Id: chars,
	}
	res, err = c.AddResource(lr)
	if err != nil {
		// Error reading the object - requeue the request.
		log.Error(err, "Failed to add the AccessNode to PodCD")
	}
	log.Info("response from PodCD: " + fmt.Sprint(res.StatusCode))
}
