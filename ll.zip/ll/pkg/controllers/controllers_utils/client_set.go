package controllers_utils

import (
	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/client"
)

func GetClientSet() (*client.OltOperatorClient, error) {
	config, err := rest.InClusterConfig()
	if err != nil {
		return nil, err
	}

	clientset, err := client.NewForConfig(config)
	if err != nil {
		return nil, err
	}

	return clientset, nil
}
