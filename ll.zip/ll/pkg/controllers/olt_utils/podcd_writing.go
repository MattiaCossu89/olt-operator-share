package olt_utils

import (
	"fmt"

	"github.com/go-logr/logr"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	podcdClient "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/podcd/client"
)

func UpdatePodCD(log logr.Logger, olt *v1alpha1.Olt, an *v1alpha1.AccessNode) {
	todo := env.ReadEnv("UPDATE_PODCD", "true")
	if todo != "true" {
		return
	}
	// Initialize the PodCD client
	pcd := podcdClient.NewClient()

	// Remove the OLT from PodCD
	log.Info("Removing Olt from PodCD", "id", olt.Spec.Id)
	res, err := pcd.RemoveResource(olt.Spec.Id)
	if err != nil {
		// Error reading the object - requeue the request.
		log.Error(err, "Failed to remove the Olt from PodCD")
	}
	log.Info("response from PodCD: " + fmt.Sprint(res.StatusCode))

	// Add the OLT to PodCD
	log.Info("Adding Olt to PodCD", "id", olt.Spec.Id)
	vendorClassId := ""
	if olt.Spec.Vendor == "adtran" {
		vendorClassId = "ADTRAN.SDX.6320"
	} else if olt.Spec.Vendor == "edgecore" {
		vendorClassId = "edgecore"
	}
	chars := []podcdClient.Characteristic{
		{
			Name:  "relationship",
			Value: an.Spec.Id,
		},
		{
			Name:  "plannedMatNumber",
			Value: "9",
		},
		{
			Name:  "ztpIdent",
			Value: olt.Spec.ZtpIdent,
		},
		{
			Name:  "serialNo",
			Value: olt.Spec.SerialNo,
		},
		{
			Name:  "route",
			Value: "0.0.0.0",
		},
		{
			Name:  "cidr",
			Value: olt.Spec.Cidr,
		},
		{
			Name:  "mac",
			Value: olt.Spec.MacAddress,
		},
		{
			Name:  "ipv4Address",
			Value: olt.Spec.IpAddress,
		},
		{
			Name:  "operationalData",
			Value: fmt.Sprintf("{\"resourceCharacteristic\":[{\"name\":\"neConfigId\",\"value\":101},{\"name\":\"dhcpOptions\",\"value\":[{\"tag\":1,\"value\":\"255.255.255.0\"}]},{\"name\":\"hostname\",\"value\":\"49_9124_130_7KH0\"},{\"name\":\"neSwitchId\",\"value\":101},{\"name\":\"vendorClassId\",\"value\":\"%s\"},{\"name\":\"managementIpAddresses\",\"value\":[{\"address\":\"%s\",\"type\":\"MGMT_INBAND\"}]}],\"vendorClassId\":\"%s\"}", vendorClassId, olt.Spec.Cidr, vendorClassId),
		},
	}
	lr := &podcdClient.Resource{
		olt.Spec.Id: chars,
	}
	res, err = pcd.AddResource(lr)
	if err != nil {
		// Error reading the object - requeue the request.
		log.Error(err, "Failed to add the Olt to PodCD")
	}
	log.Info("response from PodCD: " + fmt.Sprint(res.StatusCode))

}
