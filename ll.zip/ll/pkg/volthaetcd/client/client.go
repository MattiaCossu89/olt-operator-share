package client

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

type VolthaEtcdClient struct {
	client  *clientv3.Client
	timeout time.Duration
}

type ProfileMap struct {
	Name                           string                        `json:"name"`
	ProfileType                    string                        `json:"profile_type,omitempty"`
	Version                        int                           `json:"version,omitempty"`
	NumGemPorts                    int                           `json:"num_gem_ports,omitempty"`
	InstanceControl                ProfileInstanceControl        `json:"instance_control,omitempty"`
	UsScheduler                    ProfileScheduler              `json:"us_scheduler,omitempty"`
	DsScheduler                    ProfileScheduler              `json:"ds_scheduler,omitempty"`
	UpstreamGemPortAttributeList   []ProfileGemPortAttributeList `json:"upstream_gem_port_attribute_list,omitempty"`
	DownstreamGemPortAttributeList []ProfileGemPortAttributeList `json:"downstream_gem_port_attribute_list,omitempty"`
}

type ProfileInstanceControl struct {
	Onu               string `json:"onu,omitempty"`
	Uni               string `json:"uni,omitempty"`
	MaxGemPayloadSize string `json:"max_gem_payload_size,omitempty"`
}

type ProfileScheduler struct {
	AdditionalBw string `json:"additional_bw,omitempty"`
	Direction    string `json:"direction,omitempty"`
	Priority     int    `json:"priority,omitempty"`
	Weight       int    `json:"weight,omitempty"`
	QSchedPolicy string `json:"q_sched_policy,omitempty"`
}

type ProfileGemPortAttributeList struct {
	PbitMap          string               `json:"pbit_map,omitempty"`
	AesEncryption    string               `json:"aes_encryption,omitempty"`
	SchedulingPolicy string               `json:"scheduling_policy,omitempty"`
	PriorityQ        int                  `json:"priority_q,omitempty"`
	Weight           int                  `json:"weight,omitempty"`
	DiscardPolicy    string               `json:"discard_policy,omitempty"`
	MaxQSize         string               `json:"max_q_size,omitempty"`
	DiscardConfig    ProfileDiscardConfig `json:"discard_config,omitempty"`
}

type ProfileDiscardConfig struct {
	MaxThreshold   int `json:"max_threshold,omitempty"`
	MinThreshold   int `json:"min_threshold,omitempty"`
	MaxProbability int `json:"max_probability,omitempty"`
}

func NewVolthaEtcdClient() *VolthaEtcdClient {
	return &VolthaEtcdClient{
		timeout: 5 * time.Second,
	}
}

func (c *VolthaEtcdClient) Connect() error {
	cli, err := clientv3.New(clientv3.Config{
		Endpoints:   []string{env.ReadEnv("VOLTHA_ETCD_CLIENT_ENDPOINT", "voltha-etcd-cluster-client-headless.voltha:2379")},
		DialTimeout: 5 * time.Second,
	})
	if err != nil {
		return err
	}
	c.client = cli
	return nil
}

func (c *VolthaEtcdClient) Disconnect() error {
	if c.client != nil {
		err := c.client.Close()
		if err != nil {
			return err
		}
	}
	return nil
}

func (c *VolthaEtcdClient) AddTechProfile(p *v1alpha1.TechProfile) error {
	for _, profile := range p.Spec.ProfileMap {
		key := fmt.Sprintf("service/voltha/voltha_voltha/technology_profiles/%s/%d", profile.ProfileType, p.Spec.Id)
		model := &ProfileMap{
			Name:        profile.Name,
			ProfileType: profile.ProfileType,
			Version:     profile.Version,
			NumGemPorts: profile.NumGemPorts,
			InstanceControl: ProfileInstanceControl{
				Onu:               profile.InstanceControl.Onu,
				Uni:               profile.InstanceControl.Uni,
				MaxGemPayloadSize: profile.InstanceControl.MaxGemPayloadSize,
			},
			UsScheduler: ProfileScheduler{
				AdditionalBw: profile.UsScheduler.AdditionalBw,
				Direction:    profile.UsScheduler.Direction,
				Priority:     profile.UsScheduler.Priority,
				Weight:       profile.UsScheduler.Weight,
				QSchedPolicy: profile.UsScheduler.QSchedPolicy,
			},
			DsScheduler: ProfileScheduler{
				AdditionalBw: profile.DsScheduler.AdditionalBw,
				Direction:    profile.DsScheduler.Direction,
				Priority:     profile.DsScheduler.Priority,
				Weight:       profile.DsScheduler.Weight,
				QSchedPolicy: profile.DsScheduler.QSchedPolicy,
			},
		}
		model.UpstreamGemPortAttributeList = make([]ProfileGemPortAttributeList, 0)
		model.DownstreamGemPortAttributeList = make([]ProfileGemPortAttributeList, 0)
		for _, attrs := range profile.UpstreamGemPortAttributeList {
			a := ProfileGemPortAttributeList{
				PbitMap:          attrs.PbitMap,
				AesEncryption:    attrs.AesEncryption,
				SchedulingPolicy: attrs.SchedulingPolicy,
				PriorityQ:        attrs.PriorityQ,
				Weight:           attrs.Weight,
				DiscardPolicy:    attrs.DiscardPolicy,
				MaxQSize:         attrs.MaxQSize,
				DiscardConfig: ProfileDiscardConfig{
					MaxThreshold:   attrs.DiscardConfig.MaxThreshold,
					MinThreshold:   attrs.DiscardConfig.MinThreshold,
					MaxProbability: attrs.DiscardConfig.MaxProbability,
				},
			}
			model.UpstreamGemPortAttributeList = append(model.UpstreamGemPortAttributeList, a)
		}
		for _, attrs := range profile.DownstreamGemPortAttributeList {
			a := ProfileGemPortAttributeList{
				PbitMap:          attrs.PbitMap,
				AesEncryption:    attrs.AesEncryption,
				SchedulingPolicy: attrs.SchedulingPolicy,
				PriorityQ:        attrs.PriorityQ,
				Weight:           attrs.Weight,
				DiscardPolicy:    attrs.DiscardPolicy,
				MaxQSize:         attrs.MaxQSize,
				DiscardConfig: ProfileDiscardConfig{
					MaxThreshold:   attrs.DiscardConfig.MaxThreshold,
					MinThreshold:   attrs.DiscardConfig.MinThreshold,
					MaxProbability: attrs.DiscardConfig.MaxProbability,
				},
			}
			model.DownstreamGemPortAttributeList = append(model.DownstreamGemPortAttributeList, a)
		}

		b, err := json.Marshal(model)
		if err != nil {
			return err
		}

		ctx, cancel := context.WithTimeout(context.Background(), c.timeout)
		_, err = c.client.Put(ctx, key, string(b))
		cancel()
		if err != nil {
			return err
		}
	}
	return nil
}
