package commands

import (
	"log"
	"os"
	"time"

	"google.golang.org/grpc"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

type GrpcConfigSpec struct {
	Timeout time.Duration `yaml:"timeout"`
}

type GlobalConfigSpec struct {
	Server    string         `yaml:"server"`
	Grpc      GrpcConfigSpec `yaml:"grpc"`
	K8sConfig string         `yaml:"-"`
}

var (
	GlobalConfig = GlobalConfigSpec{
		Server: env.ReadEnv("VOLTHA_API_SERVICE_ENDPOINT", "voltha-api.voltha.svc:55555"),
		Grpc: GrpcConfigSpec{
			Timeout: time.Second * 10,
		},
	}
	Error = log.New(os.Stderr, "ERROR: ", 0)
)

func NewConnection() (*grpc.ClientConn, error) {
	return grpc.Dial(GlobalConfig.Server, grpc.WithInsecure())
}
