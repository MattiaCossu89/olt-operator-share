package commands

import (
	"context"
	"errors"

	"github.com/opencord/voltha-protos/v4/go/common"
	"github.com/opencord/voltha-protos/v4/go/voltha"
	"github.com/sirupsen/logrus"
	"google.golang.org/protobuf/types/known/emptypb"
)

type DeviceList struct{}

type DeviceId string

type DeviceReboot struct {
	Ids []DeviceId
}

type DevicePortList struct {
	Id DeviceId
}

type DeviceAdd struct {
	OltDevice *voltha.Device
}

type ONTAdd struct {
	OntDevice *voltha.Device
}

type DeviceDelete struct {
	Id string
}

func (options *DeviceList) Execute() ([]*voltha.Device, error) {

	log := logrus.New()
	ctx, cancel := context.WithTimeout(context.Background(), GlobalConfig.Grpc.Timeout)
	defer cancel()

	clientBuilder := NewClientBuilder()
	volthaServiceClient, conn, err := clientBuilder.GetVolthaServiceClient(ctx, GlobalConfig.Server)
	if err != nil {
		log.Error(err)
		return nil, err
	}

	defer conn.Close()
	log.Infof(
		"Will call Voltha GRPC ListDevices method",
	)
	listedDevices, err := volthaServiceClient.ListDevices(ctx, &emptypb.Empty{})
	if err != nil {
		log.Error(err)
		return []*voltha.Device{}, err
	}

	return listedDevices.Items, nil
}

func (options *DeviceReboot) Execute() error {
	log := logrus.New()
	ctx, cancel := context.WithTimeout(context.Background(), GlobalConfig.Grpc.Timeout)
	defer cancel()
	log.Infof("Will try to reboot devices with ids %v", options.Ids)
	clientBuilder := NewClientBuilder()
	volthaServiceClient, conn, err := clientBuilder.GetVolthaServiceClient(ctx, GlobalConfig.Server)
	if err != nil {
		log.Error(err)
		return err
	}

	defer conn.Close()
	log.Infof(
		"Will call Voltha GRPC RebootDevice method",
	)

	for _, id := range options.Ids {
		log.Infof("Calling Voltha GRPC RebootDevice method for id: %s", id)
		_, err := volthaServiceClient.RebootDevice(ctx, &common.ID{Id: string(id)})
		if err != nil {
			log.Errorf("Error while calling Voltha GRPC RebootDevice method for id: %s, ERROR: %s", id, err.Error())
			return err
		}
	}

	return nil
}

func (options *DevicePortList) Execute() ([]*voltha.Port, error) {

	log := logrus.New()
	ctx, cancel := context.WithTimeout(context.Background(), GlobalConfig.Grpc.Timeout)
	defer cancel()

	clientBuilder := NewClientBuilder()
	volthaServiceClient, conn, err := clientBuilder.GetVolthaServiceClient(ctx, GlobalConfig.Server)
	if err != nil {
		log.Error(err)
		return nil, err
	}

	defer conn.Close()
	log.Infof(
		"Will call Voltha GRPC DevicePortList method",
	)
	listedPorts, err := volthaServiceClient.ListDevicePorts(ctx, &common.ID{Id: string(options.Id)})
	if err != nil {
		log.Error(err)
		return []*voltha.Port{}, err
	}

	return listedPorts.Items, nil
	/* l := []model.DevicePort
	conn, err := NewConnection()
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	descriptor, method, err := GetMethod("device-ports")
	if err != nil {
		return nil, err
	}

	ctx, cancel := context.WithTimeout(context.Background(), GlobalConfig.Grpc.Timeout)
	defer cancel()

	h := &RpcEventHandler{
		Fields: map[string]map[string]interface{}{"common.ID": {"id": options.Id}},
	}
	err = grpcurl.InvokeRPC(ctx, descriptor, conn, method, []string{}, h, h.GetParams)
	if err != nil {
		return nil, err
	}

	if h.Status != nil && h.Status.Err() != nil {
		return nil, h.Status.Err()
	}

	d, err := dynamic.AsDynamicMessage(h.Response)
	if err != nil {
		return nil, err
	}

	items, err := d.TryGetFieldByName("items")
	if err != nil {
		return nil, err
	}

	data := make([]model.DevicePort, len(items.([]interface{})))
	for i, item := range items.([]interface{}) {
		data[i].PopulateFrom(item.(*dynamic.Message))
	}

	return data, nil */
}

func (options *DeviceAdd) Execute() (*voltha.Device, error) {
	log := logrus.New()
	ctx, cancel := context.WithTimeout(context.Background(), GlobalConfig.Grpc.Timeout)
	defer cancel()
	log.Infof("Will try to create and enable device with sn: '%s' in Voltha", options.OltDevice.SerialNumber)

	clientBuilder := NewClientBuilder()
	volthaServiceClient, conn, err := clientBuilder.GetVolthaServiceClient(ctx, GlobalConfig.Server)
	if err != nil {
		return nil, err
	}

	defer conn.Close()
	log.Infof(
		"Will call Voltha GRPC CreateDevice method with the device info: type '%s', sn '%s'",
		options.OltDevice.Type,
		options.OltDevice.SerialNumber,
	)
	createdDevice, err := volthaServiceClient.CreateDevice(ctx, options.OltDevice)
	if err != nil {
		return createdDevice, err
	}

	log.Infof(
		"Voltha GRPC CreateDevice method was called successfully, device response from Voltha: %s",
		createdDevice.String(),
	)

	if createdDevice.Id == "" {
		return createdDevice, errors.New("create device failed because of missing DeviceID")
	}

	log.Infof(
		"Will call Voltha GRPC EnableDevice method with the device id '%s'",
		createdDevice.Id,
	)
	_, err = volthaServiceClient.EnableDevice(ctx, &common.ID{
		Id: createdDevice.Id,
	})
	if err != nil {
		return createdDevice, err
	}
	log.Infof("Voltha GRPC EnableDevice method was called successfully")

	log.Infof("Will call Voltha GRPC GetDevice method to get device info by id '%s'", createdDevice.Id)
	enabledDevice, err := volthaServiceClient.GetDevice(ctx, &common.ID{
		Id: createdDevice.Id,
	})
	if err != nil {
		return createdDevice, err
	}

	log.Infof("Created and enabled device with id: '%s' and sn: '%s' in Voltha", enabledDevice.Id, enabledDevice.SerialNumber)

	return enabledDevice, nil
}

func (options *DeviceDelete) Execute() error {

	log := logrus.New()
	ctx, cancel := context.WithTimeout(context.Background(), GlobalConfig.Grpc.Timeout)
	defer cancel()

	clientBuilder := NewClientBuilder()
	volthaServiceClient, conn, err := clientBuilder.GetVolthaServiceClient(ctx, GlobalConfig.Server)
	if err != nil {
		log.Error(err)
		return err
	}

	defer conn.Close()
	log.Infof(
		"Will call Voltha GRPC DeviceDelete method",
	)
	_, err = volthaServiceClient.DeleteDevice(ctx, &common.ID{Id: options.Id})
	if err != nil {
		log.Error(err)
		return err
	}

	return nil
}
