//Package voltha wraps Voltha GRPC client logic
package commands

import (
	"context"
	"io"
	"math"

	"github.com/opencord/voltha-protos/v4/go/extension"
	"github.com/opencord/voltha-protos/v4/go/voltha"
	"google.golang.org/grpc"
)

//ClientBuilder voltha grpc client builder
type ClientBuilder struct{}

//NewClientBuilder constructor
func NewClientBuilder() (cB ClientBuilder) {
	cB = ClientBuilder{}

	return
}

//GetVolthaServiceClient creates voltha GRPC client
func (cb ClientBuilder) GetVolthaServiceClient(ctx context.Context, url string) (voltha.VolthaServiceClient, io.Closer, error) {
	conn, err := grpc.DialContext(ctx, url, grpc.WithInsecure(), grpc.WithDefaultCallOptions(grpc.MaxCallRecvMsgSize(math.MaxInt32)))
	if err != nil {
		return nil, nil, err
	}
	return voltha.NewVolthaServiceClient(conn), conn, nil
}

//GetExtensionClient creates extension GRPC client
func (cb ClientBuilder) GetExtensionClient(ctx context.Context, url string) (extension.ExtensionClient, io.Closer, error) {
	conn, err := grpc.DialContext(ctx, url, grpc.WithInsecure(), grpc.WithDefaultCallOptions(grpc.MaxCallRecvMsgSize(math.MaxInt32)))
	if err != nil {
		return nil, nil, err
	}
	return extension.NewExtensionClient(conn), conn, nil
}
