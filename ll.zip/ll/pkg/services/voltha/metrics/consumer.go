package metrics

import (
	"context"
	"net/http"
	"time"

	"github.com/go-logr/logr"
	io_prometheus_client "github.com/prometheus/client_model/go"
	"github.com/prometheus/common/expfmt"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/kubernetes/scheme"
	typedcorev1 "k8s.io/client-go/kubernetes/typed/core/v1"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/record"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/client"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/influxdb"
)

type MetricsHandler struct {
	log            logr.Logger
	interval       time.Duration
	endpoint       string
	client         *http.Client
	oltClient      client.OltInterface
	ontClient      client.OntInterface
	recorder       record.EventRecorder
	influxdbClient *influxdb.InfluxdbClient
}

func NewMetricsHandler(log logr.Logger) (*MetricsHandler, error) {
	mh := &MetricsHandler{
		log:            log,
		interval:       30 * time.Second,
		endpoint:       env.ReadEnv("KAFKA_TOPIC_EXPORTER_ENDPOINT", "http://kafka-topic-exporter.voltha:8080/metrics"),
		client:         &http.Client{},
		influxdbClient: influxdb.NewClient(),
	}

	mh.log.Info("initializing olt client")
	config, err := rest.InClusterConfig()
	if err != nil {
		mh.log.Error(err, "unable to get cluster config")
		return nil, err
	}

	err = client.AddToScheme(scheme.Scheme)
	if err != nil {
		mh.log.Error(err, "cannot add to scheme")
		return nil, err
	}

	clientset, err := client.NewForConfig(config)
	if err != nil {
		mh.log.Error(err, "unable to create client set")
		return nil, err
	}

	oltClient := clientset.Olts(context.TODO(), "olt-operator-system")
	mh.oltClient = oltClient

	ontClient := clientset.Onts(context.TODO(), "olt-operator-system")
	mh.ontClient = ontClient

	eventsClient, err := kubernetes.NewForConfig(config)
	if err != nil {
		return nil, err
	}
	eventsInterface := eventsClient.CoreV1().Events("olt-operator-system")
	eventBroadcaster := record.NewBroadcaster()
	eventBroadcaster.StartRecordingToSink(
		&typedcorev1.EventSinkImpl{
			Interface: eventsInterface})
	eventRecorder := eventBroadcaster.NewRecorder(
		scheme.Scheme,
		v1.EventSource{Component: "olt-operator"},
	)
	mh.recorder = eventRecorder

	return mh, nil
}

func (h *MetricsHandler) Parse() (map[string]*io_prometheus_client.MetricFamily, error) {
	res, err := h.client.Get(h.endpoint)
	if err != nil {
		return nil, err
	}

	var parser expfmt.TextParser
	mf, err := parser.TextToMetricFamilies(res.Body)
	if err != nil {
		return nil, err
	}
	return mf, nil
}

func (h *MetricsHandler) getOlts() ([]v1alpha1.Olt, error) {
	olts, err := h.oltClient.List(metav1.ListOptions{})
	if err != nil {
		h.log.Error(err, "unable to find olts")
		return nil, err
	}

	return olts.Items, nil
}

func (h *MetricsHandler) getOnts() ([]v1alpha1.Ont, error) {
	onts, err := h.ontClient.List(metav1.ListOptions{})
	if err != nil {
		h.log.Error(err, "unable to find onts")
		return nil, err
	}

	return onts.Items, nil
}

func (h *MetricsHandler) AssignToOlt(mf *io_prometheus_client.MetricFamily) error {
	olts, err := h.getOlts()
	if err != nil {
		return err
	}

	for _, olt := range olts {
		if olt.Status.DeviceId == "" {
			h.log.Info("skipping OLT with empty DeviceId", "id", olt.Spec.Id)
			continue
		}
		for _, metric := range mf.GetMetric() {
			for _, label := range metric.Label {
				if label.GetName() == "deviceuuid" && label.GetValue() == olt.Status.DeviceId || label.GetName() == "device_id" && label.GetValue() == olt.Status.DeviceId {
					h.log.Info("assigned metric to olt", "id", olt.Spec.Id, "metric_summary", metric.Summary, "mf_name", mf.GetName())
					h.recorder.Event(&olt, "Normal", "Metrics", mf.GetName()+" ("+mf.GetHelp()+"): "+metric.Gauge.String())
					h.influxdbClient.WriteMetric("olt", olt.Spec.Id, mf.GetName(), *metric.Gauge.Value)
				}
			}
		}
	}

	return nil
}

func (h *MetricsHandler) AssignToOnt(mf *io_prometheus_client.MetricFamily) error {
	onts, err := h.getOnts()
	if err != nil {
		return err
	}

	for _, ont := range onts {
		if ont.Status.DeviceId == "" {
			h.log.Info("skipping ONT with empty DeviceId", "id", ont.Spec.Id)
			continue
		}
		for _, metric := range mf.GetMetric() {
			for _, label := range metric.Label {
				if label.GetName() == "device_id" && label.GetValue() == ont.Status.DeviceId || label.GetName() == "deviceuuid" && label.GetValue() == ont.Status.DeviceId {
					h.log.Info("assigned metric to ont", "id", ont.Spec.Id, "metric_summary", metric.Summary, "mf_name", mf.GetName())
					h.recorder.Event(&ont, "Normal", "Metrics", mf.GetName()+" ("+mf.GetHelp()+"): "+metric.Gauge.String())
					//writing in influxdb
					h.influxdbClient.WriteMetric("ont", ont.Spec.Id, mf.GetName(), *metric.Gauge.Value)
				}
			}
		}
	}

	return nil
}

func (h *MetricsHandler) Run() {
	for {
		mf, err := h.Parse()
		if err != nil {
			h.log.Error(err, "cannot parse")
		} else {
			for _, v := range mf {
				//h.log.Info(fmt.Sprintf("KEY: %s", k))
				//h.log.Info(fmt.Sprintf("VAL: %s", v))
				err := h.AssignToOlt(v)
				if err != nil {
					h.log.Error(err, "error assigning metrics to olt")
				}
				err = h.AssignToOnt(v)
				if err != nil {
					h.log.Error(err, "error assigning metrics to ont")
				}
			}
		}
		time.Sleep(h.interval)
	}
}
