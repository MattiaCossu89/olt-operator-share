package checker

import (
	"context"
	"time"

	"github.com/go-logr/logr"
	"github.com/opencord/voltha-protos/v4/go/voltha"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/client"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/comparator"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/events"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/sadis"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/voltha/commands"
)

type Checker struct {
	log               logr.Logger
	Devices           []*voltha.Device
	oltClient         client.OltInterface
	ontClient         client.OntInterface
	bandProfileClient client.BandProfileInterface
}

func NewChecker(log logr.Logger) (*Checker, error) {
	c := &Checker{
		log: log,
	}

	c.log.Info("initializing olt client")
	config, err := rest.InClusterConfig()
	if err != nil {
		c.log.Error(err, "unable to get cluster config")
		return nil, err
	}

	err = client.AddToScheme(scheme.Scheme)
	if err != nil {
		c.log.Error(err, "cannot add to scheme")
		return nil, err
	}

	clientset, err := client.NewForConfig(config)
	if err != nil {
		c.log.Error(err, "unable to create client set")
		return nil, err
	}

	oltClient := clientset.Olts(context.TODO(), "olt-operator-system")
	c.oltClient = oltClient

	ontClient := clientset.Onts(context.TODO(), "olt-operator-system")
	c.ontClient = ontClient

	bandProfileClient := clientset.BandProfiles(context.TODO(), "olt-operator-system")
	c.bandProfileClient = bandProfileClient

	return c, nil
}

type Joiner struct {
	Dev   *voltha.Device
	OLTcr *v1alpha1.Olt
	ONTcr *v1alpha1.Ont
}

func DictionarizeDeviceList(dict *map[string]Joiner, devs *[]*voltha.Device) *map[string]Joiner {
	for _, e := range *devs {
		if value, ok := (*dict)[e.SerialNumber]; !ok {
			(*dict)[e.SerialNumber] = Joiner{Dev: e}
		} else {
			value.Dev = e
			(*dict)[e.SerialNumber] = value
		}
	}
	return dict
}

func DictionarizeOLTCRList(dict *map[string]Joiner, crds *[]v1alpha1.Olt) *map[string]Joiner {
	for _, e := range *crds {
		if value, ok := (*dict)[e.Spec.SerialNo]; !ok {
			(*dict)[e.Spec.SerialNo] = Joiner{OLTcr: &e}
		} else {
			value.OLTcr = &e
			(*dict)[e.Spec.SerialNo] = value
		}
	}
	return dict
}

func DictionarizeONTCRList(dict *map[string]Joiner, crds *[]v1alpha1.Ont) *map[string]Joiner {
	for _, e := range *crds {
		if value, ok := (*dict)[e.Spec.SerialNo]; !ok {
			(*dict)[e.Spec.SerialNo] = Joiner{ONTcr: &e}
		} else {
			value.ONTcr = &e
			(*dict)[e.Spec.SerialNo] = value
		}
	}
	return dict
}

func (c *Checker) Run() {
	for {
		time.Sleep(time.Second * 5)
		dict := map[string]Joiner{}
		devices, err := c.deviceList()
		if err != nil {
			c.log.Error(err, "error retrieving device list")
			continue
		}
		c.Devices = devices
		DictionarizeDeviceList(&dict, &devices)
		olts, err := c.getOlts()
		if err != nil {
			c.log.Error(err, "error retrieving olts list")
			continue
		}
		DictionarizeOLTCRList(&dict, &olts)
		onts, err := c.getOnts()
		if err != nil {
			c.log.Error(err, "error retrieving onts list")
			continue
		}
		DictionarizeONTCRList(&dict, &onts)
		c.checkStatus(&dict)
		if env.ReadEnv("UPDATE_SADIS", "true") == "true" {
			bandprofiles, err := c.getBandProfiles()
			if err != nil {
				c.log.Error(err, "error retrieving bandprofiles list")
				continue
			}
			sadisClient := sadis.NewSadisClient()
			sadisEntries, err := sadisClient.GetAllMetrics()
			if err != nil {
				c.log.Error(err, "error while reading from sadis")
				continue
			}
			comparator.Compare(bandprofiles, sadisEntries, onts, c.log)
		}
	}
}

func (c *Checker) checkStatus(dict *map[string]Joiner) {
	for _, value := range *dict {
		if value.Dev != nil && value.OLTcr == nil && value.ONTcr == nil {
			operation := &commands.DeviceDelete{Id: value.Dev.Id}
			err := operation.Execute()
			if err != nil {
				c.log.Error(err, "error while trying to delete device")
			}
		} else if value.Dev != nil && value.OLTcr != nil {
			c.updateOltStatus(value.OLTcr, value.Dev, c.Devices)
		} else if value.Dev != nil && value.ONTcr != nil {
			c.updateOntStatus(value.ONTcr, value.Dev)
		}
	}
}

func (c *Checker) deviceList() ([]*voltha.Device, error) {
	options := &commands.DeviceList{}
	devices, err := options.Execute()
	if err != nil {
		c.log.Error(err, "error retrieving the devices list from voltha")
		return nil, err
	}
	for _, device := range devices {
		c.log.Info("found device in voltha", "id", device.Id)
	}
	return devices, nil
}

func (c *Checker) getBandProfiles() ([]v1alpha1.BandProfile, error) {
	bandprofiles, err := c.bandProfileClient.List(metav1.ListOptions{})
	if err != nil {
		c.log.Error(err, "unable to find badprofiles")
		return nil, err
	}
	return bandprofiles.Items, nil
}

func (c *Checker) getOlts() ([]v1alpha1.Olt, error) {
	olts, err := c.oltClient.List(metav1.ListOptions{})
	if err != nil {
		c.log.Error(err, "unable to find olts")
		return nil, err
	}
	return olts.Items, nil
}
func (c *Checker) updateOltStatus(olt *v1alpha1.Olt, device *voltha.Device, devices []*voltha.Device) {
	ports, err := c.devicePortsList(device.Id)
	if err != nil {
		c.log.Error(err, "cannot retrieve ports", "deviceId", device.Id)
	}
	if device.SerialNumber == olt.Spec.SerialNo {
		if olt.Status.OperStatus != device.OperStatus.String() {
			_ = events.NewEventRecorder("olt", "olt-operator-system", olt, "Normal", "OperStatus changed", "The operational status is changing from "+olt.Status.OperStatus+" to "+device.OperStatus.String()+". The Olt ID is: "+olt.Status.DeviceId)
		}
		if olt.Status.AdminState != device.AdminState.String() {
			_ = events.NewEventRecorder("olt", "olt-operator-system", olt, "Normal", "AdminState changed", "The operational status is changing from "+olt.Status.AdminState+" to "+device.AdminState.String()+". The Olt ID is: "+olt.Status.DeviceId)
		}
		if olt.Status.ConnectStatus != device.ConnectStatus.String() {
			_ = events.NewEventRecorder("olt", "olt-operator-system", olt, "Normal", "ConnectStatus changed", "The operational status is changing from "+olt.Status.ConnectStatus+" to "+device.ConnectStatus.String()+". The Olt ID is: "+olt.Status.DeviceId)
		}
		olt.Status.OperStatus = device.OperStatus.String()
		olt.Status.AdminState = device.AdminState.String()
		olt.Status.ConnectStatus = device.ConnectStatus.String()
		olt.Status.Reason = device.Reason
		olt.Status.DeviceId = device.Id
		olt.Status.Ports = []v1alpha1.OltDevicePort{}
		olt.Status.DiscoveredOnt = []v1alpha1.DiscoveredOnt{}
		for i := 0; i < len(devices); i++ {
			if devices[i].ParentId == device.Id {
				tmp := v1alpha1.DiscoveredOnt{
					Id:            devices[i].Id,
					AdminState:    devices[i].AdminState.String(),
					OperStatus:    devices[i].OperStatus.String(),
					ConnectStatus: devices[i].ConnectStatus.String(),
					SerialNo:      devices[i].SerialNumber,
					Reason:        devices[i].Reason,
				}
				olt.Status.DiscoveredOnt = append(olt.Status.DiscoveredOnt, tmp)
			}
		}
		if ports != nil {
			for _, port := range ports {
				p := v1alpha1.OltDevicePort{
					PortNo:     port.PortNo,
					Label:      port.Label,
					Type:       port.Type.String(),
					AdminState: port.AdminState.String(),
					OperStatus: port.OperStatus.String(),
					DeviceId:   port.DeviceId,
					Peers:      []v1alpha1.OltPeerPort{},
				}
				for _, peer := range port.Peers {
					pe := v1alpha1.OltPeerPort{
						DeviceId: peer.DeviceId,
						PortNo:   peer.PortNo,
					}
					p.Peers = append(p.Peers, pe)
				}
				olt.Status.Ports = append(olt.Status.Ports, p)
			}
		}
		_, err := c.oltClient.UpdateStatus(olt)
		if err != nil {
			c.log.Error(err, "failed to update olt status")
		}
	}
}

func (c *Checker) getOnts() ([]v1alpha1.Ont, error) {
	onts, err := c.ontClient.List(metav1.ListOptions{})
	if err != nil {
		c.log.Error(err, "unable to find onts")
		return nil, err
	}

	return onts.Items, nil
}

func (c *Checker) updateOntStatus(ont *v1alpha1.Ont, device *voltha.Device /*, devices []*voltha.Device*/) {

	ports, err := c.devicePortsList(device.Id)
	if err != nil {
		c.log.Error(err, "cannot retrieve ports", "deviceId", device.Id)
	}
	if device.SerialNumber == ont.Spec.SerialNo {
		if ont.Status.OperStatus != device.OperStatus.String() {
			_ = events.NewEventRecorder("ont", "olt-operator-system", ont, "Normal", "OperStatus changed", "The operational status is changing from "+ont.Status.OperStatus+" to "+device.OperStatus.String()+". The Ont ID is: "+ont.Status.DeviceId)
		}
		if ont.Status.AdminState != device.AdminState.String() {
			_ = events.NewEventRecorder("ont", "olt-operator-system", ont, "Normal", "AdminState changed", "The operational status is changing from "+ont.Status.AdminState+" to "+device.AdminState.String()+". The Ont ID is: "+ont.Status.DeviceId)
		}
		if ont.Status.ConnectStatus != device.ConnectStatus.String() {
			_ = events.NewEventRecorder("ont", "olt-operator-system", ont, "Normal", "ConnectStatus changed", "The operational status is changing from "+ont.Status.ConnectStatus+" to "+device.ConnectStatus.String()+". The Ont ID is: "+ont.Status.DeviceId)
		}
		ont.Status.OperStatus = device.OperStatus.String()
		ont.Status.AdminState = device.AdminState.String()
		ont.Status.ConnectStatus = device.ConnectStatus.String()
		ont.Status.Reason = device.Reason
		ont.Status.DeviceId = device.Id
		ont.Status.Ports = []v1alpha1.OntDevicePort{}
		if ports != nil {
			for _, port := range ports {
				p := v1alpha1.OntDevicePort{
					PortNo:     port.PortNo,
					Label:      port.Label,
					Type:       port.Type.String(),
					AdminState: port.AdminState.String(),
					OperStatus: port.OperStatus.String(),
					DeviceId:   port.DeviceId,
					Peers:      []v1alpha1.OntPeerPort{},
				}
				for _, peer := range port.Peers {
					pe := v1alpha1.OntPeerPort{
						DeviceId: peer.DeviceId,
						PortNo:   peer.PortNo,
					}
					p.Peers = append(p.Peers, pe)
				}
				ont.Status.Ports = append(ont.Status.Ports, p)
			}
		}
		_, err := c.ontClient.UpdateStatus(ont)
		if err != nil {
			c.log.Error(err, "failed to update ont status")
		}
		//Delete ont when unreachable
		if device.ConnectStatus.String() == "UNREACHABLE" {
			delete := commands.DeviceDelete{Id: ont.Status.DeviceId}
			err := delete.Execute()
			if err != nil {
				c.log.Error(err, err.Error())
			}
		}
		/* if device.Reason == "initial-mib-downloaded" {
			url := env.ReadEnv("ONOS_ENDPOINT", "http://voltha-infra-onos-classic-hs.infra.svc:8181")
			http.Post(url + "/onos/olt/oltapp/services/" + ont.)
		} */
	}
}

func (c *Checker) devicePortsList(id string) ([]*voltha.Port, error) {
	options := &commands.DevicePortList{
		Id: commands.DeviceId(id),
	}
	ports, err := options.Execute()
	if err != nil {
		c.log.Error(err, "error retrieving the ports from voltha", "id", id)
		return nil, err
	}

	for _, port := range ports {
		c.log.Info("found port in voltha", "portNo", port.PortNo, "label", port.Label)
	}
	return ports, nil
}
