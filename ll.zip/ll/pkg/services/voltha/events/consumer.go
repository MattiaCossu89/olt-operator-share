package events

/*
import (
	"context"
	"fmt"
	"github.com/go-logr/logr"
	"github.com/golang/protobuf/proto"
	"github.com/segmentio/kafka-go"
)

type EventHandler struct {
	log logr.Logger
	r   *kafka.Reader
}

func NewEventHandler(log logr.Logger) *EventHandler {
	return &EventHandler{
		log: log,
	}
}

func (e *EventHandler) Connect() error {
	topic := "voltha_openolt"

	r := kafka.NewReader(kafka.ReaderConfig{
		Brokers:     []string{"voltha-kafka.voltha.svc:9092"},
		Topic:       topic,
		GroupID:     "olt-operator",
		MinBytes:    10e3, // 10KB
		MaxBytes:    10e6, // 10MB
		StartOffset: 0,
	})

	e.r = r

	return nil
}

func (e *EventHandler) Disconnect() error {
	if err := e.r.Close(); err != nil {
		return err
	}

	return nil
}

func (e *EventHandler) Listen() error {
	var err error
	for {
		e.log.Info("trying to read message from kafka")
		m, err := e.r.ReadMessage(context.Background())
		if err != nil {
			e.log.Error(err, "error reading message from kafka")
			break
		}
		//e.log.Info(fmt.Sprintf("message at offset %d: %s = %s\n", m.Offset, string(m.Key), string(m.Value)))
		e.log.Info(fmt.Sprintf("message at offset %d: %s", m.Offset, string(m.Key)))
		evt := &vp.Event{}
		err = proto.Unmarshal(m.Value, evt)
		if err != nil {
			e.log.Error(err, "cannot unmarshal message to protobuf", "payload", string(m.Value))
			continue
		}
		e.Handle(evt)
	}

	return err
}

func (e *EventHandler) Handle(event *vp.Event) {
	e.log.Info("handling event")
	if event.GetHeader() == nil {
		e.log.Info("invalid voltha event header")
	}
	e.log.Info(fmt.Sprint(event.GetEventType()))
	deviceEvent := event.GetDeviceEvent()
	if event.GetHeader() != nil && event.GetHeader().GetType() == vp.EventType_DEVICE_EVENT && deviceEvent != nil {
		e.log.Info("resource id", "resourceId", deviceEvent.GetResourceId())
		e.log.Info("device event name", "deviceEventName", deviceEvent.GetDeviceEventName())
		e.log.Info("description", "description", deviceEvent.GetDescription())
	}
}
*/
