package client

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httputil"
	"strings"

	"github.com/go-logr/logr"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
)

type Client struct {
	client    *http.Client
	serverURL string
}

type Onu struct {
	Sn                   string `json:"sn,omitempty"`
	ItemType             string `json:"type,omitempty"`
	Stag                 string `json:"stag,omitempty"`
	Ctag                 string `json:"ctag,omitempty"`
	UniTagMatch          string `json:"uniTagMatch,omitempty"`
	ConfiguredMacAddress string `json:"configuredMacAddress,omitempty"`
	Profile              string `json:"profile,omitempty"`
}

type OnuList []Onu

type DeleteOnu string
type DeleteOnuList []DeleteOnu

func NewClient() *Client {
	client := &http.Client{}
	return &Client{
		client:    client,
		serverURL: env.ReadEnv("PAOSIM_ENDPOINT", "http://paosim.voltha:18808"),
	}
}

func (c *Client) AddONU(log logr.Logger, item *v1alpha1.Ont, ve *v1alpha1.Venet, tp *v1alpha1.TechProfile) (*http.Response, error) {
	snConverted, err := serialToHex(item.Spec.SerialNo)
	if err != nil {
		return nil, err
	}
	model := &OnuList{
		Onu{
			Sn:                   snConverted,
			ItemType:             "ONT",
			Stag:                 fmt.Sprint(ve.Spec.Svlan),
			Ctag:                 fmt.Sprint(ve.Spec.Cvlan),
			UniTagMatch:          fmt.Sprint(ve.Spec.Uvlan),
			ConfiguredMacAddress: item.Spec.MacAddress,
			Profile:              fmt.Sprint(tp.Spec.Id),
		},
	}
	b, err := json.Marshal(model)
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequest("POST", c.serverURL+"/onus", bytes.NewBuffer(b))
	if err != nil {
		return nil, err
	}
	dump, err := httputil.DumpRequest(req, true)
	if err != nil {
		return nil, err
	}
	log.Info("request to paosim to add ONU", "req", fmt.Sprintf("%q", dump))
	res, err := c.client.Do(req)
	if err != nil {
		return nil, err
	}

	return res, nil
}

func (c *Client) RemoveONU(sn string) (*http.Response, error) {
	snConverted, err := serialToHex(sn)
	if err != nil {
		return nil, err
	}
	model := &DeleteOnuList{
		DeleteOnu(snConverted),
	}
	b, err := json.Marshal(model)
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequest("DELETE", c.serverURL+"/onus", bytes.NewBuffer(b))
	if err != nil {
		return nil, err
	}
	res, err := c.client.Do(req)
	if err != nil {
		return nil, err
	}

	return res, nil
}

func serialToHex(sn string) (string, error) {
	if len(sn) < 4 {
		return "", errors.New("serial number too short")
	}
	prefix := sn[0:4]
	prefixHex := hex.EncodeToString([]byte(prefix))
	rest := sn[4:]
	return strings.ToUpper(prefixHex + rest), nil
}
