package events

import (
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/kubernetes/scheme"
	typedcorev1 "k8s.io/client-go/kubernetes/typed/core/v1"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/record"
)

func NewEventRecorder(componentName string, namespace string, object runtime.Object, eventtype string, reason string, message string) error {
	config, err := rest.InClusterConfig()
	if err != nil {
		return err
	}
	eventsClient, err := kubernetes.NewForConfig(config)
	if err != nil {
		return err
	}
	eventsInterface := eventsClient.CoreV1().Events(namespace)
	eventBroadcaster := record.NewBroadcaster()
	eventBroadcaster.StartRecordingToSink(
		&typedcorev1.EventSinkImpl{
			Interface: eventsInterface})
	eventRecorder := eventBroadcaster.NewRecorder(
		scheme.Scheme,
		v1.EventSource{Component: componentName},
	)
	eventRecorder.Event(object, eventtype, reason, message)
	return nil
}
