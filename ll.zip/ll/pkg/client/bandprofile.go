package client

import (
	"context"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
)

type BandProfileInterface interface {
	List(opts metav1.ListOptions) (*v1alpha1.BandProfileList, error)
	Get(name string, options metav1.GetOptions) (*v1alpha1.BandProfile, error)
	Create(*v1alpha1.BandProfile) (*v1alpha1.BandProfile, error)
	Watch(opts metav1.ListOptions) (watch.Interface, error)
	UpdateStatus(*v1alpha1.BandProfile) (*v1alpha1.BandProfile, error)
}

type bandProfileClient struct {
	restClient rest.Interface
	ns         string
	ctx        context.Context
}

func (c *bandProfileClient) List(opts metav1.ListOptions) (*v1alpha1.BandProfileList, error) {
	result := v1alpha1.BandProfileList{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("bandprofiles").
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *bandProfileClient) Get(name string, opts metav1.GetOptions) (*v1alpha1.BandProfile, error) {
	result := v1alpha1.BandProfile{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("bandprofiles").
		Name(name).
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *bandProfileClient) Create(project *v1alpha1.BandProfile) (*v1alpha1.BandProfile, error) {
	result := v1alpha1.BandProfile{}
	err := c.restClient.
		Post().
		Namespace(c.ns).
		Resource("bandprofiles").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *bandProfileClient) Watch(opts metav1.ListOptions) (watch.Interface, error) {
	opts.Watch = true
	return c.restClient.
		Get().
		Namespace(c.ns).
		Resource("bandprofiles").
		VersionedParams(&opts, scheme.ParameterCodec).
		Watch(c.ctx)
}

func (c *bandProfileClient) UpdateStatus(project *v1alpha1.BandProfile) (*v1alpha1.BandProfile, error) {
	result := v1alpha1.BandProfile{}
	err := c.restClient.
		Put().
		Namespace(c.ns).
		Resource("bandprofiles").
		Name(project.GetName()).
		SubResource("status").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}
