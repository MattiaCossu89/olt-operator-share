package client

import (
	"context"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
)

type AccessNodeInterface interface {
	List(opts metav1.ListOptions) (*v1alpha1.AccessNodeList, error)
	Get(name string, options metav1.GetOptions) (*v1alpha1.AccessNode, error)
	Create(*v1alpha1.AccessNode) (*v1alpha1.AccessNode, error)
	Watch(opts metav1.ListOptions) (watch.Interface, error)
	UpdateStatus(*v1alpha1.AccessNode) (*v1alpha1.AccessNode, error)
}

type accessNodeClient struct {
	restClient rest.Interface
	ns         string
	ctx        context.Context
}

func (c *accessNodeClient) List(opts metav1.ListOptions) (*v1alpha1.AccessNodeList, error) {
	result := v1alpha1.AccessNodeList{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("accessnodes").
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *accessNodeClient) Get(name string, opts metav1.GetOptions) (*v1alpha1.AccessNode, error) {
	result := v1alpha1.AccessNode{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("accessnodes").
		Name(name).
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *accessNodeClient) Create(project *v1alpha1.AccessNode) (*v1alpha1.AccessNode, error) {
	result := v1alpha1.AccessNode{}
	err := c.restClient.
		Post().
		Namespace(c.ns).
		Resource("accessnodes").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *accessNodeClient) Watch(opts metav1.ListOptions) (watch.Interface, error) {
	opts.Watch = true
	return c.restClient.
		Get().
		Namespace(c.ns).
		Resource("accessnodes").
		VersionedParams(&opts, scheme.ParameterCodec).
		Watch(c.ctx)
}

func (c *accessNodeClient) UpdateStatus(project *v1alpha1.AccessNode) (*v1alpha1.AccessNode, error) {
	result := v1alpha1.AccessNode{}
	err := c.restClient.
		Put().
		Namespace(c.ns).
		Resource("accessnodes").
		Name(project.GetName()).
		SubResource("status").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}
