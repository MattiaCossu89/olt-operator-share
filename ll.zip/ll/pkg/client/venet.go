package client

import (
	"context"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
)

type VenetInterface interface {
	List(opts metav1.ListOptions) (*v1alpha1.VenetList, error)
	Get(name string, options metav1.GetOptions) (*v1alpha1.Venet, error)
	Create(*v1alpha1.Venet) (*v1alpha1.Venet, error)
	Watch(opts metav1.ListOptions) (watch.Interface, error)
	UpdateStatus(*v1alpha1.Venet) (*v1alpha1.Venet, error)
}

type venetClient struct {
	restClient rest.Interface
	ns         string
	ctx        context.Context
}

func (c *venetClient) List(opts metav1.ListOptions) (*v1alpha1.VenetList, error) {
	result := v1alpha1.VenetList{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("venets").
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *venetClient) Get(name string, opts metav1.GetOptions) (*v1alpha1.Venet, error) {
	result := v1alpha1.Venet{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("venets").
		Name(name).
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *venetClient) Create(project *v1alpha1.Venet) (*v1alpha1.Venet, error) {
	result := v1alpha1.Venet{}
	err := c.restClient.
		Post().
		Namespace(c.ns).
		Resource("venets").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *venetClient) Watch(opts metav1.ListOptions) (watch.Interface, error) {
	opts.Watch = true
	return c.restClient.
		Get().
		Namespace(c.ns).
		Resource("venets").
		VersionedParams(&opts, scheme.ParameterCodec).
		Watch(c.ctx)
}

func (c *venetClient) UpdateStatus(project *v1alpha1.Venet) (*v1alpha1.Venet, error) {
	result := v1alpha1.Venet{}
	err := c.restClient.
		Put().
		Namespace(c.ns).
		Resource("venets").
		Name(project.GetName()).
		SubResource("status").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}
