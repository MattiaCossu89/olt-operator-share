package client

import (
	"context"

	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
)

type OltOperatorInterface interface {
	Olts(namespace string) OltInterface
	Onts(namespace string) OntInterface
	BandProfiles(namespace string) BandProfileInterface
	AccessNodes(namespace string) AccessNodeInterface
}

type OltOperatorClient struct {
	restClient rest.Interface
}

func NewForConfig(c *rest.Config) (*OltOperatorClient, error) {
	config := *c
	config.ContentConfig.GroupVersion = &schema.GroupVersion{Group: GroupName, Version: GroupVersion}
	config.APIPath = "/apis"
	config.NegotiatedSerializer = scheme.Codecs.WithoutConversion()
	config.UserAgent = rest.DefaultKubernetesUserAgent()

	client, err := rest.RESTClientFor(&config)
	if err != nil {
		return nil, err
	}

	return &OltOperatorClient{restClient: client}, nil
}

func (c *OltOperatorClient) Olts(ctx context.Context, namespace string) OltInterface {
	return &oltClient{
		restClient: c.restClient,
		ns:         namespace,
		ctx:        ctx,
	}
}

func (c *OltOperatorClient) Onts(ctx context.Context, namespace string) OntInterface {
	return &ontClient{
		restClient: c.restClient,
		ns:         namespace,
		ctx:        ctx,
	}
}

func (c *OltOperatorClient) BandProfiles(ctx context.Context, namespace string) BandProfileInterface {
	return &bandProfileClient{
		restClient: c.restClient,
		ns:         namespace,
		ctx:        ctx,
	}
}

func (c *OltOperatorClient) AccessNodes(ctx context.Context, namespace string) AccessNodeInterface {
	return &accessNodeClient{
		restClient: c.restClient,
		ns:         namespace,
		ctx:        ctx,
	}
}

func (c *OltOperatorClient) ServiceProfiles(ctx context.Context, namespace string) ServiceProfileInterface {
	return &serviceProfileClient{
		restClient: c.restClient,
		ns:         namespace,
		ctx:        ctx,
	}
}

func (c *OltOperatorClient) TechProfiles(ctx context.Context, namespace string) TechProfileInterface {
	return &techProfileClient{
		restClient: c.restClient,
		ns:         namespace,
		ctx:        ctx,
	}
}

func (c *OltOperatorClient) Venets(ctx context.Context, namespace string) VenetInterface {
	return &venetClient{
		restClient: c.restClient,
		ns:         namespace,
		ctx:        ctx,
	}
}
