package client

import (
	"context"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
)

type OltInterface interface {
	List(opts metav1.ListOptions) (*v1alpha1.OltList, error)
	Get(name string, options metav1.GetOptions) (*v1alpha1.Olt, error)
	Create(*v1alpha1.Olt) (*v1alpha1.Olt, error)
	Watch(opts metav1.ListOptions) (watch.Interface, error)
	UpdateStatus(*v1alpha1.Olt) (*v1alpha1.Olt, error)
}

type oltClient struct {
	restClient rest.Interface
	ns         string
	ctx        context.Context
}

func (c *oltClient) List(opts metav1.ListOptions) (*v1alpha1.OltList, error) {
	result := v1alpha1.OltList{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("olts").
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *oltClient) Get(name string, opts metav1.GetOptions) (*v1alpha1.Olt, error) {
	result := v1alpha1.Olt{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("olts").
		Name(name).
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *oltClient) Create(project *v1alpha1.Olt) (*v1alpha1.Olt, error) {
	result := v1alpha1.Olt{}
	err := c.restClient.
		Post().
		Namespace(c.ns).
		Resource("olts").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *oltClient) Watch(opts metav1.ListOptions) (watch.Interface, error) {
	opts.Watch = true
	return c.restClient.
		Get().
		Namespace(c.ns).
		Resource("olts").
		VersionedParams(&opts, scheme.ParameterCodec).
		Watch(c.ctx)
}

func (c *oltClient) UpdateStatus(project *v1alpha1.Olt) (*v1alpha1.Olt, error) {
	result := v1alpha1.Olt{}
	err := c.restClient.
		Put().
		Namespace(c.ns).
		Resource("olts").
		Name(project.GetName()).
		SubResource("status").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}
