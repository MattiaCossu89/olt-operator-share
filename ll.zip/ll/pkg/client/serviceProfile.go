package client

import (
	"context"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
)

type ServiceProfileInterface interface {
	List(opts metav1.ListOptions) (*v1alpha1.ServiceProfileList, error)
	Get(name string, options metav1.GetOptions) (*v1alpha1.ServiceProfile, error)
	Create(*v1alpha1.ServiceProfile) (*v1alpha1.ServiceProfile, error)
	Watch(opts metav1.ListOptions) (watch.Interface, error)
	UpdateStatus(*v1alpha1.ServiceProfile) (*v1alpha1.ServiceProfile, error)
}

type serviceProfileClient struct {
	restClient rest.Interface
	ns         string
	ctx        context.Context
}

func (c *serviceProfileClient) List(opts metav1.ListOptions) (*v1alpha1.ServiceProfileList, error) {
	result := v1alpha1.ServiceProfileList{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("serviceprofiles").
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *serviceProfileClient) Get(name string, opts metav1.GetOptions) (*v1alpha1.ServiceProfile, error) {
	result := v1alpha1.ServiceProfile{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("serviceprofiles").
		Name(name).
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *serviceProfileClient) Create(project *v1alpha1.ServiceProfile) (*v1alpha1.ServiceProfile, error) {
	result := v1alpha1.ServiceProfile{}
	err := c.restClient.
		Post().
		Namespace(c.ns).
		Resource("serviceprofiles").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *serviceProfileClient) Watch(opts metav1.ListOptions) (watch.Interface, error) {
	opts.Watch = true
	return c.restClient.
		Get().
		Namespace(c.ns).
		Resource("serviceprofiles").
		VersionedParams(&opts, scheme.ParameterCodec).
		Watch(c.ctx)
}

func (c *serviceProfileClient) UpdateStatus(project *v1alpha1.ServiceProfile) (*v1alpha1.ServiceProfile, error) {
	result := v1alpha1.ServiceProfile{}
	err := c.restClient.
		Put().
		Namespace(c.ns).
		Resource("serviceprofiles").
		Name(project.GetName()).
		SubResource("status").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}
