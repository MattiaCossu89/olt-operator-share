package client

import (
	"context"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
)

type TechProfileInterface interface {
	List(opts metav1.ListOptions) (*v1alpha1.TechProfileList, error)
	Get(name string, options metav1.GetOptions) (*v1alpha1.TechProfile, error)
	Create(*v1alpha1.TechProfile) (*v1alpha1.TechProfile, error)
	Watch(opts metav1.ListOptions) (watch.Interface, error)
	UpdateStatus(*v1alpha1.TechProfile) (*v1alpha1.TechProfile, error)
}

type techProfileClient struct {
	restClient rest.Interface
	ns         string
	ctx        context.Context
}

func (c *techProfileClient) List(opts metav1.ListOptions) (*v1alpha1.TechProfileList, error) {
	result := v1alpha1.TechProfileList{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("techprofiles").
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *techProfileClient) Get(name string, opts metav1.GetOptions) (*v1alpha1.TechProfile, error) {
	result := v1alpha1.TechProfile{}
	err := c.restClient.
		Get().
		Namespace(c.ns).
		Resource("techprofiles").
		Name(name).
		VersionedParams(&opts, scheme.ParameterCodec).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *techProfileClient) Create(project *v1alpha1.TechProfile) (*v1alpha1.TechProfile, error) {
	result := v1alpha1.TechProfile{}
	err := c.restClient.
		Post().
		Namespace(c.ns).
		Resource("techprofiles").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}

func (c *techProfileClient) Watch(opts metav1.ListOptions) (watch.Interface, error) {
	opts.Watch = true
	return c.restClient.
		Get().
		Namespace(c.ns).
		Resource("techprofiles").
		VersionedParams(&opts, scheme.ParameterCodec).
		Watch(c.ctx)
}

func (c *techProfileClient) UpdateStatus(project *v1alpha1.TechProfile) (*v1alpha1.TechProfile, error) {
	result := v1alpha1.TechProfile{}
	err := c.restClient.
		Put().
		Namespace(c.ns).
		Resource("techprofiles").
		Name(project.GetName()).
		SubResource("status").
		Body(project).
		Do(c.ctx).
		Into(&result)

	return &result, err
}
