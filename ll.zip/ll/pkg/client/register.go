package client

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
)

const GroupName = "dolt.it.dolt.it"
const GroupVersion = "v1alpha1"

var SchemeGroupVersion = schema.GroupVersion{Group: GroupName, Version: GroupVersion}

var (
	SchemeBuilder = runtime.NewSchemeBuilder(addKnownTypes)
	AddToScheme   = SchemeBuilder.AddToScheme
)

func addKnownTypes(scheme *runtime.Scheme) error {
	scheme.AddKnownTypes(SchemeGroupVersion,
		&v1alpha1.Olt{},
		&v1alpha1.OltList{},
		&v1alpha1.Ont{},
		&v1alpha1.OntList{},
		&v1alpha1.BandProfileList{},
		&v1alpha1.BandProfile{},
		&v1alpha1.ServiceProfile{},
		&v1alpha1.ServiceProfileList{},
		&v1alpha1.TechProfile{},
		&v1alpha1.TechProfileList{},
		&v1alpha1.Venet{},
		&v1alpha1.VenetList{},
	)

	metav1.AddToGroupVersion(scheme, SchemeGroupVersion)
	return nil
}
