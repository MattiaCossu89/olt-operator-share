package comparator

import (
	"encoding/json"
	"time"

	"github.com/go-logr/logr"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/events"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/sadis"
)

var timer map[string]int64 = make(map[string]int64)

func Compare(kubeDefinitionObj []v1alpha1.BandProfile, sadisDefinition []interface{}, ontsKube []v1alpha1.Ont, log logr.Logger) {

	sadisSpec := clearSadisDefinitionsBP(sadisDefinition)
	ontsSadis := clearSadisDefinitionsOnt(sadisDefinition)
	kubeDefinition := getKubeDefinitions(kubeDefinitionObj)

	//log.Info(fmt.Sprintf("ATTENZIONE MIMMO %#v\n\n%#v",sadisDefinition,   sadisSpec))

	for i := 0; i < len(kubeDefinition); i++ {

		for k := 0; k < len(sadisSpec); k++ {

			jsonResource, _ := json.Marshal(sadisSpec[k])

			if sadisSpec[k].Id == kubeDefinition[i].Id {
				if !checker(kubeDefinition[i], sadisSpec[k]) {
					if timer[sadisSpec[k].Id] == 0 {
						timer[sadisSpec[k].Id] = time.Now().Unix() + 300
						_ = events.NewEventRecorder("bandprofile", "olt-operator-system", &kubeDefinitionObj[i], "Normal", "Mismatch", string(jsonResource))
					} else if (time.Now().Unix() - timer[sadisSpec[k].Id]) >= 0 {
						_ = events.NewEventRecorder("bandprofile", "olt-operator-system", &kubeDefinitionObj[i], "Normal", "Reset", string(jsonResource))
						timer[sadisSpec[k].Id] = 0
						sadisClient := sadis.NewSadisClient()

						data, _ := json.Marshal(kubeDefinition[i])
						err := sadisClient.AddMetric(kubeDefinition[i].Id, data)
						if err != nil {
							_ = events.NewEventRecorder("bandprofile", "olt-operator-system", &kubeDefinitionObj[i], "Normal", "Error while writing sadis", err.Error())
						} else {
							_ = events.NewEventRecorder("bandprofile", "olt-operator-system", &kubeDefinitionObj[i], "Normal", "Successfuly added to sadis", "Bandprofile id: "+sadisSpec[k].Id)
						}
						err = rebootOnt(sadisSpec[k].Id, ontsSadis, ontsKube, log)
						if err != nil {
							_ = events.NewEventRecorder("ont", "olt-operator-system", &kubeDefinitionObj[i], "Normal", "onts not rebooting", err.Error())
						} else {
							_ = events.NewEventRecorder("ont", "olt-operator-system", &kubeDefinitionObj[i], "Normal", "onts rebooting", "Non ci sono stati problemi")
						}
					}
				} else if timer[sadisSpec[k].Id] != 0 {
					timer[sadisSpec[k].Id] = 0
					_ = events.NewEventRecorder("bandprofile", "olt-operator-system", &kubeDefinitionObj[i], "Normal", "Rialigned", string(jsonResource))
				}
			} else {
				continue
			}

		}
	}
}

func findKubeOntFromId(ontId string, ontKube []v1alpha1.Ont) (v1alpha1.Ont, bool) {

	for i := 0; i < len(ontKube); i++ {
		if ontId == (ontKube[i].Spec.SerialNo + "-1") {
			return ontKube[i], true
		}
	}

	return v1alpha1.Ont{}, false
}

func getKubeDefinitions(bandprofiles []v1alpha1.BandProfile) []v1alpha1.BandProfileSpec {
	output := []v1alpha1.BandProfileSpec{}

	for i := 0; i < len(bandprofiles); i++ {

		output = append(output, bandprofiles[i].Spec)

	}

	return output
}

func clearSadisDefinitionsBP(sadisDefinition []interface{}) []v1alpha1.BandProfileSpec {

	output := []v1alpha1.BandProfileSpec{}

	for i := 0; i < len(sadisDefinition); i++ {
		tmp := v1alpha1.BandProfileSpec{}

		data, _ := json.Marshal(sadisDefinition[i])
		err := json.Unmarshal(data, &tmp)
		if err != nil {
			continue
		}
		if tmp.Ebs == 0 {
			continue
		}
		output = append(output, tmp)
	}
	return output
}

func clearSadisDefinitionsOnt(sadisDefinition []interface{}) []sadis.OntMetric {

	output := []sadis.OntMetric{}

	for i := 0; i < len(sadisDefinition); i++ {
		tmp := sadis.OntMetric{}

		data, _ := json.Marshal(sadisDefinition[i])
		err := json.Unmarshal(data, &tmp)
		if err != nil {
			continue
		}
		if tmp.NasPortId == "" {
			continue
		}
		output = append(output, tmp)
	}
	return output
}

func checker(kubeDefinition v1alpha1.BandProfileSpec, sadisDefinition v1alpha1.BandProfileSpec) bool {

	if kubeDefinition.Id == sadisDefinition.Id && kubeDefinition.Eir == sadisDefinition.Eir && kubeDefinition.Ebs == sadisDefinition.Ebs && kubeDefinition.Cir == sadisDefinition.Cir && kubeDefinition.Cbs == sadisDefinition.Cbs && sadisDefinition.Air == kubeDefinition.Air {
		return true
	}

	return false

}
