package comparator

import (
	"errors"
	"fmt"

	"github.com/go-logr/logr"
	"github.com/opencord/voltha-protos/v4/go/voltha"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/sadis"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/voltha/commands"
)

func deviceList(log logr.Logger) ([]*voltha.Device, error) {
	options := &commands.DeviceList{}
	devices, err := options.Execute()
	if err != nil {
		log.Error(err, "error retrieving the devices list from voltha")
		return nil, err
	}
	for _, device := range devices {
		log.Info("found device in voltha", "id", device.Id)
	}
	return devices, nil
}

func deviceReboot(log logr.Logger, deviceId string) error {
	ids := make([]commands.DeviceId, 0)
	ids = append(ids, commands.DeviceId(deviceId))
	options := &commands.DeviceReboot{
		Ids: ids,
	}
	err := options.Execute()
	if err != nil {
		return err
	}
	return nil
}

func reboot(log logr.Logger, ont v1alpha1.Ont) error {
	devices, err := deviceList(log)
	if err != nil {
		return errors.New(err.Error() + " cannot load list of devices from voltha")
	}
	for _, device := range devices {
		if device.SerialNumber == ont.Spec.SerialNo {
			log.Info("Trying to reboot ONT", "id", ont.Spec.Id, "serialNo", ont.Spec.SerialNo, "volthaId", device.Id)
			err = deviceReboot(log, device.Id)
			if err != nil {
				log.Error(err, "error rebooting the ONT", "id", device.Id)
				continue
			}
		}
	}
	return nil
}

func rebootOnt(bandId string, ontSadis []sadis.OntMetric, ontKube []v1alpha1.Ont, log logr.Logger) error {

	for i := 0; i < len(ontSadis); i++ {

		for k := 0; k < len(ontSadis[i].UniTagList); k++ {
			if ontSadis[i].UniTagList[k].UpStreamBandwidthProfile == bandId {
				//reboot
				ont, found := findKubeOntFromId(ontSadis[i].Id, ontKube)
				if !found {
					return fmt.Errorf("the bandprofile with id: %s seems not used by any ont in the cluster", bandId)
				}
				err := reboot(log, ont)
				if err != nil {
					return err
				}
			} else if ontSadis[i].UniTagList[k].DownStreamBandwidthProfile == bandId {
				//reboot
				ont, found := findKubeOntFromId(ontSadis[i].Id, ontKube)
				if !found {
					return fmt.Errorf("the bandprofile with id: %s seems not used by any ont in the cluster", bandId)
				}
				err := reboot(log, ont)
				if err != nil {
					return err
				}
			}
		}
	}
	return nil
}
