# OLT Operator

## Overview

The olt-operator is a kubernetes operator that manage several crds, used to describe the configurations of optical fiber devices.
This version of olt-operator need as requirements voltha >= 2.9 <= 2.10. The installation for that version of voltha can be found here: https://scm.code.telecomitalia.it/dolt/dev/pod/voltha-helm-charts/-/tree/v2.10

## Installation

To install the olt-operator into a cluster you need to clone this repo, chose the branch, enter the folder and run the command:

```bash
$> git clone <link> --branch=pod-cd/paosim
$> cd olt-operator
$> make docker-build
$> make docker-push
$> make deploy
```

## Endpoints

The olt-operator expose several endopoints, on several ports:

```
:18808 {expose the simulators for pod-cd and sadis}
  - /sadisEntries/{id} {sadis entries}
  - /v2/logicalResource/{ztpIdent} {pod-cd entries}
  - /voltha/add/{ztpIdent} {activate an OLT in voltha}
:8080 {expose the endpoint to update olt software}
  - /olt/software-update/{namespace}/{name}
```

## Pkg overview

The olt-operator is composed by api folder, that contain crds declarations, controller folder, that contains the reconcile loop logics.
In the pkg folder there are some other logics that are used to manage several other functions of the operator:

- client: there are all the k8s clients to get custom resources from the cluster.
- comparator: (Deprecated) contains the logics to manage misconfigurations between sadis store and crds.
- controllers: contains utils functions for the controllers
- deviceManagement: contains the logics for the olt software update
- endpoints: contains the server that expose the simulator for pod-cd and sadis that build the response runtime reading the data from the crds in the cluster
- events: contains usefull function to emit events
- influxdb: contains the functions to connect, read and write metrics on influxdb
- paosim: (Deprecated) contains a client for paosim
- podcd: (Deprecated) contains a client for podcd
- sadis: (Deprecated) contains a client for sadis
- services:
- voltha: contains the commands to interact with voltha (device add, enable and delete)
- volthaetcd: contains the functions used to write into voltha etcd

## Adding a new CRD

```sh
operator-sdk create api --group dolt.it --version v1alpha1 --kind TechProfile --resource --controller
```

## Building from the bastion

```sh
IMAGE_TAG_BASE=registry.dolt.it/doltrepo/olt-operator GIT_TOKEN=giacomo.pruneri:DxwRzou2iTcaVdpg_dxK make docker-build
IMAGE_TAG_BASE=registry.dolt.it/doltrepo/olt-operator GIT_TOKEN=giacomo.pruneri:DxwRzou2iTcaVdpg_dxK make docker-push
IMAGE_TAG_BASE=registry.dolt.it/doltrepo/olt-operator GIT_TOKEN=giacomo.pruneri:DxwRzou2iTcaVdpg_dxK make deploy
```

## Deploy/undeploy influxdb to store metrics

```sh
make deploy-influxdb
make undeploy-influxdb
```

## Check the PODCD status

```sh
kubectl exec grpccli -i  -- curl -sS -XGET http://pod-cd.voltha:8081/api/neids | jq .
```

## Check the PAOSim status

```sh
kubectl exec grpccli -i -- curl -sS -XGET paosim.voltha:18808/onus | jq .
```

## ENV Setup

```bash
INFLUXDB_TOKEN={token for influxdb}
INFLUXDB_BUCKET={bucket name}
INFLUXDB_ORG={org name}
INFLUXDB_ENDPOINT={address of the service}
VAP_GRP_ENDPOINT={vap grpc address}
PAO_SIMULATOR_PORT={pao simulator port (internal)}
PODCD_PORT={podcd simulator port (internal)}
SADIS_ENDPOINT={address of sadis}
PODCD_ENDPOINT={podcd address}
KAFKA_TOPIC_EXPORTER_ENDPOINT={kafka topic exporter address}
VOLTHA_API_SERVICE_ENDPOINT={voltha api servic endpoint}
VOLTHA_ETCD_CLIENT_ENDPOINT={voltha etcd client endpoint}
UPDATE_PODCD={true update false not/ default true}
UPDATE_SADIS={true update false not/ default true}
UPDATE_PAOSIM={true update false not/ default true}
DEFAULT_BANDWITH_PROFILE={json describing default bandwith profile}
DEVICE_MANAGEMENT_WEBSERVER_PORT={port for device management webserver default:8080}
DEVICE_MANAGER_ADDRESS={complete address of native device manager}
GET_SW_VERSION_DELAY={time waited to retry get software version default:30s}
GET_SW_VERSION_MAX_RETRY={number of times the program have to retry before exception, defualt:1}
SFTP_USERNAME={username for artifact registry}
SFTP_TOKEN={token for artifact registry}
ONOS_ENDPOINT={base url of onos}
```
