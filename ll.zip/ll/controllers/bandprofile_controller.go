/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllers

import (
	"context"
	"encoding/json"

	"github.com/go-logr/logr"
	"k8s.io/apimachinery/pkg/runtime"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"

	//"gitlab.devops.telekom.de/Access40/dev/pod/access-proxy.git/pkg/sadis"
	doltitv1alpha1 "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/events"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/sadis"
	"sigs.k8s.io/controller-runtime/pkg/controller/controllerutil"
)

// BandProfileReconciler reconciles a BandProfile object
type BandProfileReconciler struct {
	client.Client
	Log    logr.Logger
	Scheme *runtime.Scheme
}

//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=bandprofiles,verbs=get;list;watch;create;update;patch;delete
//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=bandprofiles/status,verbs=get;update;patch
//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=bandprofiles/finalizers,verbs=update

// Reconcile is part of the main kubernetes reconciliation loop which aims to
// move the current state of the cluster closer to the desired state.
// TODO(user): Modify the Reconcile function to compare the state specified by
// the BandProfile object against the actual cluster state, and then
// perform operations to make the cluster state reflect the state specified by
// the user.
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.8.3/pkg/reconcile

//Check the status of changing bandprofiles
var bandProfileFinalizer = doltitv1alpha1.GroupVersion.Group + "/finalizer"

func (r *BandProfileReconciler) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	_ = r.Log.WithValues("BandProfile", req.NamespacedName)

	bandprofile := &doltitv1alpha1.BandProfile{}
	//r.Log.WithValues(bandprofile)
	println()
	err := r.Get(ctx, req.NamespacedName, bandprofile)
	if err == nil {

		data, _ := json.Marshal(bandprofile.Spec)

		isMarkedToBeDeleted := bandprofile.GetDeletionTimestamp() != nil
		if isMarkedToBeDeleted {
			if controllerutil.ContainsFinalizer(bandprofile, bandProfileFinalizer) {
				// Run finalization logic for out finalizer. If the
				// finalization logic fails, don't remove the finalizer so
				// that we can retry during the next reconciliation.
				if err := r.finalizeBandProfile(r.Log, bandprofile); err != nil {
					return ctrl.Result{}, err
				}

				// Remove finalizer. Once all finalizers have been
				// removed, the object will be deleted.
				controllerutil.RemoveFinalizer(bandprofile, bandProfileFinalizer)
				err := r.Update(ctx, bandprofile)
				if err != nil {
					return ctrl.Result{}, err
				}
			}
			return ctrl.Result{}, nil
		}

		// Add finalizer for this CR
		if !controllerutil.ContainsFinalizer(bandprofile, bandProfileFinalizer) {
			controllerutil.AddFinalizer(bandprofile, bandProfileFinalizer)
			err = r.Update(ctx, bandprofile)
			if err != nil {
				return ctrl.Result{}, err
			}
		}

		//IS NOT BEING DELETED

		sadisClient := sadis.NewSadisClient()
		err = sadisClient.AddMetric(bandprofile.Spec.Id, data)
		if err != nil {
			_ = events.NewEventRecorder("bandprofile", "olt-operator-system", bandprofile, "Normal", "Error while writing sadis", err.Error())
		} else {
			_ = events.NewEventRecorder("bandprofile", "olt-operator-system", bandprofile, "Normal", "Successfuly added to sadis", "Bandprofile id: "+bandprofile.Spec.Id)
		}
	}

	return ctrl.Result{}, nil
}

// SetupWithManager sets up the controller with the Manager.
func (r *BandProfileReconciler) SetupWithManager(mgr ctrl.Manager) error {
	return ctrl.NewControllerManagedBy(mgr).
		For(&doltitv1alpha1.BandProfile{}).
		Complete(r)
}

func (r *BandProfileReconciler) finalizeBandProfile(log logr.Logger, bandprofile *doltitv1alpha1.BandProfile) error {

	sadisClient := sadis.NewSadisClient()
	err := sadisClient.DeleteMetric(bandprofile.Spec.Id)
	if err != nil {
		_ = events.NewEventRecorder("bandprofile", "olt-operator-system", bandprofile, "Normal", "Error while writing sadis", err.Error())
	} else {
		_ = events.NewEventRecorder("bandprofile", "olt-operator-system", bandprofile, "Normal", "Successfuly removed from sadis", "Bandprofile id: "+bandprofile.Spec.Id)
	}

	return nil
}
