/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllers

import (
	"context"
	"fmt"

	"github.com/go-logr/logr"
	"k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/runtime"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/controller/controllerutil"

	doltitv1alpha1 "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	accessnode_utils "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/accessnode_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	podcdClient "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/podcd/client"
)

// AccessNodeReconciler reconciles a AccessNode object
type AccessNodeReconciler struct {
	client.Client
	Log    logr.Logger
	Scheme *runtime.Scheme
}

var accessNodeFinalizer = doltitv1alpha1.GroupVersion.Group + "/finalizer"

//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=accessnodes,verbs=get;list;watch;create;update;patch;delete
//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=accessnodes/status,verbs=get;update;patch
//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=accessnodes/finalizers,verbs=update

// Reconcile is part of the main kubernetes reconciliation loop which aims to
// move the current state of the cluster closer to the desired state.
// TODO(user): Modify the Reconcile function to compare the state specified by
// the AccessNode object against the actual cluster state, and then
// perform operations to make the cluster state reflect the state specified by
// the user.
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.8.3/pkg/reconcile
func (r *AccessNodeReconciler) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	log := r.Log.WithValues("accessnode", req.NamespacedName)

	// Fetch the AccessNode instance
	log.Info("Fetching AccessNode instance")
	an := &doltitv1alpha1.AccessNode{}
	err := r.Get(ctx, req.NamespacedName, an)
	if err != nil {
		if errors.IsNotFound(err) {
			log.Info("AccessNode resource not found. Ignoring since object must be deleted")
			return ctrl.Result{}, nil
		}
		log.Error(err, "Failed to get AccessNode")
		return ctrl.Result{}, err
	}

	// Update the podcd
	accessnode_utils.UpdatePodCD(log, an)

	// Check if the AccessNode instance is marked to be deleted, which is
	// indicated by the deletion timestamp being set.
	isMarkedToBeDeleted := an.GetDeletionTimestamp() != nil
	if isMarkedToBeDeleted {
		if controllerutil.ContainsFinalizer(an, accessNodeFinalizer) {
			// Run finalization logic for out finalizer. If the
			// finalization logic fails, don't remove the finalizer so
			// that we can retry during the next reconciliation.
			if err := r.finalizeAccessNode(log, an, podcdClient.NewClient()); err != nil {
				return ctrl.Result{}, err
			}

			// Remove finalizer. Once all finalizers have been
			// removed, the object will be deleted.
			controllerutil.RemoveFinalizer(an, ontFinalizer)
			err := r.Update(ctx, an)
			if err != nil {
				return ctrl.Result{}, err
			}
		}
		return ctrl.Result{}, nil
	}

	// Add finalizer for this CR
	if !controllerutil.ContainsFinalizer(an, oltFinalizer) {
		controllerutil.AddFinalizer(an, oltFinalizer)
		err = r.Update(ctx, an)
		if err != nil {
			return ctrl.Result{}, err
		}
	}

	return ctrl.Result{}, nil
}

// SetupWithManager sets up the controller with the Manager.
func (r *AccessNodeReconciler) SetupWithManager(mgr ctrl.Manager) error {
	return ctrl.NewControllerManagedBy(mgr).
		For(&doltitv1alpha1.AccessNode{}).
		Complete(r)
}

func (r *AccessNodeReconciler) finalizeAccessNode(log logr.Logger, m *doltitv1alpha1.AccessNode, cd *podcdClient.Client) error {
	log.Info("Finalizing AccessNode", "id", m.Spec.Id)

	// Remove from PODCD
	if env.ReadEnv("UPDATE_PODCD", "true") == "true" {
		log.Info("Removing AccessNode from PodCD", "id", m.Spec.Id)
		res, err := cd.RemoveResource(m.Spec.Id)
		if err != nil {
			// Error reading the object - requeue the request.
			log.Error(err, "Failed to remove the AccessNode from PodCD")
			return err
		}
		log.Info("response from PodCD: " + fmt.Sprint(res.StatusCode))
	}

	log.Info("Successfully finalized AccessNode")
	return nil
}
