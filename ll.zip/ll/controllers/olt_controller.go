/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllers

import (
	"context"
	"fmt"

	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/olt_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	checker2 "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/services/voltha/checker"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/controller/controllerutil"

	"github.com/go-logr/logr"
	"k8s.io/apimachinery/pkg/api/errors"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	doltitv1alpha1 "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	podcdClient "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/podcd/client"
	ctrl "sigs.k8s.io/controller-runtime"
)

// OltReconciler reconciles a Olt object
type OltReconciler struct {
	client.Client
	Log     logr.Logger
	Scheme  *runtime.Scheme
	Checker *checker2.Checker
}

var oltFinalizer = doltitv1alpha1.GroupVersion.Group + "/finalizer"

//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=olts,verbs=get;list;watch;create;update;patch;delete
//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=olts/status,verbs=get;update;patch
//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=olts/finalizers,verbs=update

// Reconcile is part of the main kubernetes reconciliation loop which aims to
// move the current state of the cluster closer to the desired state.
// TODO(user): Modify the Reconcile function to compare the state specified by
// the Olt object against the actual cluster state, and then
// perform operations to make the cluster state reflect the state specified by
// the user.
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.8.3/pkg/reconcile
func (r *OltReconciler) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {

	log := r.Log.WithValues("olt", req.NamespacedName)
	// Fetch the OLT instance
	log.Info("Fetching Olt instance")

	clientset, err := controllers_utils.GetClientSet()
	if err != nil {
		log.Error(err, "Failed to get Accessnode")
		return ctrl.Result{}, err
	}

	oltClient := clientset.Olts(context.TODO(), "olt-operator-system")
	olt, err := oltClient.Get(req.Name, v1.GetOptions{})
	if err != nil {
		if errors.IsNotFound(err) {
			log.Info("Olt resource not found. Ignoring since object must be deleted")
		} else {
			log.Error(err, "Failed to fetch the OLT", "an_id", olt.Spec.ParentId)
		}
		return ctrl.Result{}, err
	}

	accessNodeClient := clientset.AccessNodes(context.TODO(), "olt-operator-system")
	an, err := accessNodeClient.Get(olt.Spec.ParentId, v1.GetOptions{})
	if err != nil {
		log.Error(err, "Failed to fetch the AccessNode", "an_id", olt.Spec.ParentId)
		return ctrl.Result{}, err
	}

	olt_utils.UpdatePodCD(log, olt, an)
	// Check the operationalState and perform the requested operation

	r.Reboot(log, olt, ctx)
	// Check if the Olt instance is marked to be deleted, which is
	// indicated by the deletion timestamp being set.
	isMarkedToBeDeleted := olt.GetDeletionTimestamp() != nil
	if isMarkedToBeDeleted {
		if controllerutil.ContainsFinalizer(olt, oltFinalizer) {
			// Run finalization logic for out finalizer. If the
			// finalization logic fails, don't remove the finalizer so
			// that we can retry during the next reconciliation.
			if err := r.finalizeOlt(log, olt, podcdClient.NewClient()); err != nil {
				return ctrl.Result{}, err
			}

			// Remove finalizer. Once all finalizers have been
			// removed, the object will be deleted.
			controllerutil.RemoveFinalizer(olt, ontFinalizer)
			err := r.Update(ctx, olt)
			if err != nil {
				return ctrl.Result{}, err
			}
		}
		return ctrl.Result{}, nil
	}

	// Add finalizer for this CR
	if !controllerutil.ContainsFinalizer(olt, oltFinalizer) {
		controllerutil.AddFinalizer(olt, oltFinalizer)
		err = r.Update(ctx, olt)
		if err != nil {
			return ctrl.Result{}, err
		}
	}

	return ctrl.Result{}, nil
}

// SetupWithManager sets up the controller with the Manager.
func (r *OltReconciler) SetupWithManager(mgr ctrl.Manager) error {
	return ctrl.NewControllerManagedBy(mgr).
		For(&doltitv1alpha1.Olt{}).
		Complete(r)
}

func (r *OltReconciler) finalizeOlt(log logr.Logger, m *doltitv1alpha1.Olt, cd *podcdClient.Client) error {
	log.Info("Finalizing Olt", "id", m.Spec.Id)

	if env.ReadEnv("UPDATE_PODCD", "true") == "true" {
		log.Info("Removing Olt from PodCD", "id", m.Spec.Id)
		res, err := cd.RemoveResource(m.Spec.Id)
		if err != nil {
			// Error reading the object - requeue the request.
			log.Error(err, "Failed to remove the Olt from PodCD")
			return err
		}
		log.Info("response from PodCD: " + fmt.Sprint(res.StatusCode))
	}

	log.Info("Successfully finalized Olt")
	return nil
}

func (r *OltReconciler) Reboot(log logr.Logger, olt *v1alpha1.Olt, ctx context.Context) error {
	if olt.Spec.OperationalState == "REBOOT" {

		// List the devices in voltha to get their ids
		devices, err := olt_utils.DeviceList(log)
		if err != nil {
			log.Error(err, "cannot load list of devices from voltha")
		}
		for _, device := range devices {
			if device.SerialNumber == olt.Spec.SerialNo {
				log.Info("Trying to reboot OLT", "id", olt.Spec.Id, "serialNo", olt.Spec.SerialNo, "volthaId", device.Id)
				err = olt_utils.DeviceReboot(log, device.Id)
				if err != nil {
					log.Error(err, "error rebooting the OLT", "id", device.Id)
					continue
				}
				olt.Spec.OperationalState = "ACTIVATE"
				err = r.Update(ctx, olt)
				if err != nil {
					log.Error(err, "Something goes wrong during crd UPDATE")
					return err
				}
			}
		}
	}
	return nil
}
