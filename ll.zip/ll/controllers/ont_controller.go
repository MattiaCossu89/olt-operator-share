/*
Copyright 2021.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllers

import (
	"context"
	goerrors "errors"
	"fmt"

	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/controllers_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/controllers/ont_utils"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/endpoints/paosim/env"
	"sigs.k8s.io/controller-runtime/pkg/controller/controllerutil"

	"github.com/go-logr/logr"
	"k8s.io/apimachinery/pkg/api/errors"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	doltitv1alpha1 "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/api/v1alpha1"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/events"
	paoClient "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/paosim/client"
	podcdClient "scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/podcd/client"
	"scm.code.telecomitalia.it/dolt/dev/pod/olt-operator.git/pkg/sadis"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
)

// OntReconciler reconciles a Ont object
type OntReconciler struct {
	client.Client
	Log    logr.Logger
	Scheme *runtime.Scheme
}

var ontFinalizer = doltitv1alpha1.GroupVersion.Group + "/finalizer"

//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=onts,verbs=get;list;watch;create;update;patch;delete
//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=onts/status,verbs=get;update;patch
//+kubebuilder:rbac:groups=dolt.it.dolt.it,resources=onts/finalizers,verbs=update

// Reconcile is part of the main kubernetes reconciliation loop which aims to
// move the current state of the cluster closer to the desired state.
// TODO(user): Modify the Reconcile function to compare the state specified by
// the Ont object against the actual cluster state, and then
// perform operations to make the cluster state reflect the state specified by
// the user.
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.8.3/pkg/reconcile
func (r *OntReconciler) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	log := r.Log.WithValues("ont", req.NamespacedName)

	// Fetch the ONT instance
	log.Info("Fetching Ont instance")
	clientset, err := controllers_utils.GetClientSet()
	if err != nil {
		return ctrl.Result{}, err
	}

	ontClient := clientset.Onts(context.TODO(), "olt-operator-system")
	ont, err := ontClient.Get(req.Name, v1.GetOptions{})
	if err != nil {
		if errors.IsNotFound(err) {
			log.Info("Ont resource not found. Ignoring since object must be deleted")
		} else {
			log.Error(err, "Failed to get Ont")
		}
		return ctrl.Result{}, err
	}

	// Fetch the ServiceProfile
	serviceProfileClient := clientset.ServiceProfiles(context.TODO(), "olt-operator-system")
	serviceProfile, err := serviceProfileClient.Get(ont.Spec.ServiceId, v1.GetOptions{})
	if err != nil {
		log.Error(err, "Failed to fetch the ServiceProfile", "service_profile_id", ont.Spec.ServiceId)
		return ctrl.Result{}, err
	} else if len(serviceProfile.Spec.ServiceInfo) == 0 {
		log.Error(err, "Failed to read serviceInfo", "serviceprofile_id", serviceProfile.Spec.Id)
		return ctrl.Result{}, goerrors.New(fmt.Sprintf("missing service info in service profile with id %s. you have to add at least one item to the serviceInfo array", serviceProfile.Spec.Id))
	}

	err = ont_utils.AddToSadis(log, serviceProfile, ont)
	if err != nil {
		log.Error(err, "Failed to create/update ont into sadis")
		return ctrl.Result{}, err
	}
	ont_utils.UpdatePodCD(log, ont)
	ont_utils.UpdatePaoSim(log, serviceProfile, ont)

	// Check if the Ont instance is marked to be deleted, which is indicated by the deletion timestamp being set.
	isMarkedToBeDeleted := ont.GetDeletionTimestamp() != nil
	if isMarkedToBeDeleted {
		if controllerutil.ContainsFinalizer(ont, ontFinalizer) {
			// Run finalization logic for out finalizer. If the finalization logic fails, don't remove the finalizer so that we can retry during the next reconciliation.
			if err := r.finalizeOnt(log, ont, paoClient.NewClient(), podcdClient.NewClient()); err != nil {
				return ctrl.Result{}, err
			}
			// Remove finalizer. Once all finalizers have beenremoved, the object will be deleted.
			controllerutil.RemoveFinalizer(ont, ontFinalizer)
			err := r.Update(ctx, ont)
			if err != nil {
				return ctrl.Result{}, err
			}
		}
		return ctrl.Result{}, nil
	}

	// Add finalizer for this CR
	if !controllerutil.ContainsFinalizer(ont, ontFinalizer) {
		controllerutil.AddFinalizer(ont, ontFinalizer)
		err = r.Update(ctx, ont)
		if err != nil {
			return ctrl.Result{}, err
		}
	}

	return ctrl.Result{}, nil
}

// SetupWithManager sets up the controller with the Manager.
func (r *OntReconciler) SetupWithManager(mgr ctrl.Manager) error {
	return ctrl.NewControllerManagedBy(mgr).
		For(&doltitv1alpha1.Ont{}).
		Complete(r)
}

func (r *OntReconciler) Reboot(log logr.Logger, ont *v1alpha1.Ont, ctx context.Context) error {
	if ont.Spec.OperationalState == "REBOOT" {
		// List the devices in voltha to get their ids
		devices, err := ont_utils.DeviceList(log)
		if err != nil {
			log.Error(err, "cannot load list of devices from voltha")
		}
		for _, device := range devices {
			if device.SerialNumber == ont.Spec.SerialNo {
				log.Info("Trying to reboot ONT", "id", ont.Spec.Id, "serialNo", ont.Spec.SerialNo, "volthaId", device.Id)
				err = ont_utils.DeviceReboot(log, device.Id)
				if err != nil {
					log.Error(err, "error rebooting the ONT", "id", device.Id)
					continue
				}
				ont.Spec.OperationalState = "ACTIVATE"
				err = r.Update(ctx, ont)
				if err != nil {
					return err
				}
			}
		}
	}
	return nil
}

func (r *OntReconciler) finalizeOnt(log logr.Logger, m *doltitv1alpha1.Ont, pao *paoClient.Client, cd *podcdClient.Client) error {
	log.Info("Finalizing Ont", "id", m.Spec.Id)

	if env.ReadEnv("UPDATE_SADIS", "true") == "true" {
		sadisClient := sadis.NewSadisClient()
		err := sadisClient.DeleteMetric(m.Spec.SerialNo + "-1")
		if err != nil {
			_ = events.NewEventRecorder("ont", "olt-operator-system", m, "Normal", "Error while writing sadis", err.Error())
		} else {
			_ = events.NewEventRecorder("ont", "olt-operator-system", m, "Normal", "Successfuly removed from sadis", "Bandprofile id: "+m.Spec.SerialNo+"-1")
		}
	}

	// Remove from PAOSim
	if env.ReadEnv("UPDATE_PAOSIM", "true") == "true" {
		log.Info("Removing Ont from PaoSim", "serialNo", m.Spec.SerialNo)
		res, err := pao.RemoveONU(m.Spec.SerialNo)
		if err != nil {
			// Error reading the object - requeue the request.
			log.Error(err, "Failed to remove the Ont from PaoSim")
			return err
		}
		log.Info("response from paoSim: " + fmt.Sprint(res.StatusCode))
	}

	// Remove from PODCD
	if env.ReadEnv("UPDATE_PODCD", "true") == "true" {
		log.Info("Removing Ont from PodCD", "id", m.Spec.Id)
		res, err := cd.RemoveResource(m.Spec.Id)
		if err != nil {
			// Error reading the object - requeue the request.
			log.Error(err, "Failed to remove the Ont from PodCD")
			return err
		}
		log.Info("response from PodCD: " + fmt.Sprint(res.StatusCode))
	}

	log.Info("Successfully finalized Ont")
	return nil
}
